
 <!-- Content Header (Page header) -->
      
		  <!-- Main content -->
        <section class="content">
   <div class="row">
            <div class="col-md-12">
		
        <div class="box box-danger">
                <div style="cursor: move;" class="box-header ui-sortable-handle">
                  <i class="fa fa-user"></i>
                  <h3 class="box-title">Customer</h3>
                 
                </div>
                <div class="box-body table-responsive">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
					    <th>Name</th>
					   <th>Email ID</th>
					    <th>Address</th>
					    <th>Pin Code</th>
					   <th>Contact No.</th>
                        <th>Date Of Birth</th>
                       
                      </tr>
                    </thead>
					<tbody>
					<?php 
				  $getdata = $this->db->query("select * from customer order by id desc");
 if ($getdata->num_rows() > 0) {
                                foreach ($getdata->result_array() as $rows) {
								$id=$rows['id'];
								$name=$rows['name'];
								$emailid=$rows['emailid'];
								$address=$rows['address'];
								$pincode=$rows['pincode'];
								 $contactno=$rows['contactno'];
								  $dob=$rows['dob'];
							?>	
                    
                      <tr>
					    <td><?php echo $name;?></td>
					   <td><?php echo $emailid;?></td>
                        <td><?php echo $address;?></td>
                        <td><?php echo $pincode;?></td>
                        <td><?php echo $contactno;?></td>
                        <td><?php echo $dob;?></td>
                      
                       
                      </tr>
					  <?php     }		}
 ?>
              
                    </tbody>
                  
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
			   </div>
			    </div>
				  </section><!-- /.content -->
			  <script type="text/javascript">
      $(function () {
       
        $('#example1').dataTable({
          "bPaginate": true,
          "bLengthChange": true,
          "bFilter": true,
          "bSort": false,
          "bInfo": true,
          "bAutoWidth": false
        });
      });
    </script>