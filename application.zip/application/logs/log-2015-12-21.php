<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-21 06:58:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\edulocation\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-21 06:58:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\edulocation\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-21 06:58:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\edulocation\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-21 06:58:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\edulocation\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-21 06:58:21 --> Severity: Warning  --> include(C:\xampp\htdocs\edulocation\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\edulocation\admin\application\views\v_main.php 142
ERROR - 2015-12-21 06:58:21 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\edulocation\admin\application\views\v_main.php 142
ERROR - 2015-12-21 06:58:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\edulocation\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-21 06:58:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\edulocation\admin\application\views\state\statemanage.php 47
ERROR - 2015-12-21 06:58:29 --> Severity: Notice  --> Undefined variable: state_name C:\xampp\htdocs\edulocation\admin\application\views\state\statemanage.php 58
ERROR - 2015-12-21 06:58:29 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 44
ERROR - 2015-12-21 06:58:29 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 45
ERROR - 2015-12-21 06:58:29 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 46
ERROR - 2015-12-21 06:58:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\edulocation\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-21 06:58:28 --> Severity: Notice  --> Undefined variable: state_id C:\xampp\htdocs\edulocation\admin\application\views\district\districtmanage.php 41
ERROR - 2015-12-21 06:58:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\edulocation\admin\application\views\district\districtmanage.php 62
ERROR - 2015-12-21 06:58:28 --> Severity: Notice  --> Undefined variable: district_name C:\xampp\htdocs\edulocation\admin\application\views\district\districtmanage.php 73
ERROR - 2015-12-21 06:58:28 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 44
ERROR - 2015-12-21 06:58:28 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 45
ERROR - 2015-12-21 06:58:28 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 46
ERROR - 2015-12-21 06:58:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\edulocation\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-21 06:58:31 --> Severity: Notice  --> Undefined variable: state_id C:\xampp\htdocs\edulocation\admin\application\views\city\citymanage.php 53
ERROR - 2015-12-21 06:58:31 --> Severity: Notice  --> Undefined variable: district_id C:\xampp\htdocs\edulocation\admin\application\views\city\citymanage.php 78
ERROR - 2015-12-21 06:58:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\edulocation\admin\application\views\city\citymanage.php 99
ERROR - 2015-12-21 06:58:31 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\edulocation\admin\application\views\city\citymanage.php 110
ERROR - 2015-12-21 06:58:31 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 44
ERROR - 2015-12-21 06:58:31 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 45
ERROR - 2015-12-21 06:58:31 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 46
ERROR - 2015-12-21 07:01:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\edulocation\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-21 07:01:13 --> Severity: Notice  --> Undefined variable: state_id C:\xampp\htdocs\edulocation\admin\application\views\city\citymanage.php 53
ERROR - 2015-12-21 07:01:13 --> Severity: Notice  --> Undefined variable: district_id C:\xampp\htdocs\edulocation\admin\application\views\city\citymanage.php 78
ERROR - 2015-12-21 07:01:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\edulocation\admin\application\views\city\citymanage.php 99
ERROR - 2015-12-21 07:01:13 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\edulocation\admin\application\views\city\citymanage.php 110
ERROR - 2015-12-21 07:01:13 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 44
ERROR - 2015-12-21 07:01:13 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 45
ERROR - 2015-12-21 07:01:13 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 46
ERROR - 2015-12-21 07:01:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\edulocation\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-21 07:01:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\edulocation\admin\application\views\subject\subjectmanage.php 47
ERROR - 2015-12-21 07:01:25 --> Severity: Notice  --> Undefined variable: subject_name C:\xampp\htdocs\edulocation\admin\application\views\subject\subjectmanage.php 58
ERROR - 2015-12-21 07:01:25 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 44
ERROR - 2015-12-21 07:01:25 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 45
ERROR - 2015-12-21 07:01:25 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 46
ERROR - 2015-12-21 07:01:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\edulocation\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-21 07:01:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\edulocation\admin\application\views\standard\standardmanage.php 47
ERROR - 2015-12-21 07:01:29 --> Severity: Notice  --> Undefined variable: standard_name C:\xampp\htdocs\edulocation\admin\application\views\standard\standardmanage.php 58
ERROR - 2015-12-21 07:01:29 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 44
ERROR - 2015-12-21 07:01:29 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 45
ERROR - 2015-12-21 07:01:29 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 46
ERROR - 2015-12-21 07:01:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\edulocation\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-21 07:01:31 --> Severity: Notice  --> Undefined variable: state_id C:\xampp\htdocs\edulocation\admin\application\views\city\citymanage.php 53
ERROR - 2015-12-21 07:01:31 --> Severity: Notice  --> Undefined variable: district_id C:\xampp\htdocs\edulocation\admin\application\views\city\citymanage.php 78
ERROR - 2015-12-21 07:01:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\edulocation\admin\application\views\city\citymanage.php 99
ERROR - 2015-12-21 07:01:31 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\edulocation\admin\application\views\city\citymanage.php 110
ERROR - 2015-12-21 07:01:31 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 44
ERROR - 2015-12-21 07:01:31 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 45
ERROR - 2015-12-21 07:01:31 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 46
ERROR - 2015-12-21 07:01:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\edulocation\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-21 07:01:38 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\edulocation\admin\application\views\state\statemanage.php 47
ERROR - 2015-12-21 07:01:38 --> Severity: Notice  --> Undefined variable: state_name C:\xampp\htdocs\edulocation\admin\application\views\state\statemanage.php 58
ERROR - 2015-12-21 07:01:38 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 44
ERROR - 2015-12-21 07:01:38 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 45
ERROR - 2015-12-21 07:01:38 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\edulocation\admin\application\models\edulocation_model.php 46
ERROR - 2015-12-21 07:09:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\edulocation\admin\system\database\drivers\mysql\mysql_driver.php 92
