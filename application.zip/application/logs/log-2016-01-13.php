<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-01-13 11:13:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:13:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:13:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:13:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:16:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:16:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2016-01-13 11:16:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-13 11:16:08 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-13 11:16:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2016-01-13 11:16:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2016-01-13 11:16:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2016-01-13 11:16:08 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2016-01-13 11:34:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:34:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 11:34:01 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 11:34:01 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 11:34:01 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 11:34:01 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 11:34:01 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2016-01-13 11:34:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:40:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:40:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:40:46 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 514
ERROR - 2016-01-13 11:40:46 --> Severity: Notice  --> Undefined index: username C:\xampp\htdocs\baang\admin\application\models\baang_model.php 222
ERROR - 2016-01-13 11:40:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:40:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:40:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:40:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 11:40:55 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 11:40:55 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 11:40:55 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 11:40:55 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 11:40:55 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2016-01-13 11:41:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:41:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:41:36 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 514
ERROR - 2016-01-13 11:41:36 --> Severity: Notice  --> Undefined index: username C:\xampp\htdocs\baang\admin\application\models\baang_model.php 222
ERROR - 2016-01-13 11:41:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:41:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:41:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:41:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 11:41:46 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 11:41:46 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 11:41:46 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 11:41:46 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 11:41:46 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2016-01-13 11:41:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:42:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:42:03 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 514
ERROR - 2016-01-13 11:42:03 --> Severity: Notice  --> Undefined index: username C:\xampp\htdocs\baang\admin\application\models\baang_model.php 222
ERROR - 2016-01-13 11:42:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:42:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:42:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:42:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:42:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 11:42:18 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 11:42:18 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 11:42:18 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 11:42:18 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 11:42:18 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2016-01-13 11:42:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:42:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:42:33 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 514
ERROR - 2016-01-13 11:42:33 --> Severity: Notice  --> Undefined index: username C:\xampp\htdocs\baang\admin\application\models\baang_model.php 222
ERROR - 2016-01-13 11:42:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:42:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:56:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:56:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 11:56:25 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 11:56:25 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 11:56:25 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 11:56:25 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 11:56:25 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2016-01-13 11:56:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:56:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:56:31 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 514
ERROR - 2016-01-13 11:56:31 --> Severity: Notice  --> Undefined index: username C:\xampp\htdocs\baang\admin\application\models\baang_model.php 222
ERROR - 2016-01-13 11:57:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:57:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:57:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:57:21 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2016-01-13 11:57:21 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2016-01-13 11:57:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 107
ERROR - 2016-01-13 11:57:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 120
ERROR - 2016-01-13 11:57:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-13 11:57:21 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-13 11:57:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 125
ERROR - 2016-01-13 11:57:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 127
ERROR - 2016-01-13 11:57:21 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 143
ERROR - 2016-01-13 11:57:21 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 169
ERROR - 2016-01-13 11:57:21 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 187
ERROR - 2016-01-13 11:57:21 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 210
ERROR - 2016-01-13 11:57:21 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 232
ERROR - 2016-01-13 11:57:21 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 258
ERROR - 2016-01-13 11:57:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:57:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 11:57:26 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 11:57:26 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 11:57:26 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 11:57:26 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 11:57:26 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2016-01-13 11:57:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:57:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:57:32 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 514
ERROR - 2016-01-13 11:57:32 --> Severity: Notice  --> Undefined index: username C:\xampp\htdocs\baang\admin\application\models\baang_model.php 222
ERROR - 2016-01-13 11:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:58:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:58:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:58:10 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 514
ERROR - 2016-01-13 11:58:10 --> Severity: Notice  --> Undefined index: username C:\xampp\htdocs\baang\admin\application\models\baang_model.php 222
ERROR - 2016-01-13 11:58:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:58:42 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 514
ERROR - 2016-01-13 11:58:42 --> Severity: Notice  --> Undefined index: username C:\xampp\htdocs\baang\admin\application\models\baang_model.php 222
ERROR - 2016-01-13 11:59:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 11:59:48 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 514
ERROR - 2016-01-13 11:59:48 --> Severity: Notice  --> Undefined index: username C:\xampp\htdocs\baang\admin\application\models\baang_model.php 222
ERROR - 2016-01-13 12:00:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:01:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:01:01 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 514
ERROR - 2016-01-13 12:01:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:01:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 12:01:01 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 12:01:01 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 12:01:01 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 12:01:01 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 12:01:01 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2016-01-13 12:01:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:01:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:01:11 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 514
ERROR - 2016-01-13 12:01:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:01:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:01:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:01:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:01:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 12:01:22 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 12:01:22 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 12:01:22 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 12:01:22 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 12:01:22 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2016-01-13 12:01:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:01:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 12:01:26 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 12:01:26 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 12:01:26 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 12:01:26 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 12:01:26 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2016-01-13 12:01:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:01:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:01:33 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 514
ERROR - 2016-01-13 12:01:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:01:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:01:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:01:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 12:01:47 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 12:01:47 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 12:01:47 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 12:01:47 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 12:01:47 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2016-01-13 12:03:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:04:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:04:27 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2016-01-13 12:04:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:04:47 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2016-01-13 12:06:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:06:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:07:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:07:23 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 186
ERROR - 2016-01-13 12:07:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:07:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 12:07:27 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 12:07:27 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 12:07:27 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 12:07:27 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 12:07:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:07:31 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 186
ERROR - 2016-01-13 12:08:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:08:05 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 187
ERROR - 2016-01-13 12:08:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:08:15 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 12:08:15 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 12:08:15 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 12:08:15 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 12:08:15 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 12:08:15 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 187
ERROR - 2016-01-13 12:09:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:09:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 12:09:10 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 12:09:10 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 12:09:10 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 12:09:10 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 12:09:10 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 187
ERROR - 2016-01-13 12:09:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:09:35 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 187
ERROR - 2016-01-13 12:12:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:12:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:12:06 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 514
ERROR - 2016-01-13 12:12:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:12:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 12:12:06 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 12:12:06 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 12:12:06 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 12:12:06 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 12:12:06 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 185
ERROR - 2016-01-13 12:12:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:12:42 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 12:12:42 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 12:12:42 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 12:12:42 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 12:12:42 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 12:12:42 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 185
ERROR - 2016-01-13 12:12:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:12:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:12:45 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 514
ERROR - 2016-01-13 12:12:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:12:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 12:12:46 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 12:12:46 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 12:12:46 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 12:12:46 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 12:12:46 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 185
ERROR - 2016-01-13 12:12:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:12:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:12:52 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 514
ERROR - 2016-01-13 12:12:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:13:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:13:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:13:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:13:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 12:13:04 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 12:13:04 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 12:13:04 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 12:13:04 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 12:13:04 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 185
ERROR - 2016-01-13 12:13:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:13:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:13:10 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 514
ERROR - 2016-01-13 12:13:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:13:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:14:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:14:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:14:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:15:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:15:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:16:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:17:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:17:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\changepasswordform.php 32
ERROR - 2016-01-13 12:17:14 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\changepasswordform.php 53
ERROR - 2016-01-13 12:17:14 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\changepasswordform.php 77
ERROR - 2016-01-13 12:20:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:23:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:23:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:23:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:24:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:24:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:24:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:24:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:24:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:24:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:24:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:24:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:25:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:30:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:30:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-13 12:30:34 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-13 12:30:34 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-13 12:30:34 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-13 12:30:34 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-13 12:30:34 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 185
ERROR - 2016-01-13 12:30:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:35:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:35:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:35:41 --> 404 Page Not Found --> baang/testimonialmanage
ERROR - 2016-01-13 12:35:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:35:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2016-01-13 12:35:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-13 12:35:44 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-13 12:35:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2016-01-13 12:35:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2016-01-13 12:35:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2016-01-13 12:35:44 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2016-01-13 12:35:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:35:52 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2016-01-13 12:35:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2016-01-13 12:35:52 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2016-01-13 12:46:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:46:27 --> Severity: Notice  --> Undefined variable: get_user_details C:\xampp\htdocs\baang\admin\application\views\v_main.php 7
ERROR - 2016-01-13 12:46:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 33
ERROR - 2016-01-13 12:46:27 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 50
ERROR - 2016-01-13 12:46:27 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 69
ERROR - 2016-01-13 12:46:27 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 88
ERROR - 2016-01-13 12:46:27 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 12:46:27 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 12:46:27 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 12:46:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:46:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:46:38 --> Severity: Notice  --> Undefined variable: get_user_details C:\xampp\htdocs\baang\admin\application\views\v_main.php 7
ERROR - 2016-01-13 12:46:38 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 33
ERROR - 2016-01-13 12:46:38 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 50
ERROR - 2016-01-13 12:46:38 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 69
ERROR - 2016-01-13 12:46:38 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 88
ERROR - 2016-01-13 12:46:38 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 12:46:38 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 12:46:38 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 12:46:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:46:42 --> Severity: Notice  --> Undefined variable: get_user_details C:\xampp\htdocs\baang\admin\application\views\v_main.php 7
ERROR - 2016-01-13 12:46:42 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 12:46:42 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 12:46:42 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 12:46:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:46:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:46:45 --> Severity: Notice  --> Undefined variable: get_user_details C:\xampp\htdocs\baang\admin\application\views\v_main.php 7
ERROR - 2016-01-13 12:46:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 33
ERROR - 2016-01-13 12:46:45 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 50
ERROR - 2016-01-13 12:46:45 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 69
ERROR - 2016-01-13 12:46:45 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 88
ERROR - 2016-01-13 12:46:45 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 12:46:45 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 12:46:45 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 12:46:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:46:50 --> Severity: Notice  --> Undefined variable: get_user_details C:\xampp\htdocs\baang\admin\application\views\v_main.php 7
ERROR - 2016-01-13 12:46:50 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 12:46:50 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 12:46:50 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 12:46:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:46:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:46:56 --> Severity: Notice  --> Undefined variable: get_user_details C:\xampp\htdocs\baang\admin\application\views\v_main.php 7
ERROR - 2016-01-13 12:46:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 33
ERROR - 2016-01-13 12:46:56 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 50
ERROR - 2016-01-13 12:46:56 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 69
ERROR - 2016-01-13 12:46:56 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 88
ERROR - 2016-01-13 12:46:56 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 12:46:56 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 12:46:56 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 12:47:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:47:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:47:13 --> Severity: Notice  --> Undefined variable: get_user_details C:\xampp\htdocs\baang\admin\application\views\v_main.php 7
ERROR - 2016-01-13 12:47:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 33
ERROR - 2016-01-13 12:47:13 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 50
ERROR - 2016-01-13 12:47:13 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 69
ERROR - 2016-01-13 12:47:13 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 88
ERROR - 2016-01-13 12:47:13 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 12:47:13 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 12:47:13 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 12:47:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:47:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:47:21 --> Severity: Notice  --> Undefined variable: get_user_details C:\xampp\htdocs\baang\admin\application\views\v_main.php 7
ERROR - 2016-01-13 12:47:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 33
ERROR - 2016-01-13 12:47:21 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 50
ERROR - 2016-01-13 12:47:21 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 69
ERROR - 2016-01-13 12:47:21 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 88
ERROR - 2016-01-13 12:47:21 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 12:47:21 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 12:47:21 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 12:47:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:47:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:47:50 --> Severity: Notice  --> Undefined variable: get_user_details C:\xampp\htdocs\baang\admin\application\views\v_main.php 7
ERROR - 2016-01-13 12:47:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 33
ERROR - 2016-01-13 12:47:50 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 50
ERROR - 2016-01-13 12:47:50 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 69
ERROR - 2016-01-13 12:47:50 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 88
ERROR - 2016-01-13 12:47:50 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 12:47:50 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 12:47:50 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 12:47:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:47:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:47:54 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2016-01-13 12:47:54 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-13 12:47:54 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-13 12:47:54 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2016-01-13 12:47:54 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2016-01-13 12:47:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2016-01-13 12:47:54 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2016-01-13 12:47:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:47:56 --> Severity: Notice  --> Undefined variable: get_user_details C:\xampp\htdocs\baang\admin\application\views\v_main.php 7
ERROR - 2016-01-13 12:47:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 33
ERROR - 2016-01-13 12:47:56 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 50
ERROR - 2016-01-13 12:47:56 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 69
ERROR - 2016-01-13 12:47:56 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 88
ERROR - 2016-01-13 12:47:56 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 12:47:56 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 12:47:56 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 12:48:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:48:33 --> Severity: Notice  --> Undefined variable: get_user_details C:\xampp\htdocs\baang\admin\application\views\v_main.php 7
ERROR - 2016-01-13 12:48:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 33
ERROR - 2016-01-13 12:48:33 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 50
ERROR - 2016-01-13 12:48:33 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 69
ERROR - 2016-01-13 12:48:33 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 88
ERROR - 2016-01-13 12:48:33 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 12:48:33 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 12:48:33 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 12:48:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:48:50 --> Severity: Notice  --> Undefined variable: get_user_details C:\xampp\htdocs\baang\admin\application\views\v_main.php 7
ERROR - 2016-01-13 12:48:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 33
ERROR - 2016-01-13 12:48:50 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 50
ERROR - 2016-01-13 12:48:50 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 69
ERROR - 2016-01-13 12:48:50 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 88
ERROR - 2016-01-13 12:48:50 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 12:48:50 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 12:48:50 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 12:49:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:49:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:49:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:49:41 --> Severity: Notice  --> Undefined variable: get_user_details C:\xampp\htdocs\baang\admin\application\views\v_main.php 7
ERROR - 2016-01-13 12:49:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 33
ERROR - 2016-01-13 12:49:41 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 50
ERROR - 2016-01-13 12:49:41 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 69
ERROR - 2016-01-13 12:49:41 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 88
ERROR - 2016-01-13 12:49:41 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 12:49:41 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 12:49:41 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 12:50:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:50:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 33
ERROR - 2016-01-13 12:50:10 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 50
ERROR - 2016-01-13 12:50:10 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 69
ERROR - 2016-01-13 12:50:10 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 88
ERROR - 2016-01-13 12:50:10 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 12:50:10 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 12:50:10 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 12:50:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:50:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 33
ERROR - 2016-01-13 12:50:47 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 50
ERROR - 2016-01-13 12:50:47 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 69
ERROR - 2016-01-13 12:50:47 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 88
ERROR - 2016-01-13 12:50:47 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 12:50:47 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 12:50:47 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 12:50:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:50:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:50:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 33
ERROR - 2016-01-13 12:50:51 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 50
ERROR - 2016-01-13 12:50:51 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 69
ERROR - 2016-01-13 12:50:51 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 88
ERROR - 2016-01-13 12:50:51 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 12:50:51 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 12:50:51 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 12:50:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:50:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 12:50:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 33
ERROR - 2016-01-13 12:50:57 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 50
ERROR - 2016-01-13 12:50:57 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 69
ERROR - 2016-01-13 12:50:57 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 88
ERROR - 2016-01-13 12:50:57 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 12:50:57 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 12:50:57 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 13:01:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 13:01:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 13:01:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 33
ERROR - 2016-01-13 13:01:25 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 50
ERROR - 2016-01-13 13:01:25 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 69
ERROR - 2016-01-13 13:01:25 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 88
ERROR - 2016-01-13 13:01:25 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 13:01:25 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 13:01:25 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
ERROR - 2016-01-13 13:01:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 13:01:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 13:01:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 33
ERROR - 2016-01-13 13:01:41 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 50
ERROR - 2016-01-13 13:01:41 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 69
ERROR - 2016-01-13 13:01:41 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\testimonial\testimonialmanage.php 88
ERROR - 2016-01-13 13:01:41 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 44
ERROR - 2016-01-13 13:01:41 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\baang\admin\application\models\baang_model.php 45
ERROR - 2016-01-13 13:01:41 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\baang\admin\application\models\baang_model.php 46
