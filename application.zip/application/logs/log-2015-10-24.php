<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-24 16:38:38 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-10-24 16:38:51 --> Severity: Warning  --> include(C:\xampp\htdocs\classfeverevent\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\classfeverevent\admin\application\views\v_main.php 147
ERROR - 2015-10-24 16:38:51 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\classfeverevent\admin\application\views\v_main.php 147
