<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-11-18 03:53:07 --> Severity: Notice  --> Undefined variable: id /home/fishwqrb/public_html/admin/application/views/testimonial/testimonialmanage.php 33
ERROR - 2016-11-18 03:53:07 --> Severity: Notice  --> Undefined variable: name /home/fishwqrb/public_html/admin/application/views/testimonial/testimonialmanage.php 50
ERROR - 2016-11-18 03:53:07 --> Severity: Notice  --> Undefined variable: location /home/fishwqrb/public_html/admin/application/views/testimonial/testimonialmanage.php 69
ERROR - 2016-11-18 03:53:07 --> Severity: Notice  --> Undefined variable: description /home/fishwqrb/public_html/admin/application/views/testimonial/testimonialmanage.php 88
ERROR - 2016-11-18 03:53:07 --> Severity: Notice  --> Undefined index: condition /home/fishwqrb/public_html/admin/application/models/baang_model.php 44
ERROR - 2016-11-18 03:53:07 --> Severity: Notice  --> Undefined index: limit /home/fishwqrb/public_html/admin/application/models/baang_model.php 45
ERROR - 2016-11-18 03:53:07 --> Severity: Notice  --> Undefined index: offset /home/fishwqrb/public_html/admin/application/models/baang_model.php 46
