<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-12 15:19:03 --> Severity: Warning  --> include(C:\xampp\htdocs\classfeverevent\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\classfeverevent\admin\application\views\v_main.php 147
ERROR - 2015-10-12 15:19:03 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\classfeverevent\admin\application\views\v_main.php 147
ERROR - 2015-10-12 15:19:23 --> Severity: Notice  --> Undefined index: attendance C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 302
ERROR - 2015-10-12 15:19:23 --> Severity: Notice  --> Undefined index: attendance C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 308
ERROR - 2015-10-12 15:19:23 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-12 15:19:23 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-12 15:19:23 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-12 15:19:23 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-12 15:19:24 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-12 15:19:24 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-12 15:19:24 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-12 15:19:24 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-12 15:19:24 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-12 15:19:24 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-12 15:19:24 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-12 15:19:24 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-12 15:19:24 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-12 15:19:24 --> Severity: Notice  --> Undefined variable: event_id C:\xampp\htdocs\classfeverevent\admin\application\views\ratingparticipatingschools.php 91
ERROR - 2015-10-12 15:19:24 --> Severity: Notice  --> Undefined variable: event_rating C:\xampp\htdocs\classfeverevent\admin\application\views\ratingparticipatingschools.php 110
