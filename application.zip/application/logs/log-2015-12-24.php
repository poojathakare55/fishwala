<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-24 06:45:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:45:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:46:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:46:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:46:45 --> Severity: Warning  --> include(C:\xampp\htdocs\tourism\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\tourism\admin\application\views\v_main.php 144
ERROR - 2015-12-24 06:46:45 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\tourism\admin\application\views\v_main.php 144
ERROR - 2015-12-24 06:50:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 96
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 109
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 114
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 116
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: announcement_name C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 132
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 153
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 178
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: announcement_date C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 196
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: fees C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 218
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: no_of_participants C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 241
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 263
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 285
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: venue C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 309
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: history C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 333
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 357
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: priority C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 380
ERROR - 2015-12-24 06:50:12 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 400
ERROR - 2015-12-24 06:51:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:52:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:52:22 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 1268
ERROR - 2015-12-24 06:52:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 96
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 109
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 114
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 116
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: announcement_name C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 132
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 153
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 178
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: announcement_date C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 196
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: fees C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 218
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: no_of_participants C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 241
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 263
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 285
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: venue C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 309
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: history C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 333
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 357
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: priority C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 380
ERROR - 2015-12-24 06:52:23 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 400
ERROR - 2015-12-24 06:52:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:52:29 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 06:52:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 96
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 109
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 114
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 116
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: announcement_name C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 132
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 153
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 178
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: announcement_date C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 196
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: fees C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 218
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: no_of_participants C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 241
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 263
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 285
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: venue C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 309
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: history C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 333
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 357
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: priority C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 380
ERROR - 2015-12-24 06:52:40 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 400
ERROR - 2015-12-24 06:53:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:53:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 1268
ERROR - 2015-12-24 06:53:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 96
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 109
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 114
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 116
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: announcement_name C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 132
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 153
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 178
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: announcement_date C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 196
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: fees C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 218
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: no_of_participants C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 241
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 263
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 285
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: venue C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 309
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: history C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 333
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 357
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: priority C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 380
ERROR - 2015-12-24 06:53:45 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 400
ERROR - 2015-12-24 06:54:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:55:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined index: extension C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 1267
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 1268
ERROR - 2015-12-24 06:55:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 96
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 109
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 114
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 116
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: announcement_name C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 132
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 153
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 178
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: announcement_date C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 196
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: fees C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 218
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: no_of_participants C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 241
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 263
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 285
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: venue C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 309
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: history C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 333
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 357
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: priority C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 380
ERROR - 2015-12-24 06:55:04 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 400
ERROR - 2015-12-24 06:55:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:55:39 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 06:55:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 1268
ERROR - 2015-12-24 06:55:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 96
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 109
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 114
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 116
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: announcement_name C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 132
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 153
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 178
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: announcement_date C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 196
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: fees C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 218
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: no_of_participants C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 241
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 263
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 285
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: venue C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 309
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: history C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 333
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 357
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: priority C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 380
ERROR - 2015-12-24 06:55:50 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 400
ERROR - 2015-12-24 06:59:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 07:00:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 1268
ERROR - 2015-12-24 07:00:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 96
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 109
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 114
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 116
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: announcement_name C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 132
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 153
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 178
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: announcement_date C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 196
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: fees C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 218
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: no_of_participants C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 241
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 263
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 285
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: venue C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 309
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: history C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 333
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 357
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: priority C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 380
ERROR - 2015-12-24 07:00:17 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 400
ERROR - 2015-12-24 07:00:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 07:00:25 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 07:00:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 07:00:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 96
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 109
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 114
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 116
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: announcement_name C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 132
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 153
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 178
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: announcement_date C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 196
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: fees C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 218
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: no_of_participants C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 241
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 263
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 285
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: venue C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 309
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: history C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 333
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 357
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: priority C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 380
ERROR - 2015-12-24 07:00:30 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 400
ERROR - 2015-12-24 08:51:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 96
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 109
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 113
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 113
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 114
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 116
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: event_name C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 132
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 153
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 178
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: event_date C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 196
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: fees C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 218
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: no_of_participants C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 241
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 263
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 285
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: venue C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 309
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: history C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 333
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 357
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: priority C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 380
ERROR - 2015-12-24 08:51:32 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 400
ERROR - 2015-12-24 08:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 08:56:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 1070
ERROR - 2015-12-24 08:56:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 96
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 109
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 113
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 113
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 114
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 116
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: event_name C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 132
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 153
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 178
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: event_date C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 196
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: fees C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 218
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: no_of_participants C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 241
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 263
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 285
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: venue C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 309
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: history C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 333
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 357
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: priority C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 380
ERROR - 2015-12-24 08:56:10 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 400
ERROR - 2015-12-24 08:56:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 08:56:29 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 113
ERROR - 2015-12-24 08:56:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 08:56:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 96
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 109
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 113
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 113
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 114
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 116
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: event_name C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 132
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 153
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 178
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: event_date C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 196
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: fees C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 218
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: no_of_participants C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 241
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 263
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 285
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: venue C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 309
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: history C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 333
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 357
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: priority C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 380
ERROR - 2015-12-24 08:56:34 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 400
ERROR - 2015-12-24 08:56:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 08:57:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 1070
ERROR - 2015-12-24 08:57:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 96
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 109
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 113
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 113
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 114
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 116
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: event_name C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 132
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 153
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 178
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: event_date C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 196
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: fees C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 218
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: no_of_participants C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 241
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 263
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 285
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: venue C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 309
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: history C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 333
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 357
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: priority C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 380
ERROR - 2015-12-24 08:57:42 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\events\eventsmanage.php 400
ERROR - 2015-12-24 10:49:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 10:49:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 96
ERROR - 2015-12-24 10:49:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 109
ERROR - 2015-12-24 10:49:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 113
ERROR - 2015-12-24 10:49:04 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 113
ERROR - 2015-12-24 10:49:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 114
ERROR - 2015-12-24 10:49:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 116
ERROR - 2015-12-24 10:49:04 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 132
ERROR - 2015-12-24 10:49:04 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 153
ERROR - 2015-12-24 10:49:04 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 178
ERROR - 2015-12-24 10:49:04 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 196
ERROR - 2015-12-24 10:49:04 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 218
ERROR - 2015-12-24 10:49:04 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 242
ERROR - 2015-12-24 10:49:04 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 262
ERROR - 2015-12-24 11:06:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 11:07:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 11:07:01 --> Severity: Notice  --> Undefined index: extension C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 511
ERROR - 2015-12-24 11:07:01 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 512
ERROR - 2015-12-24 11:07:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 11:07:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 96
ERROR - 2015-12-24 11:07:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 109
ERROR - 2015-12-24 11:07:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 113
ERROR - 2015-12-24 11:07:01 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 113
ERROR - 2015-12-24 11:07:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 114
ERROR - 2015-12-24 11:07:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 116
ERROR - 2015-12-24 11:07:01 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 132
ERROR - 2015-12-24 11:07:01 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 153
ERROR - 2015-12-24 11:07:01 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 178
ERROR - 2015-12-24 11:07:01 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 196
ERROR - 2015-12-24 11:07:01 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 218
ERROR - 2015-12-24 11:07:01 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 242
ERROR - 2015-12-24 11:07:01 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 262
ERROR - 2015-12-24 11:08:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 11:09:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 11:09:03 --> Severity: Notice  --> Undefined index: extension C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 511
ERROR - 2015-12-24 11:09:03 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 512
ERROR - 2015-12-24 11:09:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 11:09:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 96
ERROR - 2015-12-24 11:09:03 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 109
ERROR - 2015-12-24 11:09:03 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 113
ERROR - 2015-12-24 11:09:03 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 113
ERROR - 2015-12-24 11:09:03 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 114
ERROR - 2015-12-24 11:09:03 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 116
ERROR - 2015-12-24 11:09:03 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 132
ERROR - 2015-12-24 11:09:03 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 153
ERROR - 2015-12-24 11:09:03 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 178
ERROR - 2015-12-24 11:09:03 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 196
ERROR - 2015-12-24 11:09:03 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 218
ERROR - 2015-12-24 11:09:03 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 242
ERROR - 2015-12-24 11:09:03 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 262
ERROR - 2015-12-24 13:19:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:19:30 --> Severity: Warning  --> include(C:\xampp\htdocs\tourism\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\tourism\admin\application\views\v_main.php 144
ERROR - 2015-12-24 13:19:30 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\tourism\admin\application\views\v_main.php 144
ERROR - 2015-12-24 13:20:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:20:25 --> Severity: Warning  --> include(C:\xampp\htdocs\tourism\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\tourism\admin\application\views\v_main.php 144
ERROR - 2015-12-24 13:20:25 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\tourism\admin\application\views\v_main.php 144
ERROR - 2015-12-24 13:22:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:22:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 47
ERROR - 2015-12-24 13:22:34 --> Severity: Notice  --> Undefined variable: country_name C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 58
ERROR - 2015-12-24 13:23:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:23:27 --> Severity: Warning  --> include(C:\xampp\htdocs\tourism\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\tourism\admin\application\views\v_main.php 144
ERROR - 2015-12-24 13:23:27 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\tourism\admin\application\views\v_main.php 144
ERROR - 2015-12-24 13:28:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:28:44 --> Severity: Warning  --> include(C:\xampp\htdocs\tourism\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\tourism\admin\application\views\v_main.php 144
ERROR - 2015-12-24 13:28:44 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\tourism\admin\application\views\v_main.php 144
ERROR - 2015-12-24 13:29:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:30:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:32:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:32:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:32:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:33:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:35:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:37:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:37:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:37:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:38:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:38:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:41:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:41:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:41:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:42:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:50:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:51:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:51:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:51:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:51:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:53:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:53:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:53:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 13:53:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 14:01:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 14:05:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 14:06:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 14:06:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 14:06:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 14:07:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 14:07:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 14:07:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 14:07:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 14:08:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 14:42:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 15:27:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 15:33:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 15:42:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 15:42:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-24 15:42:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
