<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-08 07:46:59 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-09-08 07:47:06 --> Severity: Warning  --> include(C:\xampp\htdocs\classfeverevent\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\classfeverevent\admin\application\views\v_main.php 146
ERROR - 2015-09-08 07:47:06 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\classfeverevent\admin\application\views\v_main.php 146
ERROR - 2015-09-08 07:47:35 --> Severity: Notice  --> Undefined index: attendance C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 285
ERROR - 2015-09-08 07:47:35 --> Severity: Notice  --> Undefined index: attendance C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 291
ERROR - 2015-09-08 07:47:35 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 400
ERROR - 2015-09-08 07:47:36 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 400
ERROR - 2015-09-08 07:47:36 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 400
ERROR - 2015-09-08 07:47:36 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 400
ERROR - 2015-09-08 07:47:36 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 400
ERROR - 2015-09-08 07:47:36 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 400
ERROR - 2015-09-08 07:47:36 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 400
ERROR - 2015-09-08 07:47:36 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 400
ERROR - 2015-09-08 07:47:36 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 400
ERROR - 2015-09-08 07:47:36 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 400
ERROR - 2015-09-08 07:47:36 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 400
ERROR - 2015-09-08 07:47:36 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 400
ERROR - 2015-09-08 07:47:36 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 400
ERROR - 2015-09-08 07:47:37 --> Severity: Notice  --> Undefined index: attendance C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 285
ERROR - 2015-09-08 07:47:37 --> Severity: Notice  --> Undefined index: attendance C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 291
