<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-13 14:40:34 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-02-13 14:51:05 --> Severity: Notice  --> Undefined variable: photo /home/fishwqrb/public_html/admin/application/views/category/categorymanage.php 77
ERROR - 2016-02-13 14:51:05 --> Severity: Notice  --> Undefined variable: photo /home/fishwqrb/public_html/admin/application/views/category/categorymanage.php 81
ERROR - 2016-02-13 14:51:05 --> Severity: Notice  --> Undefined variable: disable /home/fishwqrb/public_html/admin/application/views/category/categorymanage.php 81
ERROR - 2016-02-13 14:51:05 --> Severity: Notice  --> Undefined variable: photo /home/fishwqrb/public_html/admin/application/views/category/categorymanage.php 82
ERROR - 2016-02-13 14:51:05 --> Severity: Notice  --> Undefined variable: photo /home/fishwqrb/public_html/admin/application/views/category/categorymanage.php 84
ERROR - 2016-02-13 14:51:05 --> Severity: Notice  --> Undefined variable: id /home/fishwqrb/public_html/admin/application/views/category/categorymanage.php 103
ERROR - 2016-02-13 14:51:05 --> Severity: Notice  --> Undefined variable: category_name /home/fishwqrb/public_html/admin/application/views/category/categorymanage.php 114
