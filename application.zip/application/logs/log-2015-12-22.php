<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-22 13:47:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 13:47:02 --> 404 Page Not Found --> edulocation
ERROR - 2015-12-22 13:47:35 --> 404 Page Not Found --> edulocation
ERROR - 2015-12-22 13:47:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 13:47:52 --> 404 Page Not Found --> edulocation
ERROR - 2015-12-22 13:48:13 --> 404 Page Not Found --> edulocation
ERROR - 2015-12-22 13:48:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 13:48:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 13:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 13:52:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 13:52:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 13:52:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 13:52:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 13:52:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 13:52:31 --> Severity: Warning  --> include(C:\xampp\htdocs\tourism\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\tourism\admin\application\views\v_main.php 142
ERROR - 2015-12-22 13:52:31 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\tourism\admin\application\views\v_main.php 142
ERROR - 2015-12-22 13:52:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 13:52:52 --> Severity: Warning  --> include(C:\xampp\htdocs\tourism\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\tourism\admin\application\views\v_main.php 137
ERROR - 2015-12-22 13:52:52 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\tourism\admin\application\views\v_main.php 137
ERROR - 2015-12-22 13:52:58 --> 404 Page Not Found --> edulocation
ERROR - 2015-12-22 13:53:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 13:53:19 --> Severity: Warning  --> include(C:\xampp\htdocs\tourism\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\tourism\admin\application\views\v_main.php 137
ERROR - 2015-12-22 13:53:19 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\tourism\admin\application\views\v_main.php 137
ERROR - 2015-12-22 13:53:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 13:53:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 13:53:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 13:53:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 13:53:30 --> Severity: Warning  --> include(C:\xampp\htdocs\tourism\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\tourism\admin\application\views\v_main.php 137
ERROR - 2015-12-22 13:53:30 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\tourism\admin\application\views\v_main.php 137
ERROR - 2015-12-22 13:55:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 13:55:40 --> Severity: Warning  --> include(C:\xampp\htdocs\tourism\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\tourism\admin\application\views\v_main.php 139
ERROR - 2015-12-22 13:55:40 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\tourism\admin\application\views\v_main.php 139
ERROR - 2015-12-22 14:00:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:00:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 47
ERROR - 2015-12-22 14:00:52 --> Severity: Notice  --> Undefined variable: country_name C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 58
ERROR - 2015-12-22 14:00:52 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:00:52 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:00:52 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:01:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:01:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 47
ERROR - 2015-12-22 14:01:23 --> Severity: Notice  --> Undefined variable: country_name C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 58
ERROR - 2015-12-22 14:01:23 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:01:23 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:01:23 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:01:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:01:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:01:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 47
ERROR - 2015-12-22 14:01:27 --> Severity: Notice  --> Undefined variable: country_name C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 58
ERROR - 2015-12-22 14:01:27 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:01:27 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:01:27 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:01:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:01:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:01:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 47
ERROR - 2015-12-22 14:01:30 --> Severity: Notice  --> Undefined variable: country_name C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 58
ERROR - 2015-12-22 14:01:30 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:01:30 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:01:30 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:01:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:01:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:01:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 47
ERROR - 2015-12-22 14:01:39 --> Severity: Notice  --> Undefined variable: country_name C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 58
ERROR - 2015-12-22 14:01:39 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:01:39 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:01:39 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:02:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:02:15 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 47
ERROR - 2015-12-22 14:02:15 --> Severity: Notice  --> Undefined variable: country_name C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 58
ERROR - 2015-12-22 14:02:15 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:02:15 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:02:15 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:02:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:02:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:02:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 47
ERROR - 2015-12-22 14:02:19 --> Severity: Notice  --> Undefined variable: country_name C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 58
ERROR - 2015-12-22 14:02:19 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:02:19 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:02:19 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:02:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:02:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:02:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 47
ERROR - 2015-12-22 14:02:22 --> Severity: Notice  --> Undefined variable: country_name C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 58
ERROR - 2015-12-22 14:02:22 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:02:22 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:02:22 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:02:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:02:25 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:02:25 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:02:25 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:02:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:02:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 47
ERROR - 2015-12-22 14:02:28 --> Severity: Notice  --> Undefined variable: country_name C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 58
ERROR - 2015-12-22 14:02:28 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:02:28 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:02:28 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:02:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:02:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 47
ERROR - 2015-12-22 14:02:33 --> Severity: Notice  --> Undefined variable: country_name C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 58
ERROR - 2015-12-22 14:02:33 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:02:33 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:02:33 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:12:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:12:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 47
ERROR - 2015-12-22 14:12:50 --> Severity: Notice  --> Undefined variable: country_name C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 58
ERROR - 2015-12-22 14:12:50 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:12:50 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:12:50 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:17:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:17:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 47
ERROR - 2015-12-22 14:17:09 --> Severity: Notice  --> Undefined variable: country_name C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 58
ERROR - 2015-12-22 14:17:09 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:17:09 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:17:09 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:25:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:25:21 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 14:25:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 14:25:21 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 14:25:21 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:25:21 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:25:21 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:25:21 --> Query error: Table 'tourism.category' doesn't exist
ERROR - 2015-12-22 14:25:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:25:30 --> Query error: Table 'tourism.category' doesn't exist
ERROR - 2015-12-22 14:27:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:27:21 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 14:27:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 14:27:21 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 14:27:21 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:27:21 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:27:21 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:27:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:27:27 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 14:27:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 14:27:27 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 14:27:27 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:27:27 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:27:27 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:27:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:27:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:27:31 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 14:27:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 14:27:31 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 14:27:31 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:27:31 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:27:31 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:27:31 --> Severity: Notice  --> Undefined variable: statename C:\xampp\htdocs\tourism\admin\application\views\category\categorygrid.php 78
ERROR - 2015-12-22 14:29:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:29:10 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 14:29:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 14:29:10 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 14:29:10 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:29:10 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:29:10 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:29:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:29:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:29:22 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 14:29:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 14:29:22 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 14:29:22 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:29:22 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:29:22 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:29:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:29:24 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:29:24 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:29:24 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:29:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:29:27 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:29:27 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:29:27 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:29:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:29:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:29:30 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 14:29:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 14:29:30 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 14:29:30 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:29:30 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:29:30 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:29:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:29:34 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:29:34 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:29:34 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:29:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:29:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:29:37 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 14:29:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 14:29:37 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 14:29:37 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:29:37 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:29:37 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:29:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:29:39 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:29:39 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:29:39 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:29:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:29:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:29:43 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 14:29:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 14:29:43 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 14:29:43 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:29:43 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:29:43 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:29:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:29:46 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:29:46 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:29:46 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:29:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:29:49 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:29:49 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:29:49 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:29:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:29:55 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 14:29:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 14:29:55 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 14:29:55 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:29:55 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:29:55 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:29:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:30:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:30:00 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 14:30:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 14:30:00 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 14:30:00 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:30:00 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:30:00 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:30:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:30:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:30:04 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 14:30:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 14:30:04 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 14:30:04 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:30:04 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:30:04 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:30:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:30:07 --> 404 Page Not Found --> tourism/companymanage
ERROR - 2015-12-22 14:36:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:36:30 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 41
ERROR - 2015-12-22 14:36:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 62
ERROR - 2015-12-22 14:36:30 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 73
ERROR - 2015-12-22 14:36:30 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:36:30 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:36:30 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:36:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:36:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:36:41 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 41
ERROR - 2015-12-22 14:36:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 62
ERROR - 2015-12-22 14:36:41 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 73
ERROR - 2015-12-22 14:36:41 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:36:41 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:36:41 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:36:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:36:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:36:45 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 41
ERROR - 2015-12-22 14:36:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 62
ERROR - 2015-12-22 14:36:45 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 73
ERROR - 2015-12-22 14:36:45 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:36:45 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:36:45 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:36:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:36:49 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:36:49 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:36:49 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:36:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:36:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:36:53 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 41
ERROR - 2015-12-22 14:36:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 62
ERROR - 2015-12-22 14:36:53 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 73
ERROR - 2015-12-22 14:36:53 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:36:53 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:36:53 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:36:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:36:57 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:36:57 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:36:57 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:37:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:37:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:37:01 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 41
ERROR - 2015-12-22 14:37:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 62
ERROR - 2015-12-22 14:37:01 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 73
ERROR - 2015-12-22 14:37:01 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:37:01 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:37:01 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:37:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:37:03 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:37:03 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:37:03 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:37:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:37:06 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:37:06 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:37:06 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:37:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:37:08 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 41
ERROR - 2015-12-22 14:37:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 62
ERROR - 2015-12-22 14:37:08 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 73
ERROR - 2015-12-22 14:37:08 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:37:08 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:37:08 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:37:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:37:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:37:13 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 41
ERROR - 2015-12-22 14:37:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 62
ERROR - 2015-12-22 14:37:13 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 73
ERROR - 2015-12-22 14:37:13 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:37:13 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:37:13 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:37:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:37:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:37:16 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 41
ERROR - 2015-12-22 14:37:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 62
ERROR - 2015-12-22 14:37:16 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 73
ERROR - 2015-12-22 14:37:16 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:37:16 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:37:16 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:42:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:42:38 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 47
ERROR - 2015-12-22 14:42:38 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 58
ERROR - 2015-12-22 14:42:38 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 14:42:38 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:42:38 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:42:38 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:45:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:45:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 47
ERROR - 2015-12-22 14:45:23 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 58
ERROR - 2015-12-22 14:45:23 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 14:45:23 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:45:23 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:45:23 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:46:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:46:11 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 14:46:11 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 51
ERROR - 2015-12-22 14:46:11 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 69
ERROR - 2015-12-22 14:46:11 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:46:11 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:46:11 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:47:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:47:11 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 14:47:11 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 14:47:11 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 75
ERROR - 2015-12-22 14:47:11 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 95
ERROR - 2015-12-22 14:47:11 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:47:11 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:47:11 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:47:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:47:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 14:47:56 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 14:47:56 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 75
ERROR - 2015-12-22 14:47:56 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 95
ERROR - 2015-12-22 14:47:56 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:47:56 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:47:56 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:48:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:48:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 14:48:46 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 14:48:46 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 14:48:46 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 14:48:46 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:48:46 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:48:46 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:49:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:49:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 14:49:43 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 14:49:43 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 14:49:43 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 14:49:43 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 114
ERROR - 2015-12-22 14:49:43 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:49:43 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:49:43 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:50:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:50:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 14:50:00 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 14:50:00 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 14:50:00 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 14:50:00 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 114
ERROR - 2015-12-22 14:51:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:51:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 14:51:57 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 14:51:57 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 14:51:57 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 14:51:57 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 113
ERROR - 2015-12-22 14:51:57 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:51:57 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:51:57 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:53:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:53:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 14:53:21 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 14:53:21 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 14:53:21 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 14:53:21 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 115
ERROR - 2015-12-22 14:53:21 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:53:21 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:53:21 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:53:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:53:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 14:53:25 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 14:53:25 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 14:53:25 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 14:53:25 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 115
ERROR - 2015-12-22 14:53:25 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:53:25 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:53:25 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:53:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:53:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 14:53:47 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 14:53:47 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 14:53:47 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 14:53:47 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 115
ERROR - 2015-12-22 14:53:47 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:53:47 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:53:47 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:54:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:54:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 14:54:09 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 14:54:09 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 14:54:09 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 14:54:09 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 115
ERROR - 2015-12-22 14:54:09 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:54:09 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:54:09 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:55:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:55:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 14:55:00 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 14:55:00 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 14:55:00 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 14:55:00 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 115
ERROR - 2015-12-22 14:55:00 --> Severity: Notice  --> Undefined variable: contact_no C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 137
ERROR - 2015-12-22 14:55:00 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:55:00 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:55:00 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:55:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:55:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 14:55:52 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 14:55:52 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 14:55:52 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 14:55:52 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 115
ERROR - 2015-12-22 14:55:52 --> Severity: Notice  --> Undefined variable: contact_no C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 137
ERROR - 2015-12-22 14:55:52 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:55:52 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:55:52 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:56:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:56:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 14:56:22 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 14:56:22 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 14:56:22 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 14:56:22 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 115
ERROR - 2015-12-22 14:56:22 --> Severity: Notice  --> Undefined variable: contact_no C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 137
ERROR - 2015-12-22 14:56:22 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:56:22 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:56:22 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 14:58:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 14:58:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 14:58:03 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 14:58:03 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 14:58:03 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 14:58:03 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 115
ERROR - 2015-12-22 14:58:03 --> Severity: Notice  --> Undefined variable: contact_no C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 137
ERROR - 2015-12-22 14:58:03 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 14:58:03 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 14:58:03 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 15:01:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 15:01:11 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 15:01:11 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 15:01:11 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 15:01:11 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 15:01:11 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 115
ERROR - 2015-12-22 15:01:11 --> Severity: Notice  --> Undefined variable: contact_no C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 137
ERROR - 2015-12-22 15:01:11 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 15:01:11 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 15:01:11 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 15:01:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 15:01:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 15:01:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 15:01:48 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 15:01:48 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 15:01:48 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 15:01:48 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 115
ERROR - 2015-12-22 15:01:48 --> Severity: Notice  --> Undefined variable: contact_no C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 137
ERROR - 2015-12-22 15:01:48 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 15:01:48 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 15:01:48 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 15:02:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 15:02:10 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 15:02:10 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 15:02:10 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 15:02:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 15:02:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 15:02:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 15:02:16 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 15:02:16 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 15:02:16 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 15:02:16 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 115
ERROR - 2015-12-22 15:02:16 --> Severity: Notice  --> Undefined variable: contact_no C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 137
ERROR - 2015-12-22 15:02:16 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 15:02:16 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 15:02:16 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 15:02:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 15:02:20 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 15:02:20 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 15:02:20 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 15:02:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 15:02:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 15:02:22 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 15:02:22 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 15:02:22 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 15:02:22 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 115
ERROR - 2015-12-22 15:02:22 --> Severity: Notice  --> Undefined variable: contact_no C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 137
ERROR - 2015-12-22 15:02:22 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 15:02:22 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 15:02:22 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 15:02:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 15:02:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 15:02:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 15:02:27 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 15:02:27 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 15:02:27 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 15:02:27 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 115
ERROR - 2015-12-22 15:02:27 --> Severity: Notice  --> Undefined variable: contact_no C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 137
ERROR - 2015-12-22 15:02:27 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 15:02:27 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 15:02:27 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 15:05:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 15:05:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 33
ERROR - 2015-12-22 15:05:16 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 53
ERROR - 2015-12-22 15:05:16 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 76
ERROR - 2015-12-22 15:05:16 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 96
ERROR - 2015-12-22 15:05:16 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 115
ERROR - 2015-12-22 15:05:16 --> Severity: Notice  --> Undefined variable: contact_no C:\xampp\htdocs\tourism\admin\application\views\company\companymanage.php 137
ERROR - 2015-12-22 15:05:16 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 15:05:16 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 15:05:16 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 15:47:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 15:47:37 --> 404 Page Not Found --> tourism/newsmanage
ERROR - 2015-12-22 15:56:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 15:56:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 33
ERROR - 2015-12-22 15:56:22 --> Severity: Notice  --> Undefined variable: news_name C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 53
ERROR - 2015-12-22 15:56:22 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 75
ERROR - 2015-12-22 15:56:22 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 15:56:22 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 119
ERROR - 2015-12-22 15:56:22 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 134
ERROR - 2015-12-22 15:56:22 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 151
ERROR - 2015-12-22 15:56:22 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 173
ERROR - 2015-12-22 15:56:22 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 15:56:22 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 15:56:22 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 15:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 15:57:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 33
ERROR - 2015-12-22 15:57:14 --> Severity: Notice  --> Undefined variable: news_name C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 53
ERROR - 2015-12-22 15:57:14 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 75
ERROR - 2015-12-22 15:57:14 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 96
ERROR - 2015-12-22 15:57:14 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 111
ERROR - 2015-12-22 15:57:14 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 128
ERROR - 2015-12-22 15:57:14 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 150
ERROR - 2015-12-22 15:57:14 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 174
ERROR - 2015-12-22 15:57:14 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 15:57:14 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 15:57:14 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 15:59:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 15:59:38 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 33
ERROR - 2015-12-22 15:59:38 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 46
ERROR - 2015-12-22 15:59:38 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 50
ERROR - 2015-12-22 15:59:38 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 50
ERROR - 2015-12-22 15:59:38 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 51
ERROR - 2015-12-22 15:59:38 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 53
ERROR - 2015-12-22 15:59:38 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 69
ERROR - 2015-12-22 15:59:38 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 90
ERROR - 2015-12-22 15:59:38 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 105
ERROR - 2015-12-22 15:59:38 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 122
ERROR - 2015-12-22 15:59:38 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 144
ERROR - 2015-12-22 15:59:38 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 168
ERROR - 2015-12-22 15:59:38 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 15:59:38 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 15:59:38 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:05:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:05:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 63
ERROR - 2015-12-22 16:05:49 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 76
ERROR - 2015-12-22 16:05:49 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:05:49 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:05:49 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 81
ERROR - 2015-12-22 16:05:49 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 83
ERROR - 2015-12-22 16:05:49 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:05:49 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 120
ERROR - 2015-12-22 16:05:49 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 135
ERROR - 2015-12-22 16:05:49 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 152
ERROR - 2015-12-22 16:05:49 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 174
ERROR - 2015-12-22 16:05:49 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 198
ERROR - 2015-12-22 16:05:49 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:05:49 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:05:49 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:09:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:09:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 63
ERROR - 2015-12-22 16:09:22 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 76
ERROR - 2015-12-22 16:09:22 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:09:22 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:09:22 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 81
ERROR - 2015-12-22 16:09:22 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 83
ERROR - 2015-12-22 16:09:22 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:09:22 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 120
ERROR - 2015-12-22 16:09:22 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 135
ERROR - 2015-12-22 16:09:22 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 152
ERROR - 2015-12-22 16:09:22 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 174
ERROR - 2015-12-22 16:09:22 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 198
ERROR - 2015-12-22 16:09:22 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:09:22 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:09:22 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:10:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:10:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 63
ERROR - 2015-12-22 16:10:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 76
ERROR - 2015-12-22 16:10:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:10:04 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:10:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 81
ERROR - 2015-12-22 16:10:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 83
ERROR - 2015-12-22 16:10:04 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:10:04 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 120
ERROR - 2015-12-22 16:10:04 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 135
ERROR - 2015-12-22 16:10:04 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 152
ERROR - 2015-12-22 16:10:04 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 174
ERROR - 2015-12-22 16:10:04 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 198
ERROR - 2015-12-22 16:10:04 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:10:04 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:10:04 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:10:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:10:57 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 498
ERROR - 2015-12-22 16:10:57 --> Severity: Notice  --> Undefined index: title C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 466
ERROR - 2015-12-22 16:10:57 --> Severity: Notice  --> Undefined index: category_id C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 469
ERROR - 2015-12-22 16:10:57 --> Severity: Notice  --> Undefined index: startdate C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 470
ERROR - 2015-12-22 16:10:57 --> Severity: Notice  --> Undefined index: enddate C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 471
ERROR - 2015-12-22 16:10:57 --> Query error: Unknown column 'country_id' in 'field list'
ERROR - 2015-12-22 16:12:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:12:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 63
ERROR - 2015-12-22 16:12:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 76
ERROR - 2015-12-22 16:12:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:12:07 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:12:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 81
ERROR - 2015-12-22 16:12:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 83
ERROR - 2015-12-22 16:12:07 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:12:07 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 120
ERROR - 2015-12-22 16:12:07 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 135
ERROR - 2015-12-22 16:12:07 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 152
ERROR - 2015-12-22 16:12:07 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 174
ERROR - 2015-12-22 16:12:07 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 198
ERROR - 2015-12-22 16:12:07 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:12:07 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:12:07 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:12:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:12:47 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 498
ERROR - 2015-12-22 16:12:47 --> Query error: Unknown column 'country_id' in 'field list'
ERROR - 2015-12-22 16:14:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:14:37 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 498
ERROR - 2015-12-22 16:14:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:14:38 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 63
ERROR - 2015-12-22 16:14:38 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 76
ERROR - 2015-12-22 16:14:38 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:14:38 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:14:38 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 81
ERROR - 2015-12-22 16:14:38 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 83
ERROR - 2015-12-22 16:14:38 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:14:38 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 120
ERROR - 2015-12-22 16:14:38 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 135
ERROR - 2015-12-22 16:14:38 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 152
ERROR - 2015-12-22 16:14:38 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 174
ERROR - 2015-12-22 16:14:38 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 198
ERROR - 2015-12-22 16:14:38 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:14:38 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:14:38 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:15:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:15:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 63
ERROR - 2015-12-22 16:15:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 76
ERROR - 2015-12-22 16:15:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:15:01 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:15:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 81
ERROR - 2015-12-22 16:15:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 83
ERROR - 2015-12-22 16:15:01 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:15:01 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 120
ERROR - 2015-12-22 16:15:01 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 135
ERROR - 2015-12-22 16:15:01 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 152
ERROR - 2015-12-22 16:15:01 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 174
ERROR - 2015-12-22 16:15:01 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 198
ERROR - 2015-12-22 16:15:01 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:15:01 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:15:01 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:15:01 --> Severity: Notice  --> Undefined variable: categoryname C:\xampp\htdocs\tourism\admin\application\views\news\newsgrid.php 95
ERROR - 2015-12-22 16:15:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:15:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:15:15 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 63
ERROR - 2015-12-22 16:15:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 76
ERROR - 2015-12-22 16:15:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:15:15 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:15:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 81
ERROR - 2015-12-22 16:15:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 83
ERROR - 2015-12-22 16:15:15 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:15:15 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 120
ERROR - 2015-12-22 16:15:15 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 135
ERROR - 2015-12-22 16:15:15 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 152
ERROR - 2015-12-22 16:15:15 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 174
ERROR - 2015-12-22 16:15:15 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 198
ERROR - 2015-12-22 16:15:15 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:15:15 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:15:15 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:15:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:15:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 63
ERROR - 2015-12-22 16:15:30 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 76
ERROR - 2015-12-22 16:15:30 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:15:30 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:15:30 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 81
ERROR - 2015-12-22 16:15:30 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 83
ERROR - 2015-12-22 16:15:30 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:15:30 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 120
ERROR - 2015-12-22 16:15:30 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 135
ERROR - 2015-12-22 16:15:30 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 152
ERROR - 2015-12-22 16:15:30 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 174
ERROR - 2015-12-22 16:15:30 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 198
ERROR - 2015-12-22 16:15:30 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:15:30 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:15:30 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:16:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:16:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 63
ERROR - 2015-12-22 16:16:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 76
ERROR - 2015-12-22 16:16:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:16:56 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 80
ERROR - 2015-12-22 16:16:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 81
ERROR - 2015-12-22 16:16:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 83
ERROR - 2015-12-22 16:16:56 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:16:56 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 120
ERROR - 2015-12-22 16:16:56 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 135
ERROR - 2015-12-22 16:16:56 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 152
ERROR - 2015-12-22 16:16:56 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 174
ERROR - 2015-12-22 16:16:56 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 198
ERROR - 2015-12-22 16:16:56 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:16:56 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:16:56 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:22:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:22:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 74
ERROR - 2015-12-22 16:22:31 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 87
ERROR - 2015-12-22 16:22:31 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 91
ERROR - 2015-12-22 16:22:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 91
ERROR - 2015-12-22 16:22:31 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 92
ERROR - 2015-12-22 16:22:31 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 94
ERROR - 2015-12-22 16:22:31 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 110
ERROR - 2015-12-22 16:22:31 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 131
ERROR - 2015-12-22 16:22:31 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 156
ERROR - 2015-12-22 16:22:31 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 174
ERROR - 2015-12-22 16:22:31 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 196
ERROR - 2015-12-22 16:22:31 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 220
ERROR - 2015-12-22 16:22:31 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:22:31 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:22:31 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:22:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:22:37 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 16:22:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 16:22:37 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 16:22:37 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:22:37 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:22:37 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:22:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:22:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:22:57 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 16:22:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 16:22:57 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 16:22:57 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:22:57 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:22:57 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:23:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:23:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:23:02 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 16:23:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 16:23:02 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 16:23:02 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:23:02 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:23:02 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:23:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:23:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:23:12 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 16:23:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 16:23:12 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 16:23:12 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:23:12 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:23:12 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:23:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:23:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:23:17 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 16:23:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 16:23:17 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 16:23:17 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:23:17 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:23:17 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:23:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:23:21 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:23:21 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:23:21 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:23:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:23:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:23:24 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 16:23:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 16:23:24 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 16:23:24 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:23:24 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:23:24 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:23:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:23:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:23:28 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 16:23:28 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 16:23:28 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 16:23:28 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:23:28 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:23:28 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:23:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:23:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 74
ERROR - 2015-12-22 16:23:31 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 87
ERROR - 2015-12-22 16:23:31 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 91
ERROR - 2015-12-22 16:23:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 91
ERROR - 2015-12-22 16:23:31 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 92
ERROR - 2015-12-22 16:23:31 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 94
ERROR - 2015-12-22 16:23:31 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 110
ERROR - 2015-12-22 16:23:31 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 131
ERROR - 2015-12-22 16:23:31 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 156
ERROR - 2015-12-22 16:23:31 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 174
ERROR - 2015-12-22 16:23:31 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 196
ERROR - 2015-12-22 16:23:31 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 220
ERROR - 2015-12-22 16:23:31 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:23:31 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:23:31 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:26:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:26:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 74
ERROR - 2015-12-22 16:26:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 87
ERROR - 2015-12-22 16:26:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 91
ERROR - 2015-12-22 16:26:10 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 91
ERROR - 2015-12-22 16:26:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 92
ERROR - 2015-12-22 16:26:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 94
ERROR - 2015-12-22 16:26:10 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 110
ERROR - 2015-12-22 16:26:10 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 131
ERROR - 2015-12-22 16:26:10 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 156
ERROR - 2015-12-22 16:26:10 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 174
ERROR - 2015-12-22 16:26:10 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 196
ERROR - 2015-12-22 16:26:10 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 220
ERROR - 2015-12-22 16:26:10 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:26:10 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:26:10 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:26:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:26:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 74
ERROR - 2015-12-22 16:26:16 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 87
ERROR - 2015-12-22 16:26:16 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 91
ERROR - 2015-12-22 16:26:16 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 91
ERROR - 2015-12-22 16:26:16 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 92
ERROR - 2015-12-22 16:26:16 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 94
ERROR - 2015-12-22 16:26:16 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 110
ERROR - 2015-12-22 16:26:16 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 131
ERROR - 2015-12-22 16:26:16 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 156
ERROR - 2015-12-22 16:26:16 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 174
ERROR - 2015-12-22 16:26:16 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 196
ERROR - 2015-12-22 16:26:16 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 220
ERROR - 2015-12-22 16:26:16 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:26:16 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:26:16 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:27:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:27:15 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 74
ERROR - 2015-12-22 16:27:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 87
ERROR - 2015-12-22 16:27:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 91
ERROR - 2015-12-22 16:27:15 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 91
ERROR - 2015-12-22 16:27:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 92
ERROR - 2015-12-22 16:27:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 94
ERROR - 2015-12-22 16:27:15 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 110
ERROR - 2015-12-22 16:27:15 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 131
ERROR - 2015-12-22 16:27:15 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 156
ERROR - 2015-12-22 16:27:15 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 174
ERROR - 2015-12-22 16:27:15 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 196
ERROR - 2015-12-22 16:27:15 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 220
ERROR - 2015-12-22 16:27:15 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:27:15 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:27:15 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:27:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:27:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 74
ERROR - 2015-12-22 16:27:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 87
ERROR - 2015-12-22 16:27:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 91
ERROR - 2015-12-22 16:27:52 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 91
ERROR - 2015-12-22 16:27:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 92
ERROR - 2015-12-22 16:27:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 94
ERROR - 2015-12-22 16:27:52 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 110
ERROR - 2015-12-22 16:27:52 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 131
ERROR - 2015-12-22 16:27:52 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 156
ERROR - 2015-12-22 16:27:52 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 174
ERROR - 2015-12-22 16:27:52 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 196
ERROR - 2015-12-22 16:27:52 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 220
ERROR - 2015-12-22 16:27:52 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:27:52 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:27:52 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:28:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:28:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 74
ERROR - 2015-12-22 16:28:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 87
ERROR - 2015-12-22 16:28:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 91
ERROR - 2015-12-22 16:28:07 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 91
ERROR - 2015-12-22 16:28:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 92
ERROR - 2015-12-22 16:28:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 94
ERROR - 2015-12-22 16:28:07 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 110
ERROR - 2015-12-22 16:28:07 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 131
ERROR - 2015-12-22 16:28:07 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 156
ERROR - 2015-12-22 16:28:07 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 174
ERROR - 2015-12-22 16:28:07 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 196
ERROR - 2015-12-22 16:28:07 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 220
ERROR - 2015-12-22 16:28:07 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:28:07 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:28:07 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:28:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:28:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:34:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:34:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 82
ERROR - 2015-12-22 16:34:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 95
ERROR - 2015-12-22 16:34:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:34:17 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:34:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 100
ERROR - 2015-12-22 16:34:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 102
ERROR - 2015-12-22 16:34:17 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 118
ERROR - 2015-12-22 16:34:17 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 139
ERROR - 2015-12-22 16:34:17 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 164
ERROR - 2015-12-22 16:34:17 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:34:17 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:34:17 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:34:17 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:34:17 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:34:17 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:34:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:36:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:36:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 82
ERROR - 2015-12-22 16:36:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 95
ERROR - 2015-12-22 16:36:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:36:14 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:36:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 100
ERROR - 2015-12-22 16:36:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 102
ERROR - 2015-12-22 16:36:14 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 118
ERROR - 2015-12-22 16:36:14 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 139
ERROR - 2015-12-22 16:36:14 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 164
ERROR - 2015-12-22 16:36:14 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:36:14 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:36:14 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:36:14 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:36:14 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:36:14 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:36:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:36:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 82
ERROR - 2015-12-22 16:36:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 95
ERROR - 2015-12-22 16:36:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:36:26 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:36:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 100
ERROR - 2015-12-22 16:36:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 102
ERROR - 2015-12-22 16:36:26 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 118
ERROR - 2015-12-22 16:36:26 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 139
ERROR - 2015-12-22 16:36:26 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 164
ERROR - 2015-12-22 16:36:26 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:36:26 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:36:26 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:36:26 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:36:26 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:36:26 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:37:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:37:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 82
ERROR - 2015-12-22 16:37:43 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 95
ERROR - 2015-12-22 16:37:43 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:37:43 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:37:43 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 100
ERROR - 2015-12-22 16:37:43 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 102
ERROR - 2015-12-22 16:37:43 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 118
ERROR - 2015-12-22 16:37:43 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 139
ERROR - 2015-12-22 16:37:43 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 164
ERROR - 2015-12-22 16:37:43 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:37:43 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:37:43 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:37:43 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:37:43 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:37:43 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:37:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:37:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:37:57 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 510
ERROR - 2015-12-22 16:37:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:37:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 82
ERROR - 2015-12-22 16:37:57 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 95
ERROR - 2015-12-22 16:37:57 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:37:57 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:37:57 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 100
ERROR - 2015-12-22 16:37:57 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 102
ERROR - 2015-12-22 16:37:57 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 118
ERROR - 2015-12-22 16:37:57 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 139
ERROR - 2015-12-22 16:37:57 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 164
ERROR - 2015-12-22 16:37:57 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:37:57 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:37:57 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:37:57 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:37:57 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:37:57 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:38:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:38:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 82
ERROR - 2015-12-22 16:38:49 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 95
ERROR - 2015-12-22 16:38:49 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:38:49 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:38:49 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 100
ERROR - 2015-12-22 16:38:49 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 102
ERROR - 2015-12-22 16:38:49 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 118
ERROR - 2015-12-22 16:38:49 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 139
ERROR - 2015-12-22 16:38:49 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 164
ERROR - 2015-12-22 16:38:49 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:38:49 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:38:49 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:38:49 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:38:49 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:38:49 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:39:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:39:03 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:39:03 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:39:03 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:39:03 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:39:03 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:39:03 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:39:03 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:39:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:39:09 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:39:09 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:39:09 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:39:09 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:39:09 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:39:09 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:39:09 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:40:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:40:06 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:40:06 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:40:06 --> Severity: Notice  --> Undefined variable: email_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:40:06 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:40:06 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:40:06 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:40:06 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:40:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:40:41 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:40:41 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:40:41 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:40:41 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:40:41 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:41:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:41:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:41:09 --> Query error: Table 'tourism.events' doesn't exist
ERROR - 2015-12-22 16:41:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:41:42 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 510
ERROR - 2015-12-22 16:41:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:41:42 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 82
ERROR - 2015-12-22 16:41:42 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 95
ERROR - 2015-12-22 16:41:42 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:41:42 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:41:42 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 100
ERROR - 2015-12-22 16:41:42 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 102
ERROR - 2015-12-22 16:41:42 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 118
ERROR - 2015-12-22 16:41:42 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 139
ERROR - 2015-12-22 16:41:42 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 164
ERROR - 2015-12-22 16:41:42 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:41:42 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:41:42 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:41:42 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:41:42 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:41:42 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:42:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:42:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 82
ERROR - 2015-12-22 16:42:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 95
ERROR - 2015-12-22 16:42:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:42:07 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:42:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 100
ERROR - 2015-12-22 16:42:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 102
ERROR - 2015-12-22 16:42:07 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 118
ERROR - 2015-12-22 16:42:07 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 139
ERROR - 2015-12-22 16:42:07 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 164
ERROR - 2015-12-22 16:42:07 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:42:07 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:42:07 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:42:07 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:42:07 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:42:07 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:42:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:42:10 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:42:10 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:42:10 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:42:10 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:42:10 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:42:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:42:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 82
ERROR - 2015-12-22 16:42:16 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 95
ERROR - 2015-12-22 16:42:16 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:42:16 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:42:16 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 100
ERROR - 2015-12-22 16:42:16 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 102
ERROR - 2015-12-22 16:42:16 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 118
ERROR - 2015-12-22 16:42:16 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 139
ERROR - 2015-12-22 16:42:16 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 164
ERROR - 2015-12-22 16:42:16 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:42:16 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:42:16 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:42:16 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:42:16 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:42:16 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:43:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:43:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 82
ERROR - 2015-12-22 16:43:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 95
ERROR - 2015-12-22 16:43:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:43:04 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:43:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 100
ERROR - 2015-12-22 16:43:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 102
ERROR - 2015-12-22 16:43:04 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 118
ERROR - 2015-12-22 16:43:04 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 139
ERROR - 2015-12-22 16:43:04 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 164
ERROR - 2015-12-22 16:43:04 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:43:04 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:43:04 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:43:04 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:43:04 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:43:04 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:48:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:48:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 82
ERROR - 2015-12-22 16:48:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 95
ERROR - 2015-12-22 16:48:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:48:26 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:48:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 100
ERROR - 2015-12-22 16:48:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 102
ERROR - 2015-12-22 16:48:26 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 118
ERROR - 2015-12-22 16:48:26 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 139
ERROR - 2015-12-22 16:48:26 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 164
ERROR - 2015-12-22 16:48:26 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:48:26 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:48:26 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:48:26 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 248
ERROR - 2015-12-22 16:48:26 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:48:26 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:48:26 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:49:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:49:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 82
ERROR - 2015-12-22 16:49:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 95
ERROR - 2015-12-22 16:49:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:49:44 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:49:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 100
ERROR - 2015-12-22 16:49:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 102
ERROR - 2015-12-22 16:49:44 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 118
ERROR - 2015-12-22 16:49:44 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 139
ERROR - 2015-12-22 16:49:44 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 164
ERROR - 2015-12-22 16:49:44 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:49:44 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:49:44 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:49:44 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 248
ERROR - 2015-12-22 16:49:44 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:49:44 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:49:44 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:49:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:49:47 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:49:47 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:49:47 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:49:47 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:49:47 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:50:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:50:02 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:50:02 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:50:02 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:50:02 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:50:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:50:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:50:05 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 82
ERROR - 2015-12-22 16:50:05 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 95
ERROR - 2015-12-22 16:50:05 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:50:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:50:05 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 100
ERROR - 2015-12-22 16:50:05 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 102
ERROR - 2015-12-22 16:50:05 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 118
ERROR - 2015-12-22 16:50:05 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 139
ERROR - 2015-12-22 16:50:05 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 164
ERROR - 2015-12-22 16:50:05 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:50:05 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:50:05 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:50:05 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 248
ERROR - 2015-12-22 16:50:05 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:50:05 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:50:05 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:50:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 82
ERROR - 2015-12-22 16:50:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 95
ERROR - 2015-12-22 16:50:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:50:32 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:50:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 100
ERROR - 2015-12-22 16:50:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 102
ERROR - 2015-12-22 16:50:32 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 118
ERROR - 2015-12-22 16:50:32 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 139
ERROR - 2015-12-22 16:50:32 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 164
ERROR - 2015-12-22 16:50:32 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:50:32 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:50:32 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:50:32 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 248
ERROR - 2015-12-22 16:50:32 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:50:32 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:50:32 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:54:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:54:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 82
ERROR - 2015-12-22 16:54:19 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 95
ERROR - 2015-12-22 16:54:19 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 99
ERROR - 2015-12-22 16:54:19 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 99
ERROR - 2015-12-22 16:54:19 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 100
ERROR - 2015-12-22 16:54:19 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 102
ERROR - 2015-12-22 16:54:19 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 118
ERROR - 2015-12-22 16:54:19 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 139
ERROR - 2015-12-22 16:54:19 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 164
ERROR - 2015-12-22 16:54:19 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 182
ERROR - 2015-12-22 16:54:19 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 204
ERROR - 2015-12-22 16:54:19 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 228
ERROR - 2015-12-22 16:54:19 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 248
ERROR - 2015-12-22 16:54:19 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:54:19 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:54:19 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:55:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:55:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 82
ERROR - 2015-12-22 16:55:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 95
ERROR - 2015-12-22 16:55:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 99
ERROR - 2015-12-22 16:55:01 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 99
ERROR - 2015-12-22 16:55:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 100
ERROR - 2015-12-22 16:55:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 102
ERROR - 2015-12-22 16:55:01 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 118
ERROR - 2015-12-22 16:55:01 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 139
ERROR - 2015-12-22 16:55:01 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 164
ERROR - 2015-12-22 16:55:01 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 182
ERROR - 2015-12-22 16:55:01 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 204
ERROR - 2015-12-22 16:55:01 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 228
ERROR - 2015-12-22 16:55:01 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 248
ERROR - 2015-12-22 16:55:01 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:55:01 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:55:01 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:55:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:55:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:55:17 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 703
ERROR - 2015-12-22 16:55:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:55:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 82
ERROR - 2015-12-22 16:55:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 95
ERROR - 2015-12-22 16:55:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 99
ERROR - 2015-12-22 16:55:17 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 99
ERROR - 2015-12-22 16:55:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 100
ERROR - 2015-12-22 16:55:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 102
ERROR - 2015-12-22 16:55:17 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 118
ERROR - 2015-12-22 16:55:17 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 139
ERROR - 2015-12-22 16:55:17 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 164
ERROR - 2015-12-22 16:55:17 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 182
ERROR - 2015-12-22 16:55:17 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 204
ERROR - 2015-12-22 16:55:17 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 228
ERROR - 2015-12-22 16:55:17 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 248
ERROR - 2015-12-22 16:55:17 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:55:17 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:55:17 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:55:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:55:21 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 99
ERROR - 2015-12-22 16:55:21 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:55:21 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:55:21 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:55:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:55:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:55:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:55:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 82
ERROR - 2015-12-22 16:55:30 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 95
ERROR - 2015-12-22 16:55:30 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 99
ERROR - 2015-12-22 16:55:30 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 99
ERROR - 2015-12-22 16:55:30 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 100
ERROR - 2015-12-22 16:55:30 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 102
ERROR - 2015-12-22 16:55:30 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 118
ERROR - 2015-12-22 16:55:30 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 139
ERROR - 2015-12-22 16:55:30 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 164
ERROR - 2015-12-22 16:55:30 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 182
ERROR - 2015-12-22 16:55:30 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 204
ERROR - 2015-12-22 16:55:30 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 228
ERROR - 2015-12-22 16:55:30 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 248
ERROR - 2015-12-22 16:55:30 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:55:30 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:55:30 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:55:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:55:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 82
ERROR - 2015-12-22 16:55:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 95
ERROR - 2015-12-22 16:55:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:55:52 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:55:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 100
ERROR - 2015-12-22 16:55:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 102
ERROR - 2015-12-22 16:55:52 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 118
ERROR - 2015-12-22 16:55:52 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 139
ERROR - 2015-12-22 16:55:52 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 164
ERROR - 2015-12-22 16:55:52 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:55:52 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:55:52 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:55:52 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 248
ERROR - 2015-12-22 16:55:52 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:55:52 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:55:52 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:55:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:55:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:55:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 82
ERROR - 2015-12-22 16:55:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 95
ERROR - 2015-12-22 16:55:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:55:56 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 16:55:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 100
ERROR - 2015-12-22 16:55:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 102
ERROR - 2015-12-22 16:55:56 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 118
ERROR - 2015-12-22 16:55:56 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 139
ERROR - 2015-12-22 16:55:56 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 164
ERROR - 2015-12-22 16:55:56 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 16:55:56 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 16:55:56 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 16:55:56 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 248
ERROR - 2015-12-22 16:55:56 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:55:56 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:55:56 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:55:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:55:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 82
ERROR - 2015-12-22 16:55:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 95
ERROR - 2015-12-22 16:55:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 99
ERROR - 2015-12-22 16:55:58 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 99
ERROR - 2015-12-22 16:55:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 100
ERROR - 2015-12-22 16:55:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 102
ERROR - 2015-12-22 16:55:58 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 118
ERROR - 2015-12-22 16:55:58 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 139
ERROR - 2015-12-22 16:55:58 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 164
ERROR - 2015-12-22 16:55:58 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 182
ERROR - 2015-12-22 16:55:58 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 204
ERROR - 2015-12-22 16:55:58 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 228
ERROR - 2015-12-22 16:55:58 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 248
ERROR - 2015-12-22 16:55:58 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:55:58 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:55:58 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:56:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:56:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:56:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 82
ERROR - 2015-12-22 16:56:03 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 95
ERROR - 2015-12-22 16:56:03 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 99
ERROR - 2015-12-22 16:56:03 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 99
ERROR - 2015-12-22 16:56:03 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 100
ERROR - 2015-12-22 16:56:03 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 102
ERROR - 2015-12-22 16:56:03 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 118
ERROR - 2015-12-22 16:56:03 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 139
ERROR - 2015-12-22 16:56:03 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 164
ERROR - 2015-12-22 16:56:03 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 182
ERROR - 2015-12-22 16:56:03 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 204
ERROR - 2015-12-22 16:56:03 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 228
ERROR - 2015-12-22 16:56:03 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 248
ERROR - 2015-12-22 16:56:03 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:56:03 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:56:03 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:57:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:57:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 82
ERROR - 2015-12-22 16:57:50 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 95
ERROR - 2015-12-22 16:57:50 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 99
ERROR - 2015-12-22 16:57:50 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 99
ERROR - 2015-12-22 16:57:50 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 100
ERROR - 2015-12-22 16:57:50 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 102
ERROR - 2015-12-22 16:57:50 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 118
ERROR - 2015-12-22 16:57:50 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 139
ERROR - 2015-12-22 16:57:50 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 164
ERROR - 2015-12-22 16:57:50 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 182
ERROR - 2015-12-22 16:57:50 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 204
ERROR - 2015-12-22 16:57:50 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 228
ERROR - 2015-12-22 16:57:50 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 248
ERROR - 2015-12-22 16:57:50 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:57:50 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:57:50 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:58:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:58:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:58:14 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\tourism\admin\application\controllers\tourism.php 878
ERROR - 2015-12-22 16:58:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:58:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 82
ERROR - 2015-12-22 16:58:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 95
ERROR - 2015-12-22 16:58:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 99
ERROR - 2015-12-22 16:58:14 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 99
ERROR - 2015-12-22 16:58:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 100
ERROR - 2015-12-22 16:58:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 102
ERROR - 2015-12-22 16:58:14 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 118
ERROR - 2015-12-22 16:58:14 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 139
ERROR - 2015-12-22 16:58:14 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 164
ERROR - 2015-12-22 16:58:14 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 182
ERROR - 2015-12-22 16:58:14 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 204
ERROR - 2015-12-22 16:58:14 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 228
ERROR - 2015-12-22 16:58:14 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 248
ERROR - 2015-12-22 16:58:14 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:58:14 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:58:14 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:58:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:58:18 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 99
ERROR - 2015-12-22 16:58:18 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:58:18 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:58:18 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:58:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:58:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:58:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 82
ERROR - 2015-12-22 16:58:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 95
ERROR - 2015-12-22 16:58:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 99
ERROR - 2015-12-22 16:58:21 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 99
ERROR - 2015-12-22 16:58:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 100
ERROR - 2015-12-22 16:58:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 102
ERROR - 2015-12-22 16:58:21 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 118
ERROR - 2015-12-22 16:58:21 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 139
ERROR - 2015-12-22 16:58:21 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 164
ERROR - 2015-12-22 16:58:21 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 182
ERROR - 2015-12-22 16:58:21 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 204
ERROR - 2015-12-22 16:58:21 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 228
ERROR - 2015-12-22 16:58:21 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 248
ERROR - 2015-12-22 16:58:21 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:58:21 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:58:21 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 16:58:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:58:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 16:58:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 82
ERROR - 2015-12-22 16:58:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 95
ERROR - 2015-12-22 16:58:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 99
ERROR - 2015-12-22 16:58:37 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 99
ERROR - 2015-12-22 16:58:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 100
ERROR - 2015-12-22 16:58:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 102
ERROR - 2015-12-22 16:58:37 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 118
ERROR - 2015-12-22 16:58:37 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 139
ERROR - 2015-12-22 16:58:37 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 164
ERROR - 2015-12-22 16:58:37 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 182
ERROR - 2015-12-22 16:58:37 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 204
ERROR - 2015-12-22 16:58:37 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 228
ERROR - 2015-12-22 16:58:37 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 248
ERROR - 2015-12-22 16:58:37 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 16:58:37 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 16:58:37 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 17:00:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 17:00:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 47
ERROR - 2015-12-22 17:00:02 --> Severity: Notice  --> Undefined variable: country_name C:\xampp\htdocs\tourism\admin\application\views\country\countrymanage.php 58
ERROR - 2015-12-22 17:00:02 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 17:00:02 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 17:00:02 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 17:00:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 17:00:06 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 41
ERROR - 2015-12-22 17:00:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 62
ERROR - 2015-12-22 17:00:06 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\tourism\admin\application\views\category\categorymanage.php 73
ERROR - 2015-12-22 17:00:06 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 17:00:06 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 17:00:06 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 17:00:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 17:00:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 82
ERROR - 2015-12-22 17:00:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 95
ERROR - 2015-12-22 17:00:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 17:00:12 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 99
ERROR - 2015-12-22 17:00:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 100
ERROR - 2015-12-22 17:00:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 102
ERROR - 2015-12-22 17:00:12 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 118
ERROR - 2015-12-22 17:00:12 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 139
ERROR - 2015-12-22 17:00:12 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 164
ERROR - 2015-12-22 17:00:12 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 182
ERROR - 2015-12-22 17:00:12 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 204
ERROR - 2015-12-22 17:00:12 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 228
ERROR - 2015-12-22 17:00:12 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\news\newsmanage.php 248
ERROR - 2015-12-22 17:00:12 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 17:00:12 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 17:00:12 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 17:00:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 17:00:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 82
ERROR - 2015-12-22 17:00:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 95
ERROR - 2015-12-22 17:00:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 99
ERROR - 2015-12-22 17:00:13 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 99
ERROR - 2015-12-22 17:00:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 100
ERROR - 2015-12-22 17:00:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 102
ERROR - 2015-12-22 17:00:13 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 118
ERROR - 2015-12-22 17:00:13 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 139
ERROR - 2015-12-22 17:00:13 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 164
ERROR - 2015-12-22 17:00:13 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 182
ERROR - 2015-12-22 17:00:13 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 204
ERROR - 2015-12-22 17:00:13 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 228
ERROR - 2015-12-22 17:00:13 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 248
ERROR - 2015-12-22 17:00:13 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 17:00:13 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 17:00:13 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 17:00:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-22 17:00:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 82
ERROR - 2015-12-22 17:00:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 95
ERROR - 2015-12-22 17:00:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 99
ERROR - 2015-12-22 17:00:14 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 99
ERROR - 2015-12-22 17:00:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 100
ERROR - 2015-12-22 17:00:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 102
ERROR - 2015-12-22 17:00:14 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 118
ERROR - 2015-12-22 17:00:14 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 139
ERROR - 2015-12-22 17:00:14 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 164
ERROR - 2015-12-22 17:00:14 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 182
ERROR - 2015-12-22 17:00:14 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 204
ERROR - 2015-12-22 17:00:14 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 228
ERROR - 2015-12-22 17:00:14 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\coperation\coperationmanage.php 248
ERROR - 2015-12-22 17:00:14 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 44
ERROR - 2015-12-22 17:00:14 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 45
ERROR - 2015-12-22 17:00:14 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\tourism\admin\application\models\tourism_model.php 46
ERROR - 2015-12-22 17:00:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
