<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-26 07:01:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 07:01:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 07:01:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 07:01:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 07:02:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 96
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 109
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 113
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 114
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 116
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: announcement_name C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 132
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 153
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 178
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: announcement_date C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 196
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: fees C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 218
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: no_of_participants C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 241
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 263
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 285
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: venue C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 309
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: history C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 333
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 357
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: priority C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 380
ERROR - 2015-12-26 07:02:07 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\announcement\announcementmanage.php 400
ERROR - 2015-12-26 07:29:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 07:29:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 94
ERROR - 2015-12-26 07:29:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 107
ERROR - 2015-12-26 07:29:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 111
ERROR - 2015-12-26 07:29:37 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 111
ERROR - 2015-12-26 07:29:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 112
ERROR - 2015-12-26 07:29:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 114
ERROR - 2015-12-26 07:29:37 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 130
ERROR - 2015-12-26 07:29:37 --> Severity: Notice  --> Undefined variable: country_id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 151
ERROR - 2015-12-26 07:29:37 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 176
ERROR - 2015-12-26 07:29:37 --> Severity: Notice  --> Undefined variable: startdate C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 194
ERROR - 2015-12-26 07:29:37 --> Severity: Notice  --> Undefined variable: enddate C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 216
ERROR - 2015-12-26 07:29:37 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 240
ERROR - 2015-12-26 07:29:37 --> Severity: Notice  --> Undefined variable: display C:\xampp\htdocs\tourism\admin\application\views\agenda\agendamanage.php 260
ERROR - 2015-12-26 07:53:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\tourism\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:30:05 --> 404 Page Not Found --> tourism
ERROR - 2015-12-26 09:30:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:30:37 --> 404 Page Not Found --> tourism
ERROR - 2015-12-26 09:31:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:31:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:31:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:31:36 --> 404 Page Not Found --> tourism
ERROR - 2015-12-26 09:31:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:31:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:33:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:33:04 --> Query error: Table 'baang.user' doesn't exist
ERROR - 2015-12-26 09:33:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:33:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:35:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:35:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 50
ERROR - 2015-12-26 09:35:53 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 61
ERROR - 2015-12-26 09:36:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:36:21 --> Severity: Notice  --> Undefined index: country_id C:\xampp\htdocs\baang\admin\application\controllers\baang.php 136
ERROR - 2015-12-26 09:36:21 --> Query error: Unknown column 'country_id' in 'field list'
ERROR - 2015-12-26 09:38:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:38:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 50
ERROR - 2015-12-26 09:38:52 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 61
ERROR - 2015-12-26 09:38:52 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 79
ERROR - 2015-12-26 09:39:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:39:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:39:05 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 50
ERROR - 2015-12-26 09:39:05 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 61
ERROR - 2015-12-26 09:39:05 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 79
ERROR - 2015-12-26 09:39:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:39:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:39:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 50
ERROR - 2015-12-26 09:39:13 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 61
ERROR - 2015-12-26 09:39:13 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 79
ERROR - 2015-12-26 09:39:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:39:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:39:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 50
ERROR - 2015-12-26 09:39:17 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 61
ERROR - 2015-12-26 09:39:17 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 79
ERROR - 2015-12-26 09:39:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:39:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 50
ERROR - 2015-12-26 09:39:53 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 61
ERROR - 2015-12-26 09:39:53 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 79
ERROR - 2015-12-26 09:40:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:40:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 50
ERROR - 2015-12-26 09:40:08 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 61
ERROR - 2015-12-26 09:40:08 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 79
ERROR - 2015-12-26 09:40:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:40:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:40:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 50
ERROR - 2015-12-26 09:40:18 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 61
ERROR - 2015-12-26 09:40:18 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 79
ERROR - 2015-12-26 09:40:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:40:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:40:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 50
ERROR - 2015-12-26 09:40:23 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 61
ERROR - 2015-12-26 09:40:23 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 79
ERROR - 2015-12-26 09:40:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:40:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:40:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 50
ERROR - 2015-12-26 09:40:32 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 61
ERROR - 2015-12-26 09:40:32 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 79
ERROR - 2015-12-26 09:40:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:40:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:40:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 50
ERROR - 2015-12-26 09:40:40 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 61
ERROR - 2015-12-26 09:40:40 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 79
ERROR - 2015-12-26 09:40:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:40:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:40:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 50
ERROR - 2015-12-26 09:40:47 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 61
ERROR - 2015-12-26 09:40:47 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 79
ERROR - 2015-12-26 09:40:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:40:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:40:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 50
ERROR - 2015-12-26 09:40:54 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 61
ERROR - 2015-12-26 09:40:54 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 79
ERROR - 2015-12-26 09:41:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:41:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:41:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 50
ERROR - 2015-12-26 09:41:00 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 61
ERROR - 2015-12-26 09:41:00 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 79
ERROR - 2015-12-26 09:41:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:41:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:41:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:41:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 50
ERROR - 2015-12-26 09:41:07 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 61
ERROR - 2015-12-26 09:41:07 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 79
ERROR - 2015-12-26 09:41:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:41:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:41:11 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 50
ERROR - 2015-12-26 09:41:11 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 61
ERROR - 2015-12-26 09:41:11 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 79
ERROR - 2015-12-26 09:43:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:43:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 09:43:18 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 09:43:18 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 09:43:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:43:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:43:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 09:43:21 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 09:43:21 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 09:43:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:43:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:43:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:43:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 09:43:30 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 09:43:30 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 09:43:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:43:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:43:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 09:43:35 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 09:43:35 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 09:46:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:46:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 09:46:30 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 09:46:30 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 09:46:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:46:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:46:36 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 09:46:36 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 09:46:36 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 09:50:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:50:57 --> 404 Page Not Found --> baang/subcategorymanage
ERROR - 2015-12-26 09:51:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:51:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 09:51:12 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 09:51:12 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 09:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:51:14 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 09:51:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 09:51:14 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 09:52:17 --> 404 Page Not Found --> tourism
ERROR - 2015-12-26 09:52:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:52:32 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 09:52:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 09:52:32 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 09:52:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:52:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:52:39 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 09:52:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 09:52:39 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 09:52:39 --> Severity: Notice  --> Undefined property: CI_Loader::$tourism_model C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorygrid.php 68
ERROR - 2015-12-26 09:52:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:52:58 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 09:52:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 09:52:58 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 09:53:04 --> 404 Page Not Found --> tourism
ERROR - 2015-12-26 09:53:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:53:20 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 09:53:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 09:53:20 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 09:53:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:53:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:53:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:53:26 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 09:53:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 09:53:26 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 09:53:30 --> 404 Page Not Found --> tourism
ERROR - 2015-12-26 09:57:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:57:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:57:51 --> 404 Page Not Found --> tourism
ERROR - 2015-12-26 09:57:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:57:55 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 09:57:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 09:57:55 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 09:58:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:58:08 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 09:58:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 09:58:08 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 09:58:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:58:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:58:12 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 09:58:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 09:58:12 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 09:59:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 09:59:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 09:59:02 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 09:59:02 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 10:08:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:08:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:08:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:08:10 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 70
ERROR - 2015-12-26 10:08:10 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 90
ERROR - 2015-12-26 10:09:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:09:05 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:09:05 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 70
ERROR - 2015-12-26 10:09:05 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 90
ERROR - 2015-12-26 10:09:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:09:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:09:15 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:09:15 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 70
ERROR - 2015-12-26 10:09:15 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 90
ERROR - 2015-12-26 10:09:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:09:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:09:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:09:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:09:25 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 70
ERROR - 2015-12-26 10:09:25 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 90
ERROR - 2015-12-26 10:09:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:09:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:09:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:09:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:09:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:09:50 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 10:09:50 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 10:09:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:09:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:09:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:09:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:09:59 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 10:09:59 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 10:10:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:10:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:10:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:10:11 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\baang\admin\application\controllers\baang.php 390
ERROR - 2015-12-26 10:10:11 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\baang\admin\application\controllers\baang.php 391
ERROR - 2015-12-26 10:10:11 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\baang\admin\application\controllers\baang.php 392
ERROR - 2015-12-26 10:10:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:10:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:10:14 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 10:10:14 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 10:12:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:12:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:12:33 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 10:12:33 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 10:12:33 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-26 10:13:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:13:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:13:35 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 10:13:35 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 10:13:35 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-26 10:13:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:13:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:13:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:13:40 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 10:13:40 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 10:13:40 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-26 10:14:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:14:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:14:03 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 10:14:03 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 10:14:03 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-26 10:14:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:14:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:14:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:14:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:14:09 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 10:14:09 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 10:14:09 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-26 10:14:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:14:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:14:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:14:17 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\baang\admin\application\controllers\baang.php 317
ERROR - 2015-12-26 10:14:17 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\baang\admin\application\controllers\baang.php 318
ERROR - 2015-12-26 10:14:17 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\baang\admin\application\controllers\baang.php 319
ERROR - 2015-12-26 10:14:17 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\baang\admin\application\controllers\baang.php 320
ERROR - 2015-12-26 10:16:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:16:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:16:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:16:25 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 10:16:25 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 10:16:25 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-26 10:17:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:17:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:17:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:17:47 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 10:17:47 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 10:17:47 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-26 10:17:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:17:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:17:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:17:59 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 10:17:59 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 10:17:59 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-26 10:18:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:18:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:18:15 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:18:15 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 10:18:15 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 10:18:15 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-26 10:18:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:18:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:18:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:18:25 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 10:18:25 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 10:18:25 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-26 10:18:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:18:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:18:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:18:47 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 10:18:47 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 10:18:47 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-26 10:18:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:18:59 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 10:18:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 10:18:59 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 10:19:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:19:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 10:19:03 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 10:19:03 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 10:19:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:19:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:19:07 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 10:19:07 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 10:19:07 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-26 10:31:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:31:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 10:31:07 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 10:31:07 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 10:31:07 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-26 10:31:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:31:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 33
ERROR - 2015-12-26 10:31:23 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 54
ERROR - 2015-12-26 10:31:23 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 78
ERROR - 2015-12-26 10:31:23 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 100
ERROR - 2015-12-26 10:31:23 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 125
ERROR - 2015-12-26 10:31:23 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 171
ERROR - 2015-12-26 10:32:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:32:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 33
ERROR - 2015-12-26 10:32:34 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 54
ERROR - 2015-12-26 10:32:34 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 78
ERROR - 2015-12-26 10:32:34 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 101
ERROR - 2015-12-26 10:32:34 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 126
ERROR - 2015-12-26 10:32:34 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 172
ERROR - 2015-12-26 10:32:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:32:43 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 172
ERROR - 2015-12-26 10:33:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:34:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:34:01 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 443
ERROR - 2015-12-26 10:34:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:34:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 33
ERROR - 2015-12-26 10:34:01 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 54
ERROR - 2015-12-26 10:34:01 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 78
ERROR - 2015-12-26 10:34:01 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 101
ERROR - 2015-12-26 10:34:01 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 126
ERROR - 2015-12-26 10:34:01 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 173
ERROR - 2015-12-26 10:36:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:36:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 33
ERROR - 2015-12-26 10:36:16 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 54
ERROR - 2015-12-26 10:36:16 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 78
ERROR - 2015-12-26 10:36:16 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 101
ERROR - 2015-12-26 10:36:16 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 126
ERROR - 2015-12-26 10:36:16 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 173
ERROR - 2015-12-26 10:36:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:36:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:36:36 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 443
ERROR - 2015-12-26 10:36:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:36:36 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 33
ERROR - 2015-12-26 10:36:36 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 54
ERROR - 2015-12-26 10:36:36 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 78
ERROR - 2015-12-26 10:36:36 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 101
ERROR - 2015-12-26 10:36:36 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 126
ERROR - 2015-12-26 10:36:36 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 173
ERROR - 2015-12-26 10:37:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:37:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 33
ERROR - 2015-12-26 10:37:01 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 54
ERROR - 2015-12-26 10:37:01 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 78
ERROR - 2015-12-26 10:37:01 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 101
ERROR - 2015-12-26 10:37:01 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 126
ERROR - 2015-12-26 10:37:01 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 173
ERROR - 2015-12-26 10:37:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:37:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:37:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 33
ERROR - 2015-12-26 10:37:26 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 54
ERROR - 2015-12-26 10:37:26 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 78
ERROR - 2015-12-26 10:37:26 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 101
ERROR - 2015-12-26 10:37:26 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 126
ERROR - 2015-12-26 10:37:26 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 173
ERROR - 2015-12-26 10:37:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:37:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:37:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:37:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 33
ERROR - 2015-12-26 10:37:47 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 54
ERROR - 2015-12-26 10:37:47 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 78
ERROR - 2015-12-26 10:37:47 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 101
ERROR - 2015-12-26 10:37:47 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 126
ERROR - 2015-12-26 10:37:47 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 173
ERROR - 2015-12-26 10:37:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:37:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:37:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 33
ERROR - 2015-12-26 10:37:54 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 54
ERROR - 2015-12-26 10:37:54 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 78
ERROR - 2015-12-26 10:37:54 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 101
ERROR - 2015-12-26 10:37:54 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 126
ERROR - 2015-12-26 10:37:54 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 173
ERROR - 2015-12-26 10:38:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:38:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 33
ERROR - 2015-12-26 10:38:43 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 54
ERROR - 2015-12-26 10:38:43 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 78
ERROR - 2015-12-26 10:38:43 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 101
ERROR - 2015-12-26 10:38:43 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 126
ERROR - 2015-12-26 10:38:43 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 173
ERROR - 2015-12-26 10:38:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 10:38:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 33
ERROR - 2015-12-26 10:38:52 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 54
ERROR - 2015-12-26 10:38:52 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 78
ERROR - 2015-12-26 10:38:52 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 101
ERROR - 2015-12-26 10:38:52 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 126
ERROR - 2015-12-26 10:38:52 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 173
ERROR - 2015-12-26 11:04:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:04:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 33
ERROR - 2015-12-26 11:04:58 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 54
ERROR - 2015-12-26 11:04:58 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 78
ERROR - 2015-12-26 11:04:58 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 101
ERROR - 2015-12-26 11:04:58 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 126
ERROR - 2015-12-26 11:04:58 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 173
ERROR - 2015-12-26 11:29:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:29:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 74
ERROR - 2015-12-26 11:29:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 87
ERROR - 2015-12-26 11:29:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:29:48 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:29:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 92
ERROR - 2015-12-26 11:29:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 94
ERROR - 2015-12-26 11:29:48 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 110
ERROR - 2015-12-26 11:29:48 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-26 11:29:48 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 153
ERROR - 2015-12-26 11:29:48 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 175
ERROR - 2015-12-26 11:29:48 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 197
ERROR - 2015-12-26 11:29:48 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-26 11:30:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:30:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 74
ERROR - 2015-12-26 11:30:59 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 87
ERROR - 2015-12-26 11:30:59 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:30:59 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:30:59 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 92
ERROR - 2015-12-26 11:30:59 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 94
ERROR - 2015-12-26 11:30:59 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 110
ERROR - 2015-12-26 11:30:59 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-26 11:30:59 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 153
ERROR - 2015-12-26 11:30:59 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 175
ERROR - 2015-12-26 11:30:59 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 197
ERROR - 2015-12-26 11:30:59 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-26 11:31:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:31:02 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:31:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:31:02 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:32:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:32:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:32:13 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:32:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:32:13 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:32:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:32:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:32:22 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:32:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:32:22 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:32:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:32:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:32:29 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:32:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:32:29 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:32:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:32:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:32:38 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:32:38 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:32:38 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:32:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:32:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:32:50 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:32:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:32:50 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:33:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:33:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:33:01 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:33:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:33:01 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:33:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:33:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 11:33:47 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 11:33:47 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 11:33:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:33:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 11:33:52 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 11:33:52 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 11:34:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:34:19 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:34:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:34:19 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:34:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:34:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:34:52 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:34:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:34:52 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:35:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:35:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:35:00 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:35:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:35:00 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:35:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:35:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:35:11 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:35:11 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:35:11 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:35:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:36:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:36:00 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:36:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:36:00 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:36:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:36:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:36:08 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:36:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:36:08 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:36:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:36:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:36:16 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:36:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:36:16 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:36:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:36:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:36:24 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:36:24 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:36:24 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:37:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:37:06 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:37:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:37:06 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:37:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:37:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 74
ERROR - 2015-12-26 11:37:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 87
ERROR - 2015-12-26 11:37:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:37:13 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:37:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 92
ERROR - 2015-12-26 11:37:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 94
ERROR - 2015-12-26 11:37:13 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 110
ERROR - 2015-12-26 11:37:13 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-26 11:37:13 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 153
ERROR - 2015-12-26 11:37:13 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 175
ERROR - 2015-12-26 11:37:13 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 197
ERROR - 2015-12-26 11:37:13 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-26 11:37:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:37:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:37:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:37:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:40:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:40:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 74
ERROR - 2015-12-26 11:40:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 87
ERROR - 2015-12-26 11:40:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:40:20 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:40:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 92
ERROR - 2015-12-26 11:40:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 94
ERROR - 2015-12-26 11:40:20 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 110
ERROR - 2015-12-26 11:40:20 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-26 11:40:20 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 153
ERROR - 2015-12-26 11:40:20 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 175
ERROR - 2015-12-26 11:40:20 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 197
ERROR - 2015-12-26 11:40:20 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-26 11:40:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:40:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 74
ERROR - 2015-12-26 11:40:25 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 87
ERROR - 2015-12-26 11:40:25 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:40:25 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:40:25 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 92
ERROR - 2015-12-26 11:40:25 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 94
ERROR - 2015-12-26 11:40:25 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 110
ERROR - 2015-12-26 11:40:25 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-26 11:40:25 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 153
ERROR - 2015-12-26 11:40:25 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 175
ERROR - 2015-12-26 11:40:25 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 197
ERROR - 2015-12-26 11:40:25 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-26 11:40:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:40:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:42:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:42:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 11:42:32 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 11:42:32 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 11:45:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:45:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:45:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 11:45:44 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 11:45:44 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 11:45:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:45:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:45:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 11:45:58 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 11:45:58 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 11:46:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:46:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:46:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 11:46:04 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 11:46:04 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 11:46:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:46:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:46:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 11:46:13 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 11:46:13 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 11:46:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:46:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 11:46:35 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 11:46:35 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 11:46:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:46:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:46:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 11:46:54 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 11:46:54 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 11:47:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:47:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:47:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 11:47:30 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 11:47:30 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 11:47:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:47:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:47:36 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 11:47:36 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 11:47:36 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 11:47:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:47:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:47:42 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 11:47:42 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 11:47:42 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 11:47:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:47:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:47:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 11:47:49 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 11:47:49 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 11:47:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:47:53 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:47:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:47:53 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:48:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:48:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:48:35 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:48:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:48:35 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:48:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:48:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:48:43 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:48:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:48:43 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:48:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:48:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:48:54 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:48:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:48:54 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:49:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:49:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:49:27 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:49:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:49:27 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:49:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:49:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:49:52 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:49:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:49:52 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:50:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:50:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:50:21 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:50:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:50:21 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:50:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:50:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:50:27 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:50:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:50:27 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:50:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:50:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:50:41 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:50:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:50:41 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:51:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:51:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:51:17 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:51:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:51:17 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:51:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:51:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:51:21 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:51:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:51:21 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:51:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:51:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:51:30 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:51:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:51:30 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:51:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:51:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:51:35 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:51:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:51:35 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:52:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:52:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:52:09 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:52:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:52:09 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:52:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:52:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:52:16 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:52:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:52:16 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:52:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:52:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:52:27 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:52:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:52:27 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:52:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:52:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:52:39 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:52:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:52:39 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:53:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:53:16 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:53:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:53:16 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:53:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:53:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 11:53:26 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 11:53:26 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 11:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:53:29 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 41
ERROR - 2015-12-26 11:53:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 62
ERROR - 2015-12-26 11:53:29 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 73
ERROR - 2015-12-26 11:53:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:53:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 74
ERROR - 2015-12-26 11:53:34 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 87
ERROR - 2015-12-26 11:53:34 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:53:34 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:53:34 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 92
ERROR - 2015-12-26 11:53:34 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 94
ERROR - 2015-12-26 11:53:34 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 110
ERROR - 2015-12-26 11:53:34 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-26 11:53:34 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 153
ERROR - 2015-12-26 11:53:34 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 175
ERROR - 2015-12-26 11:53:34 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 197
ERROR - 2015-12-26 11:53:34 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-26 11:53:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:54:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:54:00 --> Severity: Notice  --> Undefined index: extension C:\xampp\htdocs\baang\admin\application\controllers\baang.php 623
ERROR - 2015-12-26 11:54:00 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 624
ERROR - 2015-12-26 11:54:00 --> Query error: Unknown column 'name' in 'field list'
ERROR - 2015-12-26 11:54:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:54:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 74
ERROR - 2015-12-26 11:54:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 87
ERROR - 2015-12-26 11:54:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:54:58 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:54:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 92
ERROR - 2015-12-26 11:54:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 94
ERROR - 2015-12-26 11:54:58 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 110
ERROR - 2015-12-26 11:54:58 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-26 11:54:58 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 153
ERROR - 2015-12-26 11:54:58 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 175
ERROR - 2015-12-26 11:54:58 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 197
ERROR - 2015-12-26 11:54:58 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-26 11:55:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:55:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:55:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:55:08 --> Severity: Notice  --> Undefined index: extension C:\xampp\htdocs\baang\admin\application\controllers\baang.php 623
ERROR - 2015-12-26 11:55:08 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 624
ERROR - 2015-12-26 11:55:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:55:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 74
ERROR - 2015-12-26 11:55:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 87
ERROR - 2015-12-26 11:55:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:55:08 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:55:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 92
ERROR - 2015-12-26 11:55:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 94
ERROR - 2015-12-26 11:55:08 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 110
ERROR - 2015-12-26 11:55:08 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-26 11:55:08 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 153
ERROR - 2015-12-26 11:55:08 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 175
ERROR - 2015-12-26 11:55:08 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 197
ERROR - 2015-12-26 11:55:08 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-26 11:55:08 --> Severity: Notice  --> Undefined index: name C:\xampp\htdocs\baang\admin\application\views\product\productgrid.php 76
ERROR - 2015-12-26 11:55:08 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productgrid.php 78
ERROR - 2015-12-26 11:55:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:55:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 74
ERROR - 2015-12-26 11:55:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 87
ERROR - 2015-12-26 11:55:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:55:48 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:55:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 92
ERROR - 2015-12-26 11:55:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 94
ERROR - 2015-12-26 11:55:48 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 110
ERROR - 2015-12-26 11:55:48 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-26 11:55:48 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 153
ERROR - 2015-12-26 11:55:48 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 175
ERROR - 2015-12-26 11:55:48 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 197
ERROR - 2015-12-26 11:55:48 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-26 11:55:48 --> Severity: Notice  --> Undefined index: name C:\xampp\htdocs\baang\admin\application\views\product\productgrid.php 76
ERROR - 2015-12-26 11:55:48 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productgrid.php 78
ERROR - 2015-12-26 11:57:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:57:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 74
ERROR - 2015-12-26 11:57:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 87
ERROR - 2015-12-26 11:57:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:57:52 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:57:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 92
ERROR - 2015-12-26 11:57:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 94
ERROR - 2015-12-26 11:57:52 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 110
ERROR - 2015-12-26 11:57:52 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-26 11:57:52 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 153
ERROR - 2015-12-26 11:57:52 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 175
ERROR - 2015-12-26 11:57:52 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 197
ERROR - 2015-12-26 11:57:52 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-26 11:57:52 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productgrid.php 78
ERROR - 2015-12-26 11:58:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:58:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 74
ERROR - 2015-12-26 11:58:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 87
ERROR - 2015-12-26 11:58:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:58:10 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:58:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 92
ERROR - 2015-12-26 11:58:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 94
ERROR - 2015-12-26 11:58:10 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 110
ERROR - 2015-12-26 11:58:10 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-26 11:58:10 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 153
ERROR - 2015-12-26 11:58:10 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 175
ERROR - 2015-12-26 11:58:10 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 197
ERROR - 2015-12-26 11:58:10 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-26 11:58:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:58:14 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:58:14 --> Severity: Notice  --> Undefined variable: get_sub_category_dropdown C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 127
ERROR - 2015-12-26 11:58:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\baang\admin\system\helpers\form_helper.php 332
ERROR - 2015-12-26 11:58:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:58:48 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:59:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:59:09 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:59:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:59:28 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:59:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:59:39 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 624
ERROR - 2015-12-26 11:59:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:59:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 74
ERROR - 2015-12-26 11:59:39 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 87
ERROR - 2015-12-26 11:59:39 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:59:39 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:59:39 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 92
ERROR - 2015-12-26 11:59:39 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 94
ERROR - 2015-12-26 11:59:39 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 110
ERROR - 2015-12-26 11:59:39 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 136
ERROR - 2015-12-26 11:59:39 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 154
ERROR - 2015-12-26 11:59:39 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 176
ERROR - 2015-12-26 11:59:39 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 198
ERROR - 2015-12-26 11:59:39 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 224
ERROR - 2015-12-26 11:59:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:59:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:59:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 74
ERROR - 2015-12-26 11:59:45 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 87
ERROR - 2015-12-26 11:59:45 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:59:45 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 91
ERROR - 2015-12-26 11:59:45 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 92
ERROR - 2015-12-26 11:59:45 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 94
ERROR - 2015-12-26 11:59:45 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 110
ERROR - 2015-12-26 11:59:45 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 136
ERROR - 2015-12-26 11:59:45 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 154
ERROR - 2015-12-26 11:59:45 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 176
ERROR - 2015-12-26 11:59:45 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 198
ERROR - 2015-12-26 11:59:45 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 224
ERROR - 2015-12-26 11:59:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:59:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:59:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 11:59:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:00:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:02:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:02:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-26 12:02:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-26 12:02:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:02:56 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:02:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-26 12:02:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-26 12:02:56 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-26 12:02:56 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-26 12:02:56 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-26 12:02:56 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-26 12:02:56 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-26 12:02:56 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-26 12:03:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:03:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:03:07 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 626
ERROR - 2015-12-26 12:03:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:03:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-26 12:03:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-26 12:03:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:03:07 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:03:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-26 12:03:07 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-26 12:03:07 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-26 12:03:07 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-26 12:03:07 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-26 12:03:07 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-26 12:03:07 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-26 12:03:07 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-26 12:03:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:03:11 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:03:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:03:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:03:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-26 12:03:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-26 12:03:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:03:14 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:03:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-26 12:03:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-26 12:03:14 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-26 12:03:14 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-26 12:03:14 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-26 12:03:14 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-26 12:03:14 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-26 12:03:14 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-26 12:03:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:03:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:03:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-26 12:03:19 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-26 12:03:19 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:03:19 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:03:19 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-26 12:03:19 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-26 12:03:19 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-26 12:03:19 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-26 12:03:19 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-26 12:03:19 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-26 12:03:19 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-26 12:03:19 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-26 12:05:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:06:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:06:03 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 626
ERROR - 2015-12-26 12:06:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:06:03 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-26 12:06:03 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-26 12:06:03 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:06:03 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:06:03 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-26 12:06:03 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-26 12:06:03 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-26 12:06:03 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-26 12:06:03 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-26 12:06:03 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-26 12:06:03 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-26 12:06:03 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-26 12:06:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:06:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:06:44 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 626
ERROR - 2015-12-26 12:06:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:06:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-26 12:06:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-26 12:06:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:06:44 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:06:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-26 12:06:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-26 12:06:44 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-26 12:06:44 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-26 12:06:44 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-26 12:06:44 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-26 12:06:44 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-26 12:06:44 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-26 12:06:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:07:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:07:20 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 626
ERROR - 2015-12-26 12:07:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:07:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-26 12:07:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-26 12:07:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:07:20 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:07:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-26 12:07:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-26 12:07:20 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-26 12:07:20 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-26 12:07:20 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-26 12:07:20 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-26 12:07:20 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-26 12:07:20 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-26 12:07:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:07:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:07:51 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 626
ERROR - 2015-12-26 12:07:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:07:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-26 12:07:51 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-26 12:07:51 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:07:51 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:07:51 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-26 12:07:51 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-26 12:07:51 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-26 12:07:51 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-26 12:07:51 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-26 12:07:51 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-26 12:07:51 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-26 12:07:51 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-26 12:08:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:08:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:08:17 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 626
ERROR - 2015-12-26 12:08:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:08:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-26 12:08:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-26 12:08:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:08:17 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:08:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-26 12:08:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-26 12:08:17 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-26 12:08:17 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-26 12:08:17 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-26 12:08:17 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-26 12:08:17 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-26 12:08:17 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-26 12:08:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:08:26 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:08:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:08:30 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:08:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:08:34 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-26 12:08:34 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-26 12:08:34 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:08:34 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:08:34 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-26 12:08:34 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-26 12:08:34 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-26 12:08:34 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-26 12:08:34 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-26 12:08:34 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-26 12:08:34 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-26 12:08:34 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-26 12:09:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:09:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-26 12:09:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-26 12:09:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:09:13 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:09:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-26 12:09:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-26 12:09:13 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-26 12:09:13 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-26 12:09:13 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-26 12:09:13 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-26 12:09:13 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-26 12:09:13 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-26 12:14:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:21:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:21:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:22:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:23:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:24:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:24:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:24:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 12:24:22 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 12:24:22 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 12:24:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:25:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:46:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:46:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:46:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:47:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:47:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:48:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:48:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:51:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:52:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:52:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:52:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:52:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:53:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:53:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:53:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:53:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:54:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:54:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-26 12:54:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-26 12:54:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:54:10 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:54:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-26 12:54:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-26 12:54:10 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-26 12:54:10 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-26 12:54:10 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-26 12:54:10 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-26 12:54:10 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-26 12:54:10 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-26 12:54:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:54:11 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 12:54:11 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 12:54:11 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 12:54:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:54:12 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2015-12-26 12:54:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2015-12-26 12:54:12 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2015-12-26 12:54:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:54:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 12:54:14 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 12:54:14 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 12:54:14 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-26 12:54:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:54:15 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-26 12:54:15 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-26 12:54:15 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-26 12:54:15 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-26 12:54:15 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-26 12:54:15 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-26 12:54:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:54:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-26 12:54:16 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-26 12:54:16 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:54:16 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 12:54:16 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-26 12:54:16 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-26 12:54:16 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-26 12:54:16 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-26 12:54:16 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-26 12:54:16 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-26 12:54:16 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-26 12:54:16 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-26 12:54:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:54:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 12:54:51 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2015-12-26 12:54:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2015-12-26 12:54:51 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2015-12-26 12:58:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:00:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:00:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:05:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:06:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:06:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:06:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 13:06:21 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 13:06:21 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 13:06:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:06:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:06:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:06:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:06:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:06:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:07:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:07:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:07:02 --> 404 Page Not Found --> baang/subcategory
ERROR - 2015-12-26 13:07:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:08:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:08:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:08:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:10:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:10:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:10:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:11:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:11:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:11:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:11:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:12:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:12:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:12:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:13:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:13:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:13:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:13:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:13:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-26 13:13:35 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-26 13:13:35 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 13:13:35 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-26 13:13:35 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-26 13:13:35 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-26 13:13:35 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-26 13:13:35 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-26 13:13:35 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-26 13:13:35 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-26 13:13:35 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-26 13:13:35 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-26 13:13:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:13:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-26 13:13:54 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-26 13:13:54 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-26 13:13:54 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-26 13:13:54 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-26 13:13:54 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-26 13:13:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:13:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 13:13:57 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 13:13:57 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 13:13:57 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-26 13:14:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:16:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:16:08 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2015-12-26 13:16:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2015-12-26 13:16:08 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2015-12-26 13:16:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:16:29 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2015-12-26 13:16:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2015-12-26 13:16:29 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2015-12-26 13:17:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:17:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:18:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:21:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:21:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:22:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:23:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:24:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:32:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:34:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:41:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:41:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:41:43 --> Severity: Notice  --> Undefined variable: get_new_customer_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 136
ERROR - 2015-12-26 13:41:43 --> Severity: Notice  --> Undefined variable: get_new_order_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 145
ERROR - 2015-12-26 13:42:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:42:37 --> Severity: Notice  --> Undefined variable: get_new_customer_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 136
ERROR - 2015-12-26 13:42:37 --> Severity: Notice  --> Undefined variable: get_new_order_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 145
ERROR - 2015-12-26 13:42:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:42:44 --> Severity: Notice  --> Undefined variable: get_new_customer_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 136
ERROR - 2015-12-26 13:42:44 --> Severity: Notice  --> Undefined variable: get_new_order_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 145
ERROR - 2015-12-26 13:42:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:42:58 --> Severity: Notice  --> Undefined variable: get_new_customer_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 136
ERROR - 2015-12-26 13:42:58 --> Severity: Notice  --> Undefined variable: get_new_order_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 145
ERROR - 2015-12-26 13:43:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:43:11 --> Severity: Notice  --> Undefined variable: get_new_customer_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 136
ERROR - 2015-12-26 13:43:11 --> Severity: Notice  --> Undefined variable: get_new_order_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 145
ERROR - 2015-12-26 13:43:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:43:32 --> Severity: Notice  --> Undefined variable: get_new_customer_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 136
ERROR - 2015-12-26 13:43:32 --> Severity: Notice  --> Undefined variable: get_new_order_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 145
ERROR - 2015-12-26 13:43:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:43:46 --> Severity: Notice  --> Undefined variable: get_new_customer_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 136
ERROR - 2015-12-26 13:43:46 --> Severity: Notice  --> Undefined variable: get_new_order_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 145
ERROR - 2015-12-26 13:43:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:44:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:44:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:44:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:44:34 --> Severity: Notice  --> Undefined variable: get_new_customer_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 136
ERROR - 2015-12-26 13:44:34 --> Severity: Notice  --> Undefined variable: get_new_order_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 145
ERROR - 2015-12-26 13:44:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:44:41 --> Severity: Notice  --> Undefined variable: get_new_customer_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 136
ERROR - 2015-12-26 13:44:41 --> Severity: Notice  --> Undefined variable: get_new_order_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 145
ERROR - 2015-12-26 13:44:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:44:59 --> Severity: Notice  --> Undefined variable: get_new_customer_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 136
ERROR - 2015-12-26 13:44:59 --> Severity: Notice  --> Undefined variable: get_new_order_count C:\xampp\htdocs\baang\admin\application\views\v_main.php 145
ERROR - 2015-12-26 13:46:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:47:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-26 13:47:44 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-26 13:47:44 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-26 13:47:44 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-26 13:47:44 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-26 13:47:44 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-26 13:47:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:49:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:49:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:49:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:50:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:50:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:53:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 13:53:59 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2015-12-26 13:53:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2015-12-26 13:53:59 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2015-12-26 14:08:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:08:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:11:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:11:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:12:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:14:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:14:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'order by id desc' at line 1
ERROR - 2015-12-26 14:15:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:16:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:16:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:16:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:17:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:19:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:19:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:19:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:19:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:19:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:20:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:25:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:25:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:25:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:25:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:26:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:26:16 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2015-12-26 14:26:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2015-12-26 14:26:16 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2015-12-26 14:26:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:26:42 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-26 14:26:42 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-26 14:26:42 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-26 14:26:42 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-26 14:26:42 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-26 14:26:42 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-26 14:27:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:27:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:27:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:38:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:39:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:39:30 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-26 14:39:30 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-26 14:39:30 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-26 14:39:30 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-26 14:39:30 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-26 14:39:30 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-26 14:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:39:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-26 14:39:54 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-26 14:39:54 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-26 14:39:54 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-26 14:39:54 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-26 14:39:54 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-26 14:39:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:40:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:40:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:40:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:40:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:40:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:40:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:40:18 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-26 14:40:18 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-26 14:40:18 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-26 14:40:18 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-26 14:40:18 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-26 14:40:18 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-26 14:40:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:40:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:40:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-26 14:40:27 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-26 14:40:27 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-26 14:40:27 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-26 14:40:27 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-26 14:40:27 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-26 14:40:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:40:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 14:40:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-26 14:40:32 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-26 14:40:32 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-26 14:40:32 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-26 14:40:32 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-26 14:40:32 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-26 15:09:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 15:09:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 15:09:25 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 15:09:25 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 15:09:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 15:09:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 15:09:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 15:09:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 15:09:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 15:09:56 --> 404 Page Not Found --> baang/subcategory
ERROR - 2015-12-26 15:10:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 15:10:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-26 15:10:01 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-26 15:10:01 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-26 15:10:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 15:10:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-26 15:10:10 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-26 15:10:10 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-26 15:10:10 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-26 15:10:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 15:10:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 15:10:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 15:10:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 15:10:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 15:11:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 15:11:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 15:11:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 15:11:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-26 15:11:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
