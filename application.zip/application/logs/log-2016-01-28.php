<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-01-28 15:06:35 --> Severity: Notice  --> Undefined variable: id /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 99
ERROR - 2016-01-28 15:06:35 --> Severity: Notice  --> Undefined variable: photo /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 112
ERROR - 2016-01-28 15:06:35 --> Severity: Notice  --> Undefined variable: photo /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 116
ERROR - 2016-01-28 15:06:35 --> Severity: Notice  --> Undefined variable: disable /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 116
ERROR - 2016-01-28 15:06:35 --> Severity: Notice  --> Undefined variable: photo /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 117
ERROR - 2016-01-28 15:06:35 --> Severity: Notice  --> Undefined variable: photo /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 119
ERROR - 2016-01-28 15:06:35 --> Severity: Notice  --> Undefined variable: category_id /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 135
ERROR - 2016-01-28 15:06:35 --> Severity: Notice  --> Undefined variable: sub_category_id /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 161
ERROR - 2016-01-28 15:06:35 --> Severity: Notice  --> Undefined variable: product_name /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 179
ERROR - 2016-01-28 15:06:35 --> Severity: Notice  --> Undefined variable: price /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 202
ERROR - 2016-01-28 15:06:35 --> Severity: Notice  --> Undefined variable: unit /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 224
ERROR - 2016-01-28 15:06:35 --> Severity: Notice  --> Undefined variable: description /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 250
ERROR - 2016-01-28 15:06:35 --> Severity: Notice  --> Undefined variable: availability /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 271
ERROR - 2016-01-28 15:06:43 --> Severity: Notice  --> Undefined variable: disable /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 116
