<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-10 04:58:57 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
