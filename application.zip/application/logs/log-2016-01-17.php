<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-01-17 11:44:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-17 11:44:29 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-17 11:44:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-17 11:44:29 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-17 11:44:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-17 11:44:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-17 11:44:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-17 11:44:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-17 11:44:38 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\controllers\baang.php 1009
ERROR - 2016-01-17 06:44:41 --> Severity: Notice  --> Undefined variable: q /home/fishwqrb/public_html/admin/application/views/product/productautocompletion.php 5
ERROR - 2016-01-17 06:44:41 --> Severity: Notice  --> Undefined variable: id /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 107
ERROR - 2016-01-17 06:44:42 --> Severity: Notice  --> Undefined variable: photo /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 120
ERROR - 2016-01-17 06:44:42 --> Severity: Notice  --> Undefined variable: photo /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 124
ERROR - 2016-01-17 06:44:42 --> Severity: Notice  --> Undefined variable: disable /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 124
ERROR - 2016-01-17 06:44:42 --> Severity: Notice  --> Undefined variable: photo /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 125
ERROR - 2016-01-17 06:44:42 --> Severity: Notice  --> Undefined variable: photo /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 127
ERROR - 2016-01-17 06:44:42 --> Severity: Notice  --> Undefined variable: category_id /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 143
ERROR - 2016-01-17 06:44:42 --> Severity: Notice  --> Undefined variable: sub_category_id /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 169
ERROR - 2016-01-17 06:44:42 --> Severity: Notice  --> Undefined variable: product_name /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 187
ERROR - 2016-01-17 06:44:42 --> Severity: Notice  --> Undefined variable: price /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 210
ERROR - 2016-01-17 06:44:42 --> Severity: Notice  --> Undefined variable: unit /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 232
ERROR - 2016-01-17 06:44:42 --> Severity: Notice  --> Undefined variable: description /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 258
ERROR - 2016-01-17 06:44:42 --> Severity: Notice  --> Undefined variable: availability /home/fishwqrb/public_html/admin/application/views/product/productmanage.php 279
ERROR - 2016-01-17 06:54:17 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 06:55:43 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 06:55:43 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 06:57:38 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 06:57:38 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 06:59:38 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 06:59:38 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 06:59:38 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 07:00:49 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 07:00:49 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 07:00:49 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 07:00:49 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 07:06:50 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 07:06:50 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 07:06:50 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 07:06:50 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 07:07:33 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 07:07:33 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 07:07:33 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
ERROR - 2016-01-17 07:07:33 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 110
