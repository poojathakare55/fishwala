<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-09-22 12:41:24 --> Severity: Notice  --> Undefined variable: photo /home/fishwqrb/public_html/admin/application/views/category/categorymanage.php 77
ERROR - 2016-09-22 12:41:24 --> Severity: Notice  --> Undefined variable: photo /home/fishwqrb/public_html/admin/application/views/category/categorymanage.php 81
ERROR - 2016-09-22 12:41:24 --> Severity: Notice  --> Undefined variable: disable /home/fishwqrb/public_html/admin/application/views/category/categorymanage.php 81
ERROR - 2016-09-22 12:41:24 --> Severity: Notice  --> Undefined variable: photo /home/fishwqrb/public_html/admin/application/views/category/categorymanage.php 82
ERROR - 2016-09-22 12:41:24 --> Severity: Notice  --> Undefined variable: photo /home/fishwqrb/public_html/admin/application/views/category/categorymanage.php 84
ERROR - 2016-09-22 12:41:24 --> Severity: Notice  --> Undefined variable: id /home/fishwqrb/public_html/admin/application/views/category/categorymanage.php 103
ERROR - 2016-09-22 12:41:24 --> Severity: Notice  --> Undefined variable: category_name /home/fishwqrb/public_html/admin/application/views/category/categorymanage.php 114
ERROR - 2016-09-22 12:41:33 --> Severity: Notice  --> Undefined variable: id /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 42
ERROR - 2016-09-22 12:41:33 --> Severity: Notice  --> Undefined variable: name /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 63
ERROR - 2016-09-22 12:41:33 --> Severity: Notice  --> Undefined variable: emailid /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 87
ERROR - 2016-09-22 12:41:33 --> Severity: Notice  --> Undefined variable: contactno /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 110
ERROR - 2016-09-22 12:41:33 --> Severity: Notice  --> Undefined variable: address /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 135
ERROR - 2016-09-22 12:41:33 --> Severity: Notice  --> Undefined variable: password /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 185
ERROR - 2016-09-22 12:41:43 --> Severity: Notice  --> Undefined variable: id /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 42
ERROR - 2016-09-22 12:41:43 --> Severity: Notice  --> Undefined variable: name /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 63
ERROR - 2016-09-22 12:41:43 --> Severity: Notice  --> Undefined variable: emailid /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 87
ERROR - 2016-09-22 12:41:43 --> Severity: Notice  --> Undefined variable: contactno /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 110
ERROR - 2016-09-22 12:41:43 --> Severity: Notice  --> Undefined variable: address /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 135
ERROR - 2016-09-22 12:41:43 --> Severity: Notice  --> Undefined variable: password /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 185
ERROR - 2016-09-22 12:42:27 --> Severity: Notice  --> Undefined variable: id /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 42
ERROR - 2016-09-22 12:42:27 --> Severity: Notice  --> Undefined variable: name /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 63
ERROR - 2016-09-22 12:42:27 --> Severity: Notice  --> Undefined variable: emailid /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 87
ERROR - 2016-09-22 12:42:27 --> Severity: Notice  --> Undefined variable: contactno /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 110
ERROR - 2016-09-22 12:42:27 --> Severity: Notice  --> Undefined variable: address /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 135
ERROR - 2016-09-22 12:42:27 --> Severity: Notice  --> Undefined variable: password /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 185
