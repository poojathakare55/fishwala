<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-30 20:54:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 20:54:51 --> Query error: Table 'baang.order_details' doesn't exist
ERROR - 2015-12-30 23:38:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:38:44 --> Query error: Table 'baang.master_order where open='0'' doesn't exist
ERROR - 2015-12-30 23:38:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:38:59 --> Query error: Unknown column 'open' in 'where clause'
ERROR - 2015-12-30 23:40:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:40:33 --> Query error: Table 'baang.order_details' doesn't exist
ERROR - 2015-12-30 23:42:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:42:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:42:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:42:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:42:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:42:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:43:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:43:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:44:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:45:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:45:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:46:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:46:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:46:53 --> Query error: Table 'baang.order_details' doesn't exist
ERROR - 2015-12-30 23:51:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:51:23 --> Query error: Table 'baang.master_orderhide' doesn't exist
ERROR - 2015-12-30 23:51:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:51:30 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 47
ERROR - 2015-12-30 23:51:30 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 47
ERROR - 2015-12-30 23:53:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:53:30 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-30 23:53:30 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-30 23:54:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:54:03 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-30 23:54:03 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-30 23:54:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:54:41 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:54:41 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-30 23:54:41 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-30 23:55:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:55:02 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-30 23:55:02 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-30 23:56:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:56:59 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-30 23:56:59 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-30 23:57:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:57:11 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-30 23:57:11 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-30 23:57:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:57:45 --> Query error: Table 'baang.order_details' doesn't exist
ERROR - 2015-12-30 23:58:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:59:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-30 23:59:19 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-30 23:59:19 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
