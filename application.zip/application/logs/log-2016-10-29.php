<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-10-29 15:44:45 --> Severity: Notice  --> Undefined variable: get_user_details /home/fishwqrb/public_html/admin/application/views/v_main.php 7
ERROR - 2016-10-29 15:44:45 --> Severity: Notice  --> Undefined variable: get_new_customer_count /home/fishwqrb/public_html/admin/application/views/v_main.php 153
ERROR - 2016-10-29 15:44:45 --> Severity: Notice  --> Undefined variable: get_new_order_count /home/fishwqrb/public_html/admin/application/views/v_main.php 163
ERROR - 2016-10-29 15:44:45 --> Severity: Warning  --> include(/home/fishwqrb/public_html/admin/application/views): failed to open stream: No such file or directory /home/fishwqrb/public_html/admin/application/views/v_main.php 192
ERROR - 2016-10-29 15:44:45 --> Severity: Warning  --> include(/home/fishwqrb/public_html/admin/application/views): failed to open stream: No such device /home/fishwqrb/public_html/admin/application/views/v_main.php 192
ERROR - 2016-10-29 15:44:45 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.:/opt/alt/php54/usr/share/pear:/opt/alt/php54/usr/share/php') /home/fishwqrb/public_html/admin/application/views/v_main.php 192
