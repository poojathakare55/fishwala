<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-21 20:08:41 --> Severity: Notice  --> Undefined index: delivery_charge /home/fishwqrb/public_html/admin/application/views/order/walletgrid.php 68
ERROR - 2016-02-21 20:08:41 --> Severity: Notice  --> Undefined index: delivery_charge /home/fishwqrb/public_html/admin/application/views/order/walletgrid.php 68
ERROR - 2016-02-21 20:08:41 --> Severity: Notice  --> Undefined index: delivery_charge /home/fishwqrb/public_html/admin/application/views/order/walletgrid.php 68
ERROR - 2016-02-21 20:08:41 --> Severity: Notice  --> Undefined index: delivery_charge /home/fishwqrb/public_html/admin/application/views/order/walletgrid.php 68
ERROR - 2016-02-21 20:08:41 --> Severity: Notice  --> Undefined index: delivery_charge /home/fishwqrb/public_html/admin/application/views/order/walletgrid.php 68
ERROR - 2016-02-21 20:08:41 --> Severity: Notice  --> Undefined index: delivery_charge /home/fishwqrb/public_html/admin/application/views/order/walletgrid.php 68
ERROR - 2016-02-21 20:08:41 --> Severity: Notice  --> Undefined index: delivery_charge /home/fishwqrb/public_html/admin/application/views/order/walletgrid.php 68
ERROR - 2016-02-21 20:08:41 --> Severity: Notice  --> Undefined index: delivery_charge /home/fishwqrb/public_html/admin/application/views/order/walletgrid.php 68
