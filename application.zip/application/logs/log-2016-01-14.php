<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-01-14 06:33:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:33:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:33:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:33:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:33:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:34:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:34:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:34:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:34:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:34:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:34:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:34:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:34:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:34:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:34:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 77
ERROR - 2016-01-14 06:34:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 06:34:58 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 06:34:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 82
ERROR - 2016-01-14 06:34:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 84
ERROR - 2016-01-14 06:34:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 103
ERROR - 2016-01-14 06:34:58 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 114
ERROR - 2016-01-14 06:40:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:40:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2016-01-14 06:40:33 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\fish\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2016-01-14 06:40:33 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\fish\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2016-01-14 06:40:33 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\fish\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2016-01-14 06:40:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:40:35 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\fish\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2016-01-14 06:40:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2016-01-14 06:40:35 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\fish\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2016-01-14 06:40:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:40:36 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2016-01-14 06:40:36 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\fish\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2016-01-14 06:40:36 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\fish\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2016-01-14 06:40:36 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\fish\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2016-01-14 06:40:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:40:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-14 06:40:37 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-14 06:40:37 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-14 06:40:37 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-14 06:40:37 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-14 06:40:37 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 185
ERROR - 2016-01-14 06:40:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:40:51 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 77
ERROR - 2016-01-14 06:40:51 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 06:40:51 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 06:40:51 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 82
ERROR - 2016-01-14 06:40:51 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 84
ERROR - 2016-01-14 06:40:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 103
ERROR - 2016-01-14 06:40:51 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 114
ERROR - 2016-01-14 06:40:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:40:52 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\fish\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2016-01-14 06:40:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2016-01-14 06:40:52 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\fish\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2016-01-14 06:40:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:40:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2016-01-14 06:40:53 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\fish\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2016-01-14 06:40:53 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\fish\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2016-01-14 06:40:53 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\fish\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2016-01-14 06:40:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:40:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-14 06:40:55 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-14 06:40:55 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-14 06:40:55 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-14 06:40:55 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-14 06:40:55 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 185
ERROR - 2016-01-14 06:42:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:42:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-14 06:42:06 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-14 06:42:06 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-14 06:42:06 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-14 06:42:06 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-14 06:42:06 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 185
ERROR - 2016-01-14 06:42:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:42:36 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-14 06:42:36 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-14 06:42:36 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-14 06:42:36 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-14 06:42:36 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-14 06:42:36 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 185
ERROR - 2016-01-14 06:42:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:42:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:42:42 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\fish\admin\application\controllers\baang.php 514
ERROR - 2016-01-14 06:42:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:42:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-14 06:42:43 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-14 06:42:43 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-14 06:42:43 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-14 06:42:43 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-14 06:42:43 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 185
ERROR - 2016-01-14 06:43:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:43:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 42
ERROR - 2016-01-14 06:43:37 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 63
ERROR - 2016-01-14 06:43:37 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 87
ERROR - 2016-01-14 06:43:37 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 110
ERROR - 2016-01-14 06:43:37 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 135
ERROR - 2016-01-14 06:43:37 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\fish\admin\application\views\employee\employeemanage.php 185
ERROR - 2016-01-14 06:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:43:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:44:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:44:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:45:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:45:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:45:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:45:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:45:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 77
ERROR - 2016-01-14 06:45:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 06:45:52 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 06:45:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 82
ERROR - 2016-01-14 06:45:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 84
ERROR - 2016-01-14 06:45:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 103
ERROR - 2016-01-14 06:45:52 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 114
ERROR - 2016-01-14 06:46:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:46:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 77
ERROR - 2016-01-14 06:46:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 06:46:56 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 06:46:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 82
ERROR - 2016-01-14 06:46:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 84
ERROR - 2016-01-14 06:46:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 103
ERROR - 2016-01-14 06:46:56 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 114
ERROR - 2016-01-14 06:47:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 06:47:05 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 77
ERROR - 2016-01-14 06:47:05 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 06:47:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 06:47:05 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 82
ERROR - 2016-01-14 06:47:05 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 84
ERROR - 2016-01-14 06:47:05 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 103
ERROR - 2016-01-14 06:47:05 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 114
ERROR - 2016-01-14 07:04:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:04:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:08:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:08:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:09:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:10:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:11:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:11:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:11:36 --> Severity: Warning  --> Missing argument 2 for Baang_model::get_subcategory_for_dashboard(), called in C:\xampp\htdocs\fish\admin\application\controllers\baang.php on line 794 and defined C:\xampp\htdocs\fish\admin\application\models\baang_model.php 158
ERROR - 2016-01-14 07:11:36 --> Severity: Notice  --> Undefined variable: nextdate C:\xampp\htdocs\fish\admin\application\models\baang_model.php 160
ERROR - 2016-01-14 07:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:11:38 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\fish\admin\application\controllers\baang.php 1018
ERROR - 2016-01-14 07:12:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:12:04 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\fish\admin\application\controllers\baang.php 1018
ERROR - 2016-01-14 07:12:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:12:14 --> Severity: Notice  --> Undefined index: delivery_time C:\xampp\htdocs\fish\admin\application\views\order\newordergrid.php 110
ERROR - 2016-01-14 07:12:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:12:21 --> Severity: Notice  --> Undefined index: fromdate C:\xampp\htdocs\fish\admin\application\models\baang_model.php 368
ERROR - 2016-01-14 07:12:21 --> Severity: Notice  --> Undefined index: todate C:\xampp\htdocs\fish\admin\application\models\baang_model.php 369
ERROR - 2016-01-14 07:12:21 --> Severity: Notice  --> Undefined index: days C:\xampp\htdocs\fish\admin\application\models\baang_model.php 370
ERROR - 2016-01-14 07:12:21 --> Severity: Notice  --> Undefined index: selecteddates C:\xampp\htdocs\fish\admin\application\models\baang_model.php 371
ERROR - 2016-01-14 07:12:21 --> Severity: Notice  --> Undefined index: fromdate C:\xampp\htdocs\fish\admin\application\models\baang_model.php 368
ERROR - 2016-01-14 07:12:21 --> Severity: Notice  --> Undefined index: todate C:\xampp\htdocs\fish\admin\application\models\baang_model.php 369
ERROR - 2016-01-14 07:12:21 --> Severity: Notice  --> Undefined index: days C:\xampp\htdocs\fish\admin\application\models\baang_model.php 370
ERROR - 2016-01-14 07:12:21 --> Severity: Notice  --> Undefined index: selecteddates C:\xampp\htdocs\fish\admin\application\models\baang_model.php 371
ERROR - 2016-01-14 07:13:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:13:54 --> Severity: Notice  --> Undefined index: order_date C:\xampp\htdocs\fish\admin\application\models\baang_model.php 368
ERROR - 2016-01-14 07:13:54 --> Severity: Notice  --> Undefined index: order_date C:\xampp\htdocs\fish\admin\application\models\baang_model.php 368
ERROR - 2016-01-14 07:13:54 --> Query error: Unknown column 'selecteddates' in 'where clause'
ERROR - 2016-01-14 07:20:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:20:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'om mo.id=pod.order_id where pod.order_id='42' and mo.status!='delivered' order b' at line 1
ERROR - 2016-01-14 07:20:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:20:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'om mo.id=pod.order_id where pod.order_id='42' and mo.status!='delivered' order b' at line 1
ERROR - 2016-01-14 07:21:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:21:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'om mo.id=pod.order_id where pod.order_id='42' and mo.status!='delivered' order b' at line 1
ERROR - 2016-01-14 07:21:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:21:33 --> Query error: Column 'id' in order clause is ambiguous
ERROR - 2016-01-14 07:21:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:21:41 --> Query error: Unknown column 'selecteddates' in 'where clause'
ERROR - 2016-01-14 07:22:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:22:44 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 90
ERROR - 2016-01-14 07:22:44 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 92
ERROR - 2016-01-14 07:22:44 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 94
ERROR - 2016-01-14 07:22:44 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 96
ERROR - 2016-01-14 07:22:44 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 103
ERROR - 2016-01-14 07:22:44 --> Severity: Notice  --> Undefined variable: mysubscriptionstatustext C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 113
ERROR - 2016-01-14 07:22:44 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 90
ERROR - 2016-01-14 07:22:44 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 92
ERROR - 2016-01-14 07:22:44 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 94
ERROR - 2016-01-14 07:22:44 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 96
ERROR - 2016-01-14 07:22:44 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 103
ERROR - 2016-01-14 07:22:44 --> Severity: Notice  --> Undefined variable: mysubscriptionstatustext C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 113
ERROR - 2016-01-14 07:38:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:38:33 --> Severity: Notice  --> Undefined index: order_no C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 41
ERROR - 2016-01-14 07:38:33 --> Severity: Notice  --> Undefined index: customer C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 41
ERROR - 2016-01-14 07:38:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:38:39 --> Severity: Notice  --> Undefined index: delivery_time C:\xampp\htdocs\fish\admin\application\views\order\newordergrid.php 110
ERROR - 2016-01-14 07:38:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:38:40 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 90
ERROR - 2016-01-14 07:38:40 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 92
ERROR - 2016-01-14 07:38:40 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 94
ERROR - 2016-01-14 07:38:40 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 96
ERROR - 2016-01-14 07:38:40 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 103
ERROR - 2016-01-14 07:38:40 --> Severity: Notice  --> Undefined variable: mysubscriptionstatustext C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 113
ERROR - 2016-01-14 07:38:40 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 90
ERROR - 2016-01-14 07:38:40 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 92
ERROR - 2016-01-14 07:38:40 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 94
ERROR - 2016-01-14 07:38:40 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 96
ERROR - 2016-01-14 07:38:40 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 103
ERROR - 2016-01-14 07:38:40 --> Severity: Notice  --> Undefined variable: mysubscriptionstatustext C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 113
ERROR - 2016-01-14 07:38:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:39:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:39:01 --> Severity: Notice  --> Undefined index: delivery_time C:\xampp\htdocs\fish\admin\application\views\order\newordergrid.php 110
ERROR - 2016-01-14 07:39:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:39:04 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 90
ERROR - 2016-01-14 07:39:04 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 92
ERROR - 2016-01-14 07:39:04 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 94
ERROR - 2016-01-14 07:39:04 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 96
ERROR - 2016-01-14 07:39:04 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 103
ERROR - 2016-01-14 07:39:04 --> Severity: Notice  --> Undefined variable: mysubscriptionstatustext C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 113
ERROR - 2016-01-14 07:39:04 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 90
ERROR - 2016-01-14 07:39:04 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 92
ERROR - 2016-01-14 07:39:04 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 94
ERROR - 2016-01-14 07:39:04 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 96
ERROR - 2016-01-14 07:39:04 --> Severity: Notice  --> Undefined variable: statusfromdb C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 103
ERROR - 2016-01-14 07:39:04 --> Severity: Notice  --> Undefined variable: mysubscriptionstatustext C:\xampp\htdocs\fish\admin\application\views\order\orderdetails.php 113
ERROR - 2016-01-14 07:39:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:41:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:41:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:43:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:43:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:44:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:45:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:45:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:45:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:45:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:46:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:47:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:47:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:47:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:47:48 --> Severity: Notice  --> Undefined index: delivery_time C:\xampp\htdocs\fish\admin\application\views\order\newordergrid.php 110
ERROR - 2016-01-14 07:47:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:47:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:47:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:48:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:48:00 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\fish\admin\application\controllers\baang.php 1019
ERROR - 2016-01-14 07:48:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:48:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:48:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:48:13 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\fish\admin\application\controllers\baang.php 1019
ERROR - 2016-01-14 07:48:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:48:17 --> Severity: Notice  --> Undefined index: delivery_time C:\xampp\htdocs\fish\admin\application\views\order\newordergrid.php 110
ERROR - 2016-01-14 07:48:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:48:24 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\fish\admin\application\views\order\walletgrid.php 66
ERROR - 2016-01-14 07:48:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:48:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:48:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:48:34 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\fish\admin\application\controllers\baang.php 1019
ERROR - 2016-01-14 07:48:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:49:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:50:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:50:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:50:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:50:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'where p.status='pending' GROUP BY c.id' at line 1
ERROR - 2016-01-14 07:50:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:50:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:50:52 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\fish\admin\application\controllers\baang.php 1019
ERROR - 2016-01-14 07:51:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:51:33 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\fish\admin\application\controllers\baang.php 1019
ERROR - 2016-01-14 07:51:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:51:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:51:40 --> Severity: Notice  --> Undefined index: delivery_time C:\xampp\htdocs\fish\admin\application\views\order\newordergrid.php 110
ERROR - 2016-01-14 07:51:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:51:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:51:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:51:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:51:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:51:53 --> Severity: Notice  --> Undefined index: delivery_time C:\xampp\htdocs\fish\admin\application\views\order\newordergrid.php 110
ERROR - 2016-01-14 07:54:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:54:05 --> Severity: Notice  --> Undefined index: delivery_time C:\xampp\htdocs\fish\admin\application\views\order\newordergrid.php 110
ERROR - 2016-01-14 07:54:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:54:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:54:36 --> Severity: Notice  --> Undefined index: delivery_time C:\xampp\htdocs\fish\admin\application\views\order\newordergrid.php 110
ERROR - 2016-01-14 07:55:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:55:04 --> Query error: Unknown column 'fromdate' in 'field list'
ERROR - 2016-01-14 07:55:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:55:08 --> Query error: Unknown column 'fromdate' in 'field list'
ERROR - 2016-01-14 07:55:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:55:10 --> Query error: Unknown column 'fromdate' in 'field list'
ERROR - 2016-01-14 07:55:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:55:12 --> Severity: Notice  --> Undefined index: delivery_time C:\xampp\htdocs\fish\admin\application\views\order\newordergrid.php 110
ERROR - 2016-01-14 07:55:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:55:33 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\fish\admin\application\views\order\walletgrid.php 66
ERROR - 2016-01-14 07:55:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:55:48 --> Severity: Notice  --> Undefined index: delivery_time C:\xampp\htdocs\fish\admin\application\views\order\newordergrid.php 110
ERROR - 2016-01-14 07:57:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:57:46 --> Severity: Notice  --> Undefined index: delivery_time C:\xampp\htdocs\fish\admin\application\views\order\newordergrid.php 110
ERROR - 2016-01-14 07:57:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:57:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:58:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:58:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:58:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:58:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:58:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 07:58:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:00:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:00:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 77
ERROR - 2016-01-14 08:00:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 08:00:17 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 08:00:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 82
ERROR - 2016-01-14 08:00:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 84
ERROR - 2016-01-14 08:00:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 103
ERROR - 2016-01-14 08:00:17 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 114
ERROR - 2016-01-14 08:00:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:00:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:00:25 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 77
ERROR - 2016-01-14 08:00:25 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 08:00:25 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 08:00:25 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 82
ERROR - 2016-01-14 08:00:25 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 84
ERROR - 2016-01-14 08:00:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 103
ERROR - 2016-01-14 08:00:25 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 114
ERROR - 2016-01-14 08:00:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:00:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:00:31 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 77
ERROR - 2016-01-14 08:00:31 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 08:00:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 08:00:31 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 82
ERROR - 2016-01-14 08:00:31 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 84
ERROR - 2016-01-14 08:00:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 103
ERROR - 2016-01-14 08:00:31 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 114
ERROR - 2016-01-14 08:00:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:00:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:00:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 77
ERROR - 2016-01-14 08:00:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 08:00:37 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 08:00:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 82
ERROR - 2016-01-14 08:00:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 84
ERROR - 2016-01-14 08:00:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 103
ERROR - 2016-01-14 08:00:37 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 114
ERROR - 2016-01-14 08:00:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:00:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:00:41 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 77
ERROR - 2016-01-14 08:00:41 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 08:00:41 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 08:00:41 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 82
ERROR - 2016-01-14 08:00:41 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 84
ERROR - 2016-01-14 08:00:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 103
ERROR - 2016-01-14 08:00:41 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 114
ERROR - 2016-01-14 08:00:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:00:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:00:46 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 77
ERROR - 2016-01-14 08:00:46 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 08:00:46 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 81
ERROR - 2016-01-14 08:00:46 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 82
ERROR - 2016-01-14 08:00:46 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 84
ERROR - 2016-01-14 08:00:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 103
ERROR - 2016-01-14 08:00:46 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\fish\admin\application\views\category\categorymanage.php 114
ERROR - 2016-01-14 08:00:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:00:48 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\fish\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2016-01-14 08:00:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2016-01-14 08:00:48 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\fish\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2016-01-14 08:04:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:04:43 --> Severity: Notice  --> Undefined index: delivery_time C:\xampp\htdocs\fish\admin\application\views\order\newordergrid.php 110
ERROR - 2016-01-14 08:04:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:04:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:04:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:04:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:04:57 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\fish\admin\application\controllers\baang.php 1019
ERROR - 2016-01-14 08:05:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:05:11 --> Severity: Notice  --> Undefined index: delivery_time C:\xampp\htdocs\fish\admin\application\views\order\newordergrid.php 110
ERROR - 2016-01-14 08:05:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:05:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:05:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:06:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:07:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:07:33 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\fish\admin\application\views\product\productautocompletion.php 5
ERROR - 2016-01-14 08:07:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 107
ERROR - 2016-01-14 08:07:33 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 120
ERROR - 2016-01-14 08:07:33 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-14 08:07:33 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-14 08:07:33 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 125
ERROR - 2016-01-14 08:07:33 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 127
ERROR - 2016-01-14 08:07:33 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 143
ERROR - 2016-01-14 08:07:33 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 169
ERROR - 2016-01-14 08:07:33 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 187
ERROR - 2016-01-14 08:07:33 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 210
ERROR - 2016-01-14 08:07:33 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 232
ERROR - 2016-01-14 08:07:33 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 258
ERROR - 2016-01-14 08:07:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:07:36 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\fish\admin\application\views\product\productautocompletion.php 5
ERROR - 2016-01-14 08:07:36 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-14 08:07:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:07:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:07:41 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\fish\admin\application\views\product\productautocompletion.php 5
ERROR - 2016-01-14 08:07:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 107
ERROR - 2016-01-14 08:07:41 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 120
ERROR - 2016-01-14 08:07:41 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-14 08:07:41 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-14 08:07:41 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 125
ERROR - 2016-01-14 08:07:41 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 127
ERROR - 2016-01-14 08:07:41 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 143
ERROR - 2016-01-14 08:07:41 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 169
ERROR - 2016-01-14 08:07:41 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 187
ERROR - 2016-01-14 08:07:41 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 210
ERROR - 2016-01-14 08:07:41 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 232
ERROR - 2016-01-14 08:07:41 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 258
ERROR - 2016-01-14 08:08:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:08:10 --> Severity: Notice  --> Undefined index: delivery_time C:\xampp\htdocs\fish\admin\application\views\order\newordergrid.php 110
ERROR - 2016-01-14 08:08:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:08:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:08:23 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\fish\admin\application\views\order\walletgrid.php 66
ERROR - 2016-01-14 08:09:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 08:09:42 --> Severity: Notice  --> Undefined index: delivery_time C:\xampp\htdocs\fish\admin\application\views\order\newordergrid.php 110
ERROR - 2016-01-14 09:21:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 09:21:35 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\fish\admin\application\views\product\productautocompletion.php 5
ERROR - 2016-01-14 09:21:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 107
ERROR - 2016-01-14 09:21:35 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 120
ERROR - 2016-01-14 09:21:35 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-14 09:21:35 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-14 09:21:35 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 125
ERROR - 2016-01-14 09:21:35 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 127
ERROR - 2016-01-14 09:21:35 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 143
ERROR - 2016-01-14 09:21:35 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 169
ERROR - 2016-01-14 09:21:35 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 187
ERROR - 2016-01-14 09:21:35 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 210
ERROR - 2016-01-14 09:21:35 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 232
ERROR - 2016-01-14 09:21:35 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 258
ERROR - 2016-01-14 09:21:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 10:12:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 10:12:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 10:13:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 10:33:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 10:33:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 10:33:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 10:33:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 10:33:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 10:33:23 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\fish\admin\application\views\product\productautocompletion.php 5
ERROR - 2016-01-14 10:33:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 107
ERROR - 2016-01-14 10:33:23 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 120
ERROR - 2016-01-14 10:33:23 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-14 10:33:23 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-14 10:33:23 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 125
ERROR - 2016-01-14 10:33:23 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 127
ERROR - 2016-01-14 10:33:23 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 143
ERROR - 2016-01-14 10:33:23 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 169
ERROR - 2016-01-14 10:33:23 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 187
ERROR - 2016-01-14 10:33:23 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 210
ERROR - 2016-01-14 10:33:23 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 232
ERROR - 2016-01-14 10:33:23 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 258
ERROR - 2016-01-14 10:33:23 --> Severity: Notice  --> Undefined variable: availability C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 279
ERROR - 2016-01-14 10:33:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 10:33:28 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\fish\admin\application\views\product\productautocompletion.php 5
ERROR - 2016-01-14 10:33:28 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-14 10:33:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 10:33:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 10:33:32 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\fish\admin\application\views\product\productautocompletion.php 5
ERROR - 2016-01-14 10:33:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 107
ERROR - 2016-01-14 10:33:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 120
ERROR - 2016-01-14 10:33:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-14 10:33:32 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-14 10:33:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 125
ERROR - 2016-01-14 10:33:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 127
ERROR - 2016-01-14 10:33:32 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 143
ERROR - 2016-01-14 10:33:32 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 169
ERROR - 2016-01-14 10:33:32 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 187
ERROR - 2016-01-14 10:33:32 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 210
ERROR - 2016-01-14 10:33:32 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 232
ERROR - 2016-01-14 10:33:32 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 258
ERROR - 2016-01-14 10:33:32 --> Severity: Notice  --> Undefined variable: availability C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 279
ERROR - 2016-01-14 10:33:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 10:33:36 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\fish\admin\application\views\product\productautocompletion.php 5
ERROR - 2016-01-14 10:33:36 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-14 10:33:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 10:33:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-14 10:33:39 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\fish\admin\application\views\product\productautocompletion.php 5
ERROR - 2016-01-14 10:33:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 107
ERROR - 2016-01-14 10:33:39 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 120
ERROR - 2016-01-14 10:33:39 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-14 10:33:39 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-14 10:33:39 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 125
ERROR - 2016-01-14 10:33:39 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 127
ERROR - 2016-01-14 10:33:39 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 143
ERROR - 2016-01-14 10:33:39 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 169
ERROR - 2016-01-14 10:33:39 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 187
ERROR - 2016-01-14 10:33:39 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 210
ERROR - 2016-01-14 10:33:39 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 232
ERROR - 2016-01-14 10:33:39 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 258
ERROR - 2016-01-14 10:33:39 --> Severity: Notice  --> Undefined variable: availability C:\xampp\htdocs\fish\admin\application\views\product\productmanage.php 279
ERROR - 2016-01-14 10:41:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fish\admin\system\database\drivers\mysql\mysql_driver.php 92
