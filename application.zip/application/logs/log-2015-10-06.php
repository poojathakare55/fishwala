<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-06 07:45:48 --> Severity: Warning  --> include(C:\xampp\htdocs\classfeverevent\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\classfeverevent\admin\application\views\v_main.php 147
ERROR - 2015-10-06 07:45:48 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\classfeverevent\admin\application\views\v_main.php 147
ERROR - 2015-10-06 07:45:55 --> Severity: Notice  --> Undefined index: attendance C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 302
ERROR - 2015-10-06 07:45:55 --> Severity: Notice  --> Undefined index: attendance C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 308
ERROR - 2015-10-06 07:45:55 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 07:45:55 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 07:45:55 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 07:45:55 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 07:45:55 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 07:45:55 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 07:45:55 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 07:45:55 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 07:45:55 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 07:45:55 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 07:45:56 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 07:45:56 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 07:45:56 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 07:45:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\classfeverevent\admin\application\views\eventtypemanage.php 77
ERROR - 2015-10-06 07:45:57 --> Severity: Notice  --> Undefined variable: event_type C:\xampp\htdocs\classfeverevent\admin\application\views\eventtypemanage.php 88
ERROR - 2015-10-06 07:45:57 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\classfeverevent\admin\application\views\eventtypemanage.php 101
ERROR - 2015-10-06 07:45:57 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\classfeverevent\admin\application\views\eventtypemanage.php 105
ERROR - 2015-10-06 07:45:57 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfeverevent\admin\application\views\eventtypemanage.php 105
ERROR - 2015-10-06 07:45:57 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\classfeverevent\admin\application\views\eventtypemanage.php 106
ERROR - 2015-10-06 07:45:57 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\classfeverevent\admin\application\views\eventtypemanage.php 108
ERROR - 2015-10-06 07:45:57 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 44
ERROR - 2015-10-06 07:45:57 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 45
ERROR - 2015-10-06 07:45:57 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 46
ERROR - 2015-10-06 08:01:38 --> Severity: Notice  --> Undefined index: attendance C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 302
ERROR - 2015-10-06 08:01:38 --> Severity: Notice  --> Undefined index: attendance C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 308
ERROR - 2015-10-06 08:01:38 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 08:01:38 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 08:01:38 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 08:01:38 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 08:01:38 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 08:01:38 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 08:01:38 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 08:01:38 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 08:01:38 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 08:01:38 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 08:01:38 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 08:01:39 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 08:01:39 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 417
ERROR - 2015-10-06 08:01:39 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfeverevent\admin\application\views\eventtypemanage.php 105
ERROR - 2015-10-06 08:01:39 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 44
ERROR - 2015-10-06 08:01:39 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 45
ERROR - 2015-10-06 08:01:39 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\classfeverevent\admin\application\models\event_model.php 46
