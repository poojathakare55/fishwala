<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-16 05:43:25 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-02-16 06:06:43 --> Severity: Notice  --> Undefined variable: category_id /home/fishwqrb/public_html/admin/application/controllers/baang.php 1022
