<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-28 07:12:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 07:12:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 07:12:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 07:12:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 07:17:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 07:17:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-28 07:17:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-28 07:17:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-28 07:17:58 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-28 07:17:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-28 07:17:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-28 07:17:58 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 07:17:58 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-28 07:17:58 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-28 07:17:58 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-28 07:17:58 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-28 07:17:58 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-28 08:00:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:00:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-28 08:00:14 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-28 08:00:14 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-28 08:00:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:00:17 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2015-12-28 08:00:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2015-12-28 08:00:17 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2015-12-28 08:00:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:00:23 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-28 08:00:23 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-28 08:00:23 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-28 08:00:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:00:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:00:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-28 08:00:32 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-28 08:00:32 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-28 08:00:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:00:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:00:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-28 08:00:37 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-28 08:00:37 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-28 08:00:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:00:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:00:41 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-28 08:00:41 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-28 08:00:41 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-28 08:00:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:00:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:00:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-28 08:00:49 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-28 08:00:49 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-28 08:00:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:00:51 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2015-12-28 08:00:51 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2015-12-28 08:00:51 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2015-12-28 08:00:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:00:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:00:59 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-28 08:00:59 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-28 08:00:59 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-28 08:01:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:01:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:01:15 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-28 08:01:15 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-28 08:01:15 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-28 08:01:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:01:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:01:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-28 08:01:26 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-28 08:01:26 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-28 08:01:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:01:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:01:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-28 08:01:35 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-28 08:01:35 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-28 08:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:01:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-28 08:01:43 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-28 08:01:43 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-28 08:01:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:01:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:01:50 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-28 08:01:50 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-28 08:01:50 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-28 08:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:01:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-28 08:01:55 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-28 08:01:55 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-28 08:02:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:02:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:02:02 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-28 08:02:02 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-28 08:02:02 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-28 08:02:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:02:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:02:09 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2015-12-28 08:02:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2015-12-28 08:02:09 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2015-12-28 08:02:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:02:15 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-28 08:02:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-28 08:02:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-28 08:02:15 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-28 08:02:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-28 08:02:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-28 08:02:15 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 08:02:15 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-28 08:02:15 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-28 08:02:15 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-28 08:02:15 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-28 08:02:15 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-28 08:02:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:02:39 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 59
ERROR - 2015-12-28 08:02:39 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 70
ERROR - 2015-12-28 08:02:39 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 88
ERROR - 2015-12-28 08:06:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:06:33 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:06:33 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:06:33 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:06:33 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:06:33 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:06:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2015-12-28 08:06:33 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2015-12-28 08:06:33 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 132
ERROR - 2015-12-28 08:07:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:07:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:07:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:07:26 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:07:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:07:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:07:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2015-12-28 08:07:26 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2015-12-28 08:07:26 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 132
ERROR - 2015-12-28 08:07:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:07:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:07:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:07:48 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:07:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:07:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:08:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:08:09 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 197
ERROR - 2015-12-28 08:08:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:08:09 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:08:09 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:08:09 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:08:09 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:08:09 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:08:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2015-12-28 08:08:09 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2015-12-28 08:08:09 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 132
ERROR - 2015-12-28 08:09:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:09:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:09:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:12 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:09:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:09:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:09:16 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 198
ERROR - 2015-12-28 08:09:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:09:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:09:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:17 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:09:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:09:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2015-12-28 08:09:17 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2015-12-28 08:09:17 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 132
ERROR - 2015-12-28 08:09:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:09:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:09:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:21 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:09:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:09:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:09:27 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 198
ERROR - 2015-12-28 08:09:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:09:27 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:09:27 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:27 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:27 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:09:27 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:09:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2015-12-28 08:09:27 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2015-12-28 08:09:27 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 132
ERROR - 2015-12-28 08:09:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:09:30 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:09:30 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:30 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:30 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:09:30 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:09:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:09:36 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 198
ERROR - 2015-12-28 08:09:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:09:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:09:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:37 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:09:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:09:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2015-12-28 08:09:37 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2015-12-28 08:09:37 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 132
ERROR - 2015-12-28 08:09:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:09:42 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:09:42 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:42 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:42 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:09:42 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:09:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:09:47 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 198
ERROR - 2015-12-28 08:09:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:09:47 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:09:47 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:47 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:47 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:09:47 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:09:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2015-12-28 08:09:47 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2015-12-28 08:09:47 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 132
ERROR - 2015-12-28 08:09:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:09:50 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:09:50 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:50 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:09:50 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:09:50 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:10:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:10:08 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 198
ERROR - 2015-12-28 08:10:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:10:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:10:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:10:08 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:10:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:10:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:10:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2015-12-28 08:10:08 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2015-12-28 08:10:08 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 132
ERROR - 2015-12-28 08:10:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:10:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:10:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:10:13 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:10:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:10:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:10:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:10:20 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 198
ERROR - 2015-12-28 08:10:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:10:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:10:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:10:20 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:10:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:10:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:10:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2015-12-28 08:10:20 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2015-12-28 08:10:20 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 132
ERROR - 2015-12-28 08:10:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:10:53 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:10:53 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:10:53 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:10:53 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:10:53 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:10:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2015-12-28 08:10:53 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2015-12-28 08:10:53 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 132
ERROR - 2015-12-28 08:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:11:16 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-28 08:11:16 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:11:16 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-28 08:11:16 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-28 08:11:16 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-28 08:11:16 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2015-12-28 08:11:16 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2015-12-28 08:11:16 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 132
ERROR - 2015-12-28 08:22:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 08:22:15 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-28 08:22:15 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-28 08:22:15 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-28 08:22:15 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-28 10:04:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 10:04:05 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-28 10:04:05 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-28 10:04:05 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-28 10:04:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-28 10:04:05 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-28 10:04:05 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-28 10:04:05 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 10:04:05 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-28 10:04:05 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-28 10:04:05 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-28 10:04:05 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-28 10:04:05 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-28 10:08:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 10:08:48 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2015-12-28 10:08:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2015-12-28 10:08:48 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2015-12-28 10:08:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 10:08:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 10:08:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 10:08:53 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2015-12-28 10:08:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2015-12-28 10:08:53 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2015-12-28 10:08:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 10:09:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 10:09:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 10:09:01 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2015-12-28 10:09:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2015-12-28 10:09:01 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2015-12-28 10:24:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 10:24:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 10:24:32 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2015-12-28 10:24:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2015-12-28 10:24:32 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2015-12-28 10:24:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 10:24:35 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-28 10:24:35 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-28 10:24:35 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-28 10:24:35 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-28 10:24:35 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-28 10:24:35 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-28 10:24:35 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 10:24:35 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-28 10:24:35 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-28 10:24:35 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-28 10:24:35 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-28 10:24:35 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-28 10:25:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 10:25:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 10:25:55 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 684
ERROR - 2015-12-28 10:25:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 10:25:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-28 10:25:55 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-28 10:25:55 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-28 10:25:55 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-28 10:25:55 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-28 10:25:55 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-28 10:25:55 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 10:25:55 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-28 10:25:55 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-28 10:25:55 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-28 10:25:55 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-28 10:25:55 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-28 10:26:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 10:26:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 10:26:57 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 684
ERROR - 2015-12-28 10:26:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 10:26:57 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-28 10:26:57 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-28 10:26:57 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-28 10:26:57 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-28 10:26:57 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-28 10:26:57 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-28 10:26:57 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 10:26:57 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-28 10:26:57 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-28 10:26:57 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-28 10:26:57 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-28 10:26:57 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-28 11:03:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 11:03:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 12:06:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 12:07:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 12:27:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 12:28:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 12:28:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 12:30:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 12:31:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 12:31:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 12:31:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 12:32:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:06:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:06:15 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-28 13:06:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-28 13:06:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-28 13:06:15 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-28 13:06:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-28 13:06:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-28 13:06:15 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 13:06:15 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-28 13:06:15 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-28 13:06:15 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-28 13:06:15 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-28 13:06:15 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-28 13:06:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:06:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:06:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 83
ERROR - 2015-12-28 13:06:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 96
ERROR - 2015-12-28 13:06:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-28 13:06:37 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 100
ERROR - 2015-12-28 13:06:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-28 13:06:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 103
ERROR - 2015-12-28 13:06:37 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 13:06:37 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 145
ERROR - 2015-12-28 13:06:37 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-28 13:06:37 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 185
ERROR - 2015-12-28 13:06:37 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 207
ERROR - 2015-12-28 13:06:37 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 233
ERROR - 2015-12-28 13:18:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:18:49 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:18:49 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 101
ERROR - 2015-12-28 13:18:49 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 114
ERROR - 2015-12-28 13:18:49 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 118
ERROR - 2015-12-28 13:18:49 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 118
ERROR - 2015-12-28 13:18:49 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 13:18:49 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 121
ERROR - 2015-12-28 13:18:49 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 137
ERROR - 2015-12-28 13:18:49 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 163
ERROR - 2015-12-28 13:18:49 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 181
ERROR - 2015-12-28 13:18:49 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 203
ERROR - 2015-12-28 13:18:49 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 225
ERROR - 2015-12-28 13:18:49 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 251
ERROR - 2015-12-28 13:19:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:19:22 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:19:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-28 13:19:22 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-28 13:19:22 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:19:22 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:19:22 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-28 13:19:22 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 13:19:22 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-28 13:19:22 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-28 13:19:22 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-28 13:19:22 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-28 13:19:22 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-28 13:19:22 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-28 13:19:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:19:40 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:19:40 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:19:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:19:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:19:48 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:19:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-28 13:19:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-28 13:19:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:19:48 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:19:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-28 13:19:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 13:19:48 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-28 13:19:48 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-28 13:19:48 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-28 13:19:48 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-28 13:19:48 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-28 13:19:48 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-28 13:19:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:19:56 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:19:56 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:20:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:20:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:20:00 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:20:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-28 13:20:00 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-28 13:20:00 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:20:00 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:20:00 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-28 13:20:00 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 13:20:00 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-28 13:20:00 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-28 13:20:00 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-28 13:20:00 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-28 13:20:00 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-28 13:20:00 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-28 13:20:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:20:26 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:20:26 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:20:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:20:27 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:20:27 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:20:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:20:28 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:20:28 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:20:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:20:29 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:20:29 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:20:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:20:30 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:20:30 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:20:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:20:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:20:42 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:20:42 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-28 13:20:42 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-28 13:20:42 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:20:42 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:20:42 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-28 13:20:42 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 13:20:42 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-28 13:20:42 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-28 13:20:42 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-28 13:20:42 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-28 13:20:42 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-28 13:20:42 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-28 13:20:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:20:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:20:46 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:20:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-28 13:20:46 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-28 13:20:46 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:20:46 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:20:46 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-28 13:20:46 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 13:20:46 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-28 13:20:46 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-28 13:20:46 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-28 13:20:46 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-28 13:20:46 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-28 13:20:46 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-28 13:20:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:20:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:20:56 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:20:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-28 13:20:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-28 13:20:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:20:56 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:20:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-28 13:20:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 13:20:56 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-28 13:20:56 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-28 13:20:56 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-28 13:20:56 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-28 13:20:56 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-28 13:20:56 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-28 13:21:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:21:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:21:01 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:21:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-28 13:21:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-28 13:21:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:21:01 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:21:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-28 13:21:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 13:21:01 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-28 13:21:01 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-28 13:21:01 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-28 13:21:01 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-28 13:21:01 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-28 13:21:01 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-28 13:21:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:21:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:21:06 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:21:06 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-28 13:21:06 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-28 13:21:06 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:21:06 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:21:06 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-28 13:21:06 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 13:21:06 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-28 13:21:06 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-28 13:21:06 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-28 13:21:06 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-28 13:21:06 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-28 13:21:06 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-28 13:21:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:21:10 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:21:10 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-28 13:21:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-28 13:21:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:21:10 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:21:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-28 13:21:10 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 13:21:10 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-28 13:21:10 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-28 13:21:10 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-28 13:21:10 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-28 13:21:10 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-28 13:21:10 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-28 13:21:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:21:33 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:21:33 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:21:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:21:48 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:21:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-28 13:21:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-28 13:21:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:21:48 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:21:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-28 13:21:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 13:21:48 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-28 13:21:48 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-28 13:21:48 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-28 13:21:48 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-28 13:21:48 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-28 13:21:48 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-28 13:21:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:22:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:22:26 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 684
ERROR - 2015-12-28 13:22:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:22:26 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:22:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-28 13:22:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-28 13:22:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:22:26 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:22:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-28 13:22:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 13:22:26 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-28 13:22:26 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-28 13:22:26 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-28 13:22:26 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-28 13:22:26 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-28 13:22:26 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-28 13:22:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:23:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:23:13 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 684
ERROR - 2015-12-28 13:23:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:23:13 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:23:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-28 13:23:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-28 13:23:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:23:13 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:23:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-28 13:23:13 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 13:23:13 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-28 13:23:13 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-28 13:23:13 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-28 13:23:13 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-28 13:23:13 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-28 13:23:13 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-28 13:23:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:23:17 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:23:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-28 13:23:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-28 13:23:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:23:17 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:23:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-28 13:23:17 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 13:23:17 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-28 13:23:17 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-28 13:23:17 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-28 13:23:17 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-28 13:23:17 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-28 13:23:17 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-28 13:23:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-28 13:23:20 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-28 13:23:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-28 13:23:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-28 13:23:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:23:20 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-28 13:23:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-28 13:23:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-28 13:23:20 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-28 13:23:20 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-28 13:23:20 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-28 13:23:20 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-28 13:23:20 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-28 13:23:20 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
