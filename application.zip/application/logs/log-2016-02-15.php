<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-15 05:42:46 --> Severity: Notice  --> Undefined variable: id /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 42
ERROR - 2016-02-15 05:42:46 --> Severity: Notice  --> Undefined variable: name /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 63
ERROR - 2016-02-15 05:42:46 --> Severity: Notice  --> Undefined variable: emailid /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 87
ERROR - 2016-02-15 05:42:46 --> Severity: Notice  --> Undefined variable: contactno /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 110
ERROR - 2016-02-15 05:42:46 --> Severity: Notice  --> Undefined variable: address /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 135
ERROR - 2016-02-15 05:42:46 --> Severity: Notice  --> Undefined variable: password /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 185
ERROR - 2016-02-15 05:42:56 --> Severity: Notice  --> Undefined index: password /home/fishwqrb/public_html/admin/application/controllers/baang.php 512
ERROR - 2016-02-15 05:42:56 --> Severity: Notice  --> Undefined variable: id /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 42
ERROR - 2016-02-15 05:42:56 --> Severity: Notice  --> Undefined variable: name /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 63
ERROR - 2016-02-15 05:42:56 --> Severity: Notice  --> Undefined variable: emailid /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 87
ERROR - 2016-02-15 05:42:56 --> Severity: Notice  --> Undefined variable: contactno /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 110
ERROR - 2016-02-15 05:42:56 --> Severity: Notice  --> Undefined variable: address /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 135
ERROR - 2016-02-15 05:42:56 --> Severity: Notice  --> Undefined variable: password /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 185
ERROR - 2016-02-15 05:43:04 --> Severity: Notice  --> Undefined index: password /home/fishwqrb/public_html/admin/application/controllers/baang.php 512
ERROR - 2016-02-15 05:43:04 --> Severity: Notice  --> Undefined variable: id /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 42
ERROR - 2016-02-15 05:43:04 --> Severity: Notice  --> Undefined variable: name /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 63
ERROR - 2016-02-15 05:43:04 --> Severity: Notice  --> Undefined variable: emailid /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 87
ERROR - 2016-02-15 05:43:04 --> Severity: Notice  --> Undefined variable: contactno /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 110
ERROR - 2016-02-15 05:43:04 --> Severity: Notice  --> Undefined variable: address /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 135
ERROR - 2016-02-15 05:43:04 --> Severity: Notice  --> Undefined variable: password /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 185
ERROR - 2016-02-15 05:43:44 --> Severity: Notice  --> Undefined variable: id /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 42
ERROR - 2016-02-15 05:43:44 --> Severity: Notice  --> Undefined variable: name /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 63
ERROR - 2016-02-15 05:43:44 --> Severity: Notice  --> Undefined variable: emailid /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 87
ERROR - 2016-02-15 05:43:44 --> Severity: Notice  --> Undefined variable: contactno /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 110
ERROR - 2016-02-15 05:43:44 --> Severity: Notice  --> Undefined variable: address /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 135
ERROR - 2016-02-15 05:43:44 --> Severity: Notice  --> Undefined variable: password /home/fishwqrb/public_html/admin/application/views/employee/employeemanage.php 185
