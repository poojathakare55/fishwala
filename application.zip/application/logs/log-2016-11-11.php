<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-11-11 15:05:44 --> Severity: Notice  --> Undefined variable: category_id /home/fishwqrb/public_html/admin/application/controllers/baang.php 1022
