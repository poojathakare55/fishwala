<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-03-30 06:47:38 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-03-30 06:47:38 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-03-30 06:47:38 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-03-30 06:47:38 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-03-30 06:47:38 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-03-30 06:47:38 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-03-30 07:17:29 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-03-30 07:17:29 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-03-30 07:17:29 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-03-30 07:17:29 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-03-30 07:17:29 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-03-30 07:17:29 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-03-30 07:17:29 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
