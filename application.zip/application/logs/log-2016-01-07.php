<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-01-07 16:12:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:12:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:12:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:12:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:12:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:12:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:15:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:20:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:24:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:24:40 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2016-01-07 16:24:40 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2016-01-07 16:24:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 107
ERROR - 2016-01-07 16:24:40 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 120
ERROR - 2016-01-07 16:24:40 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-07 16:24:40 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-07 16:24:40 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 125
ERROR - 2016-01-07 16:24:40 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 127
ERROR - 2016-01-07 16:24:40 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 143
ERROR - 2016-01-07 16:24:40 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 169
ERROR - 2016-01-07 16:24:40 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 187
ERROR - 2016-01-07 16:24:40 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 210
ERROR - 2016-01-07 16:24:40 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 232
ERROR - 2016-01-07 16:24:40 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 258
ERROR - 2016-01-07 16:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:24:47 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2016-01-07 16:24:47 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2016-01-07 16:24:47 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-07 16:24:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:24:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:24:52 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2016-01-07 16:24:52 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2016-01-07 16:24:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 107
ERROR - 2016-01-07 16:24:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 120
ERROR - 2016-01-07 16:24:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-07 16:24:52 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-07 16:24:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 125
ERROR - 2016-01-07 16:24:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 127
ERROR - 2016-01-07 16:24:52 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 143
ERROR - 2016-01-07 16:24:52 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 169
ERROR - 2016-01-07 16:24:52 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 187
ERROR - 2016-01-07 16:24:52 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 210
ERROR - 2016-01-07 16:24:52 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 232
ERROR - 2016-01-07 16:24:52 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 258
ERROR - 2016-01-07 16:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:24:57 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2016-01-07 16:24:57 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2016-01-07 16:24:57 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-07 16:25:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:25:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:25:00 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2016-01-07 16:25:00 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2016-01-07 16:25:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 107
ERROR - 2016-01-07 16:25:00 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 120
ERROR - 2016-01-07 16:25:00 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-07 16:25:00 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2016-01-07 16:25:00 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 125
ERROR - 2016-01-07 16:25:00 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 127
ERROR - 2016-01-07 16:25:00 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 143
ERROR - 2016-01-07 16:25:00 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 169
ERROR - 2016-01-07 16:25:00 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 187
ERROR - 2016-01-07 16:25:00 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 210
ERROR - 2016-01-07 16:25:00 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 232
ERROR - 2016-01-07 16:25:00 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 258
ERROR - 2016-01-07 15:34:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 15:37:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 15:37:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 15:37:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 15:38:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 15:51:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:19:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:19:10 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 66
ERROR - 2016-01-07 16:19:10 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 66
ERROR - 2016-01-07 16:19:10 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 66
ERROR - 2016-01-07 16:19:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:20:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-07 16:20:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
