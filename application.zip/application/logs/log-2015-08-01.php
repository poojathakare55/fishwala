<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-01 07:21:07 --> Severity: Warning  --> include(C:\xampp\htdocs\classfever\eventadmin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\classfever\eventadmin\application\views\v_main.php 146
ERROR - 2015-08-01 07:21:07 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\classfever\eventadmin\application\views\v_main.php 146
ERROR - 2015-08-01 07:21:12 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\classfever\eventadmin\application\views\schoolnameautocompletion.php 5
ERROR - 2015-08-01 07:21:13 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\classfever\eventadmin\application\views\cityautocompletion.php 5
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: disabled C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 274
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: chkschoolnostatus C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 279
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: disabled C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 279
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: schoolname C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 296
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: school_id C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 306
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: event_name C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 328
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: event_type C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 347
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: event_location C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 362
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: fees C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 383
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 403
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: age C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 423
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: cityname C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 443
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: city C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 455
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: districtname C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 479
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 491
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: statename C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 512
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: state C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 524
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: chkmalestatus C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 542
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: disabled C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 542
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: chkfemalestatus C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 547
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: disabled C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 547
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: chkbothstatus C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 552
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: disabled C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 552
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: website C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 569
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: contact_person C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 589
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: event_date C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 608
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: application_deadline C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 628
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: participating_schools C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 648
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: prestige_rating C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 667
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: event_level C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 681
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: selectedevent_awardsarray C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 695
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: event_awards C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 696
ERROR - 2015-08-01 07:21:14 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\classfever\eventadmin\application\views\eventpostmanage.php 712
ERROR - 2015-08-01 15:43:41 --> Severity: Warning  --> include(C:\xampp\htdocs\classfever\eventadmin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\classfever\eventadmin\application\views\v_main.php 146
ERROR - 2015-08-01 15:43:41 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\classfever\eventadmin\application\views\v_main.php 146
ERROR - 2015-08-01 15:43:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\classfever\eventadmin\application\views\eventawardsmanage.php 47
ERROR - 2015-08-01 15:43:48 --> Severity: Notice  --> Undefined variable: award_name C:\xampp\htdocs\classfever\eventadmin\application\views\eventawardsmanage.php 58
ERROR - 2015-08-01 15:43:48 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 44
ERROR - 2015-08-01 15:43:48 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 45
ERROR - 2015-08-01 15:43:48 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 46
ERROR - 2015-08-01 15:44:18 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 44
ERROR - 2015-08-01 15:44:18 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 45
ERROR - 2015-08-01 15:44:18 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 46
ERROR - 2015-08-01 15:45:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\classfever\eventadmin\application\views\eventlevelmanage.php 47
ERROR - 2015-08-01 15:45:12 --> Severity: Notice  --> Undefined variable: level_name C:\xampp\htdocs\classfever\eventadmin\application\views\eventlevelmanage.php 58
ERROR - 2015-08-01 15:45:12 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 44
ERROR - 2015-08-01 15:45:12 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 45
ERROR - 2015-08-01 15:45:12 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 46
ERROR - 2015-08-01 15:45:26 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 44
ERROR - 2015-08-01 15:45:26 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 45
ERROR - 2015-08-01 15:45:26 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 46
ERROR - 2015-08-01 15:45:42 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\classfever\eventadmin\application\views\eventlevelmanage.php 47
ERROR - 2015-08-01 15:45:42 --> Severity: Notice  --> Undefined variable: level_name C:\xampp\htdocs\classfever\eventadmin\application\views\eventlevelmanage.php 58
ERROR - 2015-08-01 15:45:42 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 44
ERROR - 2015-08-01 15:45:42 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 45
ERROR - 2015-08-01 15:45:42 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 46
ERROR - 2015-08-01 15:45:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\classfever\eventadmin\application\views\eventlevelmanage.php 47
ERROR - 2015-08-01 15:45:46 --> Severity: Notice  --> Undefined variable: level_name C:\xampp\htdocs\classfever\eventadmin\application\views\eventlevelmanage.php 58
ERROR - 2015-08-01 15:45:46 --> Severity: Notice  --> Undefined index: condition C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 44
ERROR - 2015-08-01 15:45:46 --> Severity: Notice  --> Undefined index: limit C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 45
ERROR - 2015-08-01 15:45:46 --> Severity: Notice  --> Undefined index: offset C:\xampp\htdocs\classfever\eventadmin\application\models\event_model.php 46
