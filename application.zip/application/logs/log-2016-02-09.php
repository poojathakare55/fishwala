<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-09 05:28:53 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-02-09 05:28:53 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-02-09 05:28:53 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-02-09 16:59:56 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-02-09 16:59:56 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
ERROR - 2016-02-09 17:00:04 --> Severity: Notice  --> Undefined index: delivery_time /home/fishwqrb/public_html/admin/application/views/order/newordergrid.php 112
