<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-31 00:01:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:01:15 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 00:01:15 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 00:01:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 00:01:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 00:01:15 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 00:01:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 00:01:15 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 00:01:15 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 00:01:15 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 00:01:15 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 00:01:15 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 00:01:15 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 00:01:15 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 00:01:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:01:42 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 00:01:42 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 00:03:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:03:15 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 00:03:15 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 00:05:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:05:52 --> 404 Page Not Found --> baang/orderdetails
ERROR - 2015-12-31 00:18:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:18:25 --> Severity: Notice  --> Undefined index: order_no C:\xampp\htdocs\baang\admin\application\views\order\orderdetails.php 12
ERROR - 2015-12-31 00:19:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:19:11 --> Severity: Notice  --> Undefined index: order_no C:\xampp\htdocs\baang\admin\application\views\order\orderdetails.php 12
ERROR - 2015-12-31 00:19:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:20:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:20:13 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:21:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:21:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:22:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:23:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:25:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:25:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:26:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:26:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:29:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:33:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:33:25 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 00:33:25 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 00:33:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:37:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:38:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:39:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:39:51 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 00:39:51 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 00:41:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:41:37 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 00:41:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 00:41:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 00:41:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 00:41:37 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 00:41:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 00:41:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 00:41:37 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 00:41:37 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 00:41:37 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 00:41:37 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 00:41:37 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 00:41:37 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 00:41:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:42:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:42:55 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 00:42:55 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 00:42:55 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 00:42:55 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 00:42:55 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 00:42:55 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 00:42:55 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 00:42:55 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 00:42:55 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 00:42:55 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 00:42:55 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 00:42:55 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 00:42:55 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 00:43:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:43:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:43:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:43:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:45:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:45:13 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-31 00:45:13 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-31 00:45:13 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-31 00:45:13 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-31 00:45:13 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-31 00:45:13 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-31 00:46:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:46:24 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 00:46:24 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 00:46:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:46:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 00:46:50 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 00:46:50 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 03:59:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:43:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:43:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:43:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:43:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:43:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:43:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-31 06:43:47 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-31 06:43:47 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-31 06:43:47 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-31 06:43:47 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-31 06:43:47 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-31 06:48:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:48:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:48:21 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\baang\admin\application\controllers\baang.php 500
ERROR - 2015-12-31 06:48:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:48:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-31 06:48:21 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-31 06:48:21 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-31 06:48:21 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-31 06:48:21 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-31 06:48:21 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-31 06:48:21 --> Severity: Notice  --> Undefined variable: usertype C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 202
ERROR - 2015-12-31 06:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:49:17 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-31 06:49:17 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-31 06:49:17 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-31 06:49:17 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-31 06:49:17 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-31 06:49:17 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-31 06:49:17 --> Severity: Notice  --> Undefined variable: usertype C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 202
ERROR - 2015-12-31 06:52:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:53:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:53:43 --> Severity: Notice  --> Undefined index: usertype C:\xampp\htdocs\baang\admin\application\models\baang_model.php 280
ERROR - 2015-12-31 06:53:43 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\baang\admin\application\controllers\baang.php 36
ERROR - 2015-12-31 06:53:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-31 06:53:43 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-31 06:53:43 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-31 06:53:43 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-31 06:53:43 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-31 06:53:43 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-31 06:53:43 --> Severity: Notice  --> Undefined variable: usertype C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 202
ERROR - 2015-12-31 06:54:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:54:12 --> Severity: Notice  --> Undefined index: usertype C:\xampp\htdocs\baang\admin\application\models\baang_model.php 280
ERROR - 2015-12-31 06:54:12 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\baang\admin\application\controllers\baang.php 36
ERROR - 2015-12-31 06:54:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-31 06:54:12 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-31 06:54:12 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-31 06:54:12 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-31 06:54:12 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-31 06:54:12 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-31 06:54:12 --> Severity: Notice  --> Undefined variable: usertype C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 202
ERROR - 2015-12-31 06:54:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:54:42 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\baang\admin\application\controllers\baang.php 36
ERROR - 2015-12-31 06:54:42 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-31 06:54:42 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-31 06:54:42 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-31 06:54:42 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-31 06:54:42 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-31 06:54:42 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-31 06:54:42 --> Severity: Notice  --> Undefined variable: usertype C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 202
ERROR - 2015-12-31 06:55:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:55:20 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\baang\admin\application\controllers\baang.php 36
ERROR - 2015-12-31 06:55:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-31 06:55:20 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-31 06:55:20 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-31 06:55:20 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-31 06:55:20 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-31 06:55:20 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-31 06:55:20 --> Severity: Notice  --> Undefined variable: usertype C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 202
ERROR - 2015-12-31 06:56:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:56:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-31 06:56:04 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-31 06:56:04 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-31 06:56:04 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-31 06:56:04 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-31 06:56:04 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-31 06:56:04 --> Severity: Notice  --> Undefined variable: usertype C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 202
ERROR - 2015-12-31 06:56:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:57:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:57:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:57:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:57:44 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 06:57:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 06:57:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 06:57:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 06:57:44 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 06:57:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 06:57:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 06:57:44 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 06:57:44 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 06:57:44 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 06:57:44 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 06:57:44 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 06:57:44 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 06:58:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 06:58:43 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 06:58:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 06:58:43 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 06:58:43 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 06:58:43 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 06:58:43 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 06:58:43 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 06:58:43 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 06:58:43 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 06:58:43 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 06:58:43 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 06:58:43 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 06:58:43 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:00:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:00:08 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 07:00:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 07:00:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 07:00:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:00:08 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:00:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 07:00:08 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 07:00:08 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 07:00:08 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 07:00:08 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 07:00:08 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 07:00:08 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 07:00:08 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:00:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:00:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:00:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:01:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:01:45 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 07:01:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 07:01:45 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 07:01:45 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:01:45 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:01:45 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 07:01:45 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 07:01:45 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 07:01:45 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 07:01:45 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 07:01:45 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 07:01:45 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 07:01:45 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:04:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:04:26 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 07:04:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 07:04:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 07:04:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:04:26 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:04:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 07:04:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 07:04:26 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 07:04:26 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 07:04:26 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 07:04:26 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 07:04:26 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 07:04:26 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:05:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:05:05 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 07:05:05 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 07:05:05 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 07:05:05 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:05:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:05:05 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 07:05:05 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 07:05:05 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 07:05:05 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 07:05:05 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 07:05:05 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 07:05:05 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 07:05:05 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:05:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:05:54 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 07:05:54 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 07:05:54 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 07:05:54 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:05:54 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:05:54 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 07:05:54 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 07:05:54 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 07:05:54 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 07:05:54 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 07:05:54 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 07:05:54 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 07:05:54 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:07:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:07:09 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 07:07:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 07:07:09 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 07:07:09 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:07:09 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:07:09 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 07:07:09 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 07:07:09 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 07:07:09 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 07:07:09 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 07:07:09 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 07:07:09 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 07:07:09 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:07:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:07:16 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\baang\admin\application\controllers\baang.php 42
ERROR - 2015-12-31 07:07:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:07:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:07:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:07:32 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 07:07:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 07:07:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 07:07:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:07:32 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:07:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 07:07:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 07:07:32 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 07:07:32 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 07:07:32 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 07:07:32 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 07:07:32 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 07:07:32 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:07:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:07:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:07:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:07:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:07:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:07:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:08:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:08:01 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 07:08:01 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 07:08:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 07:08:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:08:01 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:08:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 07:08:01 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 07:08:01 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 07:08:01 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 07:08:01 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 07:08:01 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 07:08:01 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 07:08:01 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:09:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:09:14 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 07:09:14 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 07:09:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 07:09:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:09:14 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:09:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 07:09:14 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 07:09:14 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 07:09:14 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 07:09:14 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 07:09:14 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 07:09:14 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 07:09:14 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:09:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:09:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:09:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:09:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:09:44 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 07:09:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 07:09:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 07:09:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:09:44 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:09:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 07:09:44 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 07:09:44 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 07:09:44 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 07:09:44 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 07:09:44 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 07:09:44 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 07:09:44 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:12:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:12:56 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2015-12-31 07:12:56 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 07:12:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 07:12:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 07:12:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:12:56 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:12:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 07:12:56 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 07:12:56 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 07:12:56 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 07:12:56 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 07:12:56 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 07:12:56 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 07:12:56 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:13:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:13:09 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2015-12-31 07:13:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2015-12-31 07:13:09 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2015-12-31 07:13:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:13:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:13:19 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2015-12-31 07:13:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2015-12-31 07:13:19 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2015-12-31 07:13:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:13:21 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2015-12-31 07:13:21 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 07:13:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 07:13:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 07:13:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:13:21 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:13:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 07:13:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 07:13:21 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 07:13:21 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 07:13:21 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 07:13:21 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 07:13:21 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 07:13:21 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:13:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:13:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:13:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:13:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:13:32 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 07:13:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 07:13:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 07:13:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:13:32 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:13:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 07:13:32 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 07:13:32 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 07:13:32 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 07:13:32 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 07:13:32 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 07:13:32 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 07:13:32 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:13:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:13:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:13:52 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 07:13:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 07:13:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 07:13:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:13:52 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:13:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 07:13:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 07:13:52 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 07:13:52 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 07:13:52 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 07:13:52 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 07:13:52 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 07:13:52 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:13:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:14:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:14:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:14:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:14:04 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2015-12-31 07:14:04 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 07:14:04 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 07:14:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 07:14:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:14:04 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:14:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 07:14:04 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 07:14:04 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 07:14:04 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 07:14:04 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 07:14:04 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 07:14:04 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 07:14:04 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:16:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:16:09 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-31 07:16:09 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-31 07:16:09 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-31 07:16:09 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-31 07:16:09 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-31 07:16:09 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-31 07:16:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:16:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:16:37 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2015-12-31 07:16:37 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 07:16:37 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 07:16:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 07:16:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:16:37 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:16:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 07:16:37 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 07:16:37 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 07:16:37 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 07:16:37 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 07:16:37 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 07:16:37 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 07:16:37 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:16:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:16:49 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 07:16:49 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 07:22:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:24:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:24:28 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 07:24:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:24:33 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 07:25:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:25:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:25:10 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 07:27:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:28:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:28:38 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2015-12-31 07:28:38 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 07:28:38 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 07:28:38 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 07:28:38 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:28:38 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 07:28:38 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 07:28:38 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 07:28:38 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 07:28:38 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 07:28:38 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 07:28:38 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 07:28:38 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 07:28:38 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 07:28:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:28:41 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 48
ERROR - 2015-12-31 07:28:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:28:44 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 48
ERROR - 2015-12-31 07:31:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:31:04 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 48
ERROR - 2015-12-31 07:31:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:31:45 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 49
ERROR - 2015-12-31 07:32:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:32:58 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 49
ERROR - 2015-12-31 07:33:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:33:22 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 49
ERROR - 2015-12-31 07:33:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:33:38 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 49
ERROR - 2015-12-31 07:35:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:35:24 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 48
ERROR - 2015-12-31 07:35:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:35:52 --> Severity: Notice  --> Undefined index: order_no C:\xampp\htdocs\baang\admin\application\views\order\orderdetails.php 12
ERROR - 2015-12-31 07:35:52 --> Severity: Notice  --> Undefined index: customer C:\xampp\htdocs\baang\admin\application\views\order\orderdetails.php 12
ERROR - 2015-12-31 07:35:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:35:55 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 48
ERROR - 2015-12-31 07:47:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:47:24 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 07:47:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:47:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:49:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:49:50 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 07:51:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:51:40 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 07:51:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:51:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:54:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:54:05 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 07:54:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:54:08 --> Severity: Notice  --> Undefined index: order_no C:\xampp\htdocs\baang\admin\application\controllers\baang.php 890
ERROR - 2015-12-31 07:54:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:54:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:54:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:54:58 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 07:55:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:55:37 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 07:55:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:55:51 --> Severity: Notice  --> Undefined index: order_no C:\xampp\htdocs\baang\admin\application\controllers\baang.php 890
ERROR - 2015-12-31 07:56:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:56:04 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 07:57:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 07:57:38 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 08:00:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:00:35 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 08:02:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:02:33 --> Severity: Notice  --> Undefined index: order_no C:\xampp\htdocs\baang\admin\application\views\order\orderdetails.php 12
ERROR - 2015-12-31 08:02:33 --> Severity: Notice  --> Undefined index: customer C:\xampp\htdocs\baang\admin\application\views\order\orderdetails.php 12
ERROR - 2015-12-31 08:02:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:02:37 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 08:02:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:08:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:08:36 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 08:08:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:17:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:17:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:17:09 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 08:17:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:22:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:22:42 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 08:24:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:33:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:33:43 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 08:35:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:35:33 --> Severity: Notice  --> Undefined index: order_no C:\xampp\htdocs\baang\admin\application\controllers\baang.php 890
ERROR - 2015-12-31 08:35:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:35:39 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 08:37:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:37:23 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 08:37:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:37:47 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 08:37:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:37:51 --> Severity: Notice  --> Undefined index: order_no C:\xampp\htdocs\baang\admin\application\controllers\baang.php 890
ERROR - 2015-12-31 08:38:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:38:09 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 08:38:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:38:12 --> Severity: Notice  --> Undefined index: order_no C:\xampp\htdocs\baang\admin\application\controllers\baang.php 890
ERROR - 2015-12-31 08:38:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:38:13 --> Severity: Notice  --> Undefined index: order_no C:\xampp\htdocs\baang\admin\application\controllers\baang.php 890
ERROR - 2015-12-31 08:38:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:38:26 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 08:38:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:39:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:39:05 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 08:39:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:39:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:39:18 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 08:39:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:41:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:42:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:43:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:43:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:44:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:44:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:45:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:45:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:46:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:47:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:47:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:48:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:48:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:49:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:50:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:51:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:55:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:55:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:56:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:56:05 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 08:56:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:56:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:56:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:56:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:57:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:57:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:58:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:59:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:59:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:59:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 08:59:58 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 09:00:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:00:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:00:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:00:09 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 09:00:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:00:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:00:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:00:17 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 09:02:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:02:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:02:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:02:50 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 09:02:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:03:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:03:24 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 09:04:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:04:38 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 09:04:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:04:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:04:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:04:43 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 09:04:43 --> Severity: Notice  --> Undefined variable: wallettext C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 92
ERROR - 2015-12-31 09:04:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:04:52 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 09:05:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:05:09 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 09:05:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:05:21 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 09:05:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:05:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:23:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:23:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:59:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:59:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:59:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 09:59:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:00:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:00:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:00:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-31 10:00:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-31 10:00:21 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-31 10:00:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-31 10:00:21 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-31 10:00:21 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2015-12-31 10:00:21 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2015-12-31 10:00:21 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 132
ERROR - 2015-12-31 10:00:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:00:42 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 50
ERROR - 2015-12-31 10:00:42 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 71
ERROR - 2015-12-31 10:00:42 --> Severity: Notice  --> Undefined variable: sub_category_name C:\xampp\htdocs\baang\admin\application\views\sub_category\sub_categorymanage.php 82
ERROR - 2015-12-31 10:00:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:00:56 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 59
ERROR - 2015-12-31 10:00:56 --> Severity: Notice  --> Undefined variable: location C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 69
ERROR - 2015-12-31 10:00:56 --> Severity: Notice  --> Undefined variable: pincode C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 88
ERROR - 2015-12-31 10:00:56 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\baang\admin\application\views\service_location\service_locationmanage.php 106
ERROR - 2015-12-31 10:01:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:01:08 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 42
ERROR - 2015-12-31 10:01:08 --> Severity: Notice  --> Undefined variable: name C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 63
ERROR - 2015-12-31 10:01:08 --> Severity: Notice  --> Undefined variable: emailid C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 87
ERROR - 2015-12-31 10:01:08 --> Severity: Notice  --> Undefined variable: contactno C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 110
ERROR - 2015-12-31 10:01:08 --> Severity: Notice  --> Undefined variable: address C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 135
ERROR - 2015-12-31 10:01:08 --> Severity: Notice  --> Undefined variable: password C:\xampp\htdocs\baang\admin\application\views\employee\employeemanage.php 182
ERROR - 2015-12-31 10:01:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:01:29 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2015-12-31 10:01:29 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 10:01:29 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 10:01:29 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 10:01:29 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 10:01:29 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 10:01:29 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 10:01:29 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 10:01:29 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 10:01:29 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 10:01:29 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 10:01:29 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 10:01:29 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 10:01:29 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 10:02:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:03:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:03:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:03:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:03:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:03:47 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 10:03:47 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 10:03:47 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 10:03:47 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 10:03:47 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 10:03:47 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 10:03:47 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 10:03:47 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 10:03:47 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 10:03:47 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 10:03:47 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 10:03:47 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 10:03:47 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 10:04:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:04:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:04:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:05:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:05:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-31 10:05:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-31 10:05:52 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-31 10:05:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-31 10:05:52 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-31 10:05:52 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2015-12-31 10:05:52 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2015-12-31 10:05:52 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 132
ERROR - 2015-12-31 10:05:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:05:58 --> Severity: Notice  --> Undefined index: extension C:\xampp\htdocs\baang\admin\application\controllers\baang.php 210
ERROR - 2015-12-31 10:05:58 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 211
ERROR - 2015-12-31 10:05:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:05:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-31 10:05:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-31 10:05:58 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-31 10:05:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-31 10:05:58 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-31 10:05:58 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2015-12-31 10:05:58 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2015-12-31 10:05:58 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 132
ERROR - 2015-12-31 10:06:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:06:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-31 10:06:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-31 10:06:12 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-31 10:06:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-31 10:06:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-31 10:06:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:06:19 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\baang\admin\application\controllers\baang.php 211
ERROR - 2015-12-31 10:06:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:06:19 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-31 10:06:19 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-31 10:06:19 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-31 10:06:19 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-31 10:06:19 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-31 10:06:19 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2015-12-31 10:06:19 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2015-12-31 10:06:19 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 132
ERROR - 2015-12-31 10:18:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:18:27 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2015-12-31 10:18:27 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 10:18:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 10:18:27 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 10:18:27 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 10:18:27 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 10:18:27 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 10:18:27 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 10:18:27 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 10:18:27 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 10:18:27 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 10:18:27 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 10:18:27 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 10:18:27 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 10:18:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:29:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:29:48 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2015-12-31 10:29:48 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 10:29:48 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 10:29:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 10:29:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 10:29:48 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 10:29:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 10:29:48 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 10:29:48 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 10:29:48 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 10:29:48 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 10:29:48 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 10:29:48 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 10:29:48 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 10:30:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:30:04 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 10:30:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:31:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:31:29 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 10:31:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:32:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:32:37 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 10:32:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:32:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:32:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:32:57 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 10:40:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:40:26 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 10:42:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:42:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-31 10:42:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-31 10:42:26 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-31 10:42:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-31 10:42:26 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-31 10:42:26 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2015-12-31 10:42:26 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2015-12-31 10:42:26 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 132
ERROR - 2015-12-31 10:47:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:47:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 10:47:11 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 77
ERROR - 2015-12-31 10:47:11 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-31 10:47:11 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 81
ERROR - 2015-12-31 10:47:11 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 82
ERROR - 2015-12-31 10:47:11 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 84
ERROR - 2015-12-31 10:47:11 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 103
ERROR - 2015-12-31 10:47:11 --> Severity: Notice  --> Undefined variable: category_name C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 114
ERROR - 2015-12-31 10:47:11 --> Severity: Notice  --> Undefined variable: shift C:\xampp\htdocs\baang\admin\application\views\category\categorymanage.php 132
ERROR - 2015-12-31 11:33:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 11:33:47 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\newordergrid.php 48
ERROR - 2015-12-31 11:34:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 11:34:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 11:34:46 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2015-12-31 11:34:46 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 11:34:46 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 11:34:46 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 11:34:46 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 11:34:46 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 11:34:46 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 11:34:46 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 11:34:46 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 11:34:46 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 11:34:46 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 11:34:46 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 11:34:46 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 11:34:46 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 11:38:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 11:38:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 11:38:33 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2015-12-31 11:38:33 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 11:38:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 11:38:33 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 11:38:33 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 11:38:33 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 11:38:33 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 11:38:33 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 11:38:33 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 11:38:33 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 11:38:33 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 11:38:33 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 11:38:33 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 11:38:33 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 11:38:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 11:38:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 11:38:40 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2015-12-31 11:38:40 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 11:38:40 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 11:38:40 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 11:38:40 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 11:38:40 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 11:38:40 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 11:38:40 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 11:38:40 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 11:38:40 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 11:38:40 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 11:38:40 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 201
ERROR - 2015-12-31 11:38:40 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 223
ERROR - 2015-12-31 11:38:40 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 249
ERROR - 2015-12-31 11:40:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 11:40:45 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2015-12-31 11:40:45 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 11:40:45 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 99
ERROR - 2015-12-31 11:40:45 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 112
ERROR - 2015-12-31 11:40:45 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 11:40:45 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 116
ERROR - 2015-12-31 11:40:45 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 117
ERROR - 2015-12-31 11:40:45 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 119
ERROR - 2015-12-31 11:40:45 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 135
ERROR - 2015-12-31 11:40:45 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 161
ERROR - 2015-12-31 11:40:45 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 179
ERROR - 2015-12-31 11:40:45 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 202
ERROR - 2015-12-31 11:40:45 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 224
ERROR - 2015-12-31 11:40:45 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 250
ERROR - 2015-12-31 11:43:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 11:43:20 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2015-12-31 11:43:20 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 11:43:20 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 107
ERROR - 2015-12-31 11:43:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 120
ERROR - 2015-12-31 11:43:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2015-12-31 11:43:20 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2015-12-31 11:43:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 125
ERROR - 2015-12-31 11:43:20 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 127
ERROR - 2015-12-31 11:43:20 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 143
ERROR - 2015-12-31 11:43:20 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 169
ERROR - 2015-12-31 11:43:20 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 187
ERROR - 2015-12-31 11:43:20 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 210
ERROR - 2015-12-31 11:43:20 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 232
ERROR - 2015-12-31 11:43:20 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 258
ERROR - 2015-12-31 11:43:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 11:43:43 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2015-12-31 11:43:43 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 11:43:43 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 107
ERROR - 2015-12-31 11:43:43 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 120
ERROR - 2015-12-31 11:43:43 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2015-12-31 11:43:43 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2015-12-31 11:43:43 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 125
ERROR - 2015-12-31 11:43:43 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 127
ERROR - 2015-12-31 11:43:43 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 143
ERROR - 2015-12-31 11:43:43 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 169
ERROR - 2015-12-31 11:43:43 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 187
ERROR - 2015-12-31 11:43:43 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 210
ERROR - 2015-12-31 11:43:43 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 232
ERROR - 2015-12-31 11:43:43 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 258
ERROR - 2015-12-31 11:43:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 11:43:53 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2015-12-31 11:43:53 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 11:43:53 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 107
ERROR - 2015-12-31 11:43:53 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 120
ERROR - 2015-12-31 11:43:53 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2015-12-31 11:43:53 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2015-12-31 11:43:53 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 125
ERROR - 2015-12-31 11:43:53 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 127
ERROR - 2015-12-31 11:43:53 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 143
ERROR - 2015-12-31 11:43:53 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 169
ERROR - 2015-12-31 11:43:53 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 187
ERROR - 2015-12-31 11:43:53 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 210
ERROR - 2015-12-31 11:43:53 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 232
ERROR - 2015-12-31 11:43:53 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 258
ERROR - 2015-12-31 11:44:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 12:05:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 12:05:12 --> Severity: Notice  --> Undefined variable: seacondition C:\xampp\htdocs\baang\admin\application\models\baang_model.php 100
ERROR - 2015-12-31 12:05:12 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\baang\admin\application\views\product\productautocompletion.php 5
ERROR - 2015-12-31 12:05:12 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 107
ERROR - 2015-12-31 12:05:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 120
ERROR - 2015-12-31 12:05:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2015-12-31 12:05:12 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 124
ERROR - 2015-12-31 12:05:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 125
ERROR - 2015-12-31 12:05:12 --> Severity: Notice  --> Undefined variable: photo C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 127
ERROR - 2015-12-31 12:05:12 --> Severity: Notice  --> Undefined variable: category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 143
ERROR - 2015-12-31 12:05:12 --> Severity: Notice  --> Undefined variable: sub_category_id C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 169
ERROR - 2015-12-31 12:05:12 --> Severity: Notice  --> Undefined variable: product_name C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 187
ERROR - 2015-12-31 12:05:12 --> Severity: Notice  --> Undefined variable: price C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 210
ERROR - 2015-12-31 12:05:12 --> Severity: Notice  --> Undefined variable: unit C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 232
ERROR - 2015-12-31 12:05:12 --> Severity: Notice  --> Undefined variable: description C:\xampp\htdocs\baang\admin\application\views\product\productmanage.php 258
ERROR - 2015-12-31 12:05:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 12:05:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 12:05:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 12:05:52 --> Severity: Notice  --> Undefined index: delivery_charge C:\xampp\htdocs\baang\admin\application\views\order\walletgrid.php 65
ERROR - 2015-12-31 12:05:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-12-31 13:10:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\baang\admin\system\database\drivers\mysql\mysql_driver.php 92
