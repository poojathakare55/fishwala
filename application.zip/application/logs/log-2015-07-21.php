<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-21 09:06:22 --> Severity: Warning  --> include(C:\xampp\htdocs\classfever\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
ERROR - 2015-07-21 09:06:22 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
ERROR - 2015-07-21 09:06:38 --> Severity: Warning  --> include(C:\xampp\htdocs\classfever\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
ERROR - 2015-07-21 09:06:38 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
ERROR - 2015-07-21 09:07:14 --> Severity: Warning  --> include(C:\xampp\htdocs\classfever\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
ERROR - 2015-07-21 09:07:14 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
ERROR - 2015-07-21 09:07:44 --> Severity: Warning  --> include(C:\xampp\htdocs\classfever\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
ERROR - 2015-07-21 09:07:44 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
ERROR - 2015-07-21 09:08:27 --> Severity: Warning  --> include(C:\xampp\htdocs\classfever\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
ERROR - 2015-07-21 09:08:27 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
ERROR - 2015-07-21 09:11:02 --> Severity: Warning  --> include(C:\xampp\htdocs\classfever\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
ERROR - 2015-07-21 09:11:02 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
ERROR - 2015-07-21 09:11:15 --> Severity: Warning  --> include(C:\xampp\htdocs\classfever\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
ERROR - 2015-07-21 09:11:15 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
ERROR - 2015-07-21 09:11:42 --> Severity: Warning  --> include(C:\xampp\htdocs\classfever\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
ERROR - 2015-07-21 09:11:42 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
ERROR - 2015-07-21 09:11:48 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\classfever\admin\application\views\jobposting\institutenameautocompletion.php 5
ERROR - 2015-07-21 09:11:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*
FROM (`user_group`, `pro_job_posting`)
WHERE  `institute_name`  LIKE '%%'
GROU' at line 1
ERROR - 2015-07-21 09:12:10 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\classfever\admin\application\views\jobposting\institutenameautocompletion.php 5
ERROR - 2015-07-21 09:12:10 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\classfever\admin\application\views\jobposting\cityautocompletion.php 5
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\classfever\admin\application\views\jobposting\schoolnameautocompletion.php 5
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\classfever\admin\application\views\jobposting\subjectautocompletion.php 5
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: type_of_institute C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 346
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: school_name C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 403
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: subject C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 408
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: selectedtype_of_jobarray C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 506
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: walk_in_interview_details C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 512
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: type_of_job C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 519
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: walk_in_interview_details C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 538
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: role C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 562
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: subjectname C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 585
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: subject C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 597
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: board C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 619
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 663
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: job_profile C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 678
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: application_deadline C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 694
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: chkmalestatus C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 714
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: chkfemalestatus C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 720
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: notes C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 745
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: school_type C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 771
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: school_name C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 800
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: institute_name C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 822
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: min_exp C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 844
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: max_exp C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 858
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: exptext C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 871
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: apply_to_email C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 887
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: job_category C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 909
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: contact_number C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 924
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: job_posting_date C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 949
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 982
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: selectedjob_posting_imagearray C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 985
ERROR - 2015-07-21 09:12:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 985
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: min_edu_qualification C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1008
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: full_time C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1022
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1031
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: full_time C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1022
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1031
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: payscale_from C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1046
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: payscale_to C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1059
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: city C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1088
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: districtname C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1113
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1125
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: statename C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1148
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: state C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1160
ERROR - 2015-07-21 09:12:11 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1178
ERROR - 2015-07-21 09:12:30 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\classfever\admin\application\views\jobposting\institutenameautocompletion.php 5
ERROR - 2015-07-21 09:12:30 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\classfever\admin\application\views\jobposting\cityautocompletion.php 5
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\classfever\admin\application\views\jobposting\schoolnameautocompletion.php 5
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\classfever\admin\application\views\jobposting\subjectautocompletion.php 5
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: type_of_institute C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 346
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: school_name C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 403
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: subject C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 408
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: selectedtype_of_jobarray C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 506
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: walk_in_interview_details C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 512
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: type_of_job C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 519
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: walk_in_interview_details C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 538
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: role C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 562
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: subjectname C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 585
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: subject C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 597
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: board C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 619
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 663
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: job_profile C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 678
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: application_deadline C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 694
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: chkmalestatus C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 714
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: chkfemalestatus C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 720
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: notes C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 745
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: school_type C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 771
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: school_name C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 800
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: institute_name C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 822
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: min_exp C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 844
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: max_exp C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 858
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: exptext C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 871
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: apply_to_email C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 887
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: job_category C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 909
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: contact_number C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 924
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: job_posting_date C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 949
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 982
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: selectedjob_posting_imagearray C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 985
ERROR - 2015-07-21 09:12:31 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 985
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: min_edu_qualification C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1008
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: full_time C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1022
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1031
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: full_time C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1022
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1031
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: payscale_from C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1046
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: payscale_to C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1059
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: city C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1088
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: districtname C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1113
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1125
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: statename C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1148
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: state C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1160
ERROR - 2015-07-21 09:12:31 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1178
ERROR - 2015-07-21 09:14:04 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\classfever\admin\application\views\jobposting\institutenameautocompletion.php 5
ERROR - 2015-07-21 09:14:04 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\classfever\admin\application\views\jobposting\cityautocompletion.php 5
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\classfever\admin\application\views\jobposting\schoolnameautocompletion.php 5
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: q C:\xampp\htdocs\classfever\admin\application\views\jobposting\subjectautocompletion.php 5
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: type_of_institute C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 346
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: school_name C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 403
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: subject C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 408
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: selectedtype_of_jobarray C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 506
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: walk_in_interview_details C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 512
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: type_of_job C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 519
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: walk_in_interview_details C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 538
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: role C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 562
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: subjectname C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 585
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: subject C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 597
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: board C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 619
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 652
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 660
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: class C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 663
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: job_profile C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 678
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: application_deadline C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 694
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: chkmalestatus C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 714
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: chkfemalestatus C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 720
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: notes C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 745
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: school_type C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 771
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: school_name C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 800
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: institute_name C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 822
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: min_exp C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 844
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: max_exp C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 858
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: exptext C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 871
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: apply_to_email C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 887
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: job_category C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 909
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: contact_number C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 924
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: job_posting_date C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 949
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 982
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: selectedjob_posting_imagearray C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 985
ERROR - 2015-07-21 09:14:05 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 985
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: min_edu_qualification C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1008
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: full_time C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1022
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1031
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: full_time C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1022
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: disable C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1031
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: payscale_from C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1046
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: payscale_to C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1059
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: city C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1088
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: districtname C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1113
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1125
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: statename C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1148
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: state C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1160
ERROR - 2015-07-21 09:14:05 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\classfever\admin\application\views\jobposting\form.php 1178
ERROR - 2015-07-21 17:12:12 --> Severity: Warning  --> include(C:\xampp\htdocs\classfever\admin\application\views): failed to open stream: Permission denied C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
ERROR - 2015-07-21 17:12:12 --> Severity: Warning  --> include(): Failed opening 'application/views/' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\classfever\admin\application\views\v_main.php 175
