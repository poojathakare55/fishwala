<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// You MailChimp API Key
// Obtained by logging into your MailChimp account and navigating to 'Account > API Keys and Info'
$config['mcapi_apikey'] = 'e792aa36441dccf5c81d5702ce5f5e05-us8';

$config['mcapi_secure'] = false;